#!/usr/bin/env python3
"""Compare the 512 KB streaming port with the unmodified DOS C engine."""
import os
import re
import shutil
import struct
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
CC = os.environ.get("HOSTCC", "cc")


def run(args, **kw):
    return subprocess.run(args, text=True, capture_output=True, check=True, **kw).stdout


run([CC, "-O2", "-x", "c", "dos/TINY.C", "-lm", "-o", "build/tiny-original"])
QUESTIONS = [
    "what is the capital of peru", "what is 7 times 8", "is a whale a fish",
    "opposite of hot", "how many legs does a spider have", "what is the symbol for gold",
    "write 47 in words", "what is cat backwards", "plural of mouse", "past tense of go",
    "how many moons does mars have", "what is the biggest ocean",
    "what language do they speak in canada", "does france border spain", "tell me a joke",
    "WHAT IS 7 TIMES 8", "what is the capital of france", "spell elephant",
]
examples = Path("dos/README.TXT").read_text()
examples = examples[examples.index("Things to try"):examples.index("What it knows")]
for line in examples.splitlines()[1:]:
    if line.startswith("  "):
        for question in re.split(r" {2,}", line.strip()):
            if question.startswith(("what ", "who ", "how ", "which ", "where ", "is ",
                                    "does ", "paris ", "spell ", "past ", "opposite ",
                                    "plural ", "write ", "tell ")):
                QUESTIONS.append(question)
QUESTIONS += ["how many people are in earth", "how many people are in earthgSS",
              "what is 1 plus 1", "what is 12 times 12", "what is the capital of poland",
              "what is the capital of japan"]
QUESTIONS = list(dict.fromkeys(QUESTIONS))
for question in QUESTIONS:
    original = run([str(ROOT / "build/tiny-original"), "0"], input=question + "\nquit\n", cwd="dos")
    expected = re.search(r"\n>   ([^\n]*)", original).group(1)
    for exe in ("tiny-host", "tiny-reference", "tiny-portable"):
        actual = run([f"build/{exe}", "--model", "dos/TINY.BIN", "--ask", question]).rstrip("\n")
        assert actual == expected, (exe, question, expected, actual)
print(f"PASS: {len(QUESTIONS)} answers match DOS with float, integer and portable math kernels")

info = run(["build/tiny-host", "--model", "dos/TINY.BIN", "--info"])
assert "131456 bytes" in info, info
assert len(run(["build/tiny-host", "--model", "dos/TINY.BIN", "--ask", "hello", "--max-tokens", "2"]).strip()) <= 2

with tempfile.TemporaryDirectory() as folder:
    folder = Path(folder)
    model = Path("dos/TINY.BIN").read_bytes()
    malformed = [b"", b"TNY1", model[:11], model[:-1], model + b"x"]
    for offset, value in [(4, 0), (6, 9), (8, 0), (8, 5), (10, 513)]:
        b = bytearray(model)
        struct.pack_into("<H", b, offset, value)
        malformed.append(b)
    for bits in (0x7FC00000, 0x7F800000, 0):
        b = bytearray(model)
        struct.pack_into("<I", b, 12, bits)
        malformed.append(b)
    for i, contents in enumerate(malformed):
        path = folder / f"bad{i}.bin"
        path.write_bytes(contents)
        p = subprocess.run(["build/tiny-host", "--model", str(path), "--info"], capture_output=True)
        assert p.returncode == 1, (i, p.stdout, p.stderr)
    copy = folder / "model.bin"
    shutil.copyfile("dos/TINY.BIN", copy)
    run([CC, "-O1", "-g", "-std=c99", "-fsanitize=address,undefined", "-I", "amiga",
         "amiga/tiny.c", "tests/engine_checks.c", "-lm", "-o", "build/engine-checks"])
    run(["build/engine-checks", str(copy)])
print("PASS: malformed models, cancellation, restart, disk error, cleanup; ASan/UBSan clean")
