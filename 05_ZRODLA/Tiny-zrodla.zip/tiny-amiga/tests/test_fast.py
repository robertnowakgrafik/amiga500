#!/usr/bin/env python3
"""Independent rational-arithmetic oracle and all authored Polish FAQ aliases."""
import fractions
import random
import re
import subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
rng=random.Random(13)
def expression(depth):
    if not depth:
        n=rng.randint(0,30);d=rng.choice([1,10])
        return str(n) if d==1 else str(n/10),fractions.Fraction(n,d)
    a,x=expression(depth-1);b,y=expression(depth-1);op=rng.choice("+-*/")
    if op=="/" and not y:op="+"
    value={"+":lambda:x+y,"-":lambda:x-y,"*":lambda:x*y,"/":lambda:x/y}[op]()
    return "("+a+op+b+")",value

cases=[expression(2) for _ in range(200)]
p=subprocess.run(["build/tiny-quick","--database","does-not-exist"],cwd=ROOT,
                 input="\n".join(q for q,_ in cases)+"\nquit\n",text=True,capture_output=True,check=True)
answers=re.findall(r"\[KALKULATOR\] ([^\n]*)",p.stdout)
assert len(answers)==len(cases)
for (q,expected),answer in zip(cases,answers):
    assert fractions.Fraction(answer)==expected,(q,expected,answer)
print("PASS: 200 independent Fraction arithmetic comparisons")

faq=[]
for line in (ROOT/"training/polish_faq.tsv").read_text().splitlines():
    if not line or line.startswith("#"):continue
    aliases,answer=line.split("\t")
    faq.extend((q,answer) for q in aliases.split("|"))
p=subprocess.run(["build/tiny-quick","--database","build/TINY.KB"],cwd=ROOT,
                 input="\n".join(q for q,_ in faq)+"\nquit\n",text=True,capture_output=True,check=True)
answers=re.findall(r"\[BAZA WIEDZY\] ([^\n]*)",p.stdout)
assert len(answers)==len(faq),(len(answers),len(faq))
for (q,expected),answer in zip(faq,answers):assert answer==expected,(q,expected,answer)
print(f"PASS: all {len(faq)} aliases of the 86 authored Polish FAQ records")
