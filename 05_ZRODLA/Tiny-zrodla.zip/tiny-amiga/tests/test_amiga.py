#!/usr/bin/env python3
"""Run the actual Amiga HUNK on a 68000 with only 224 KiB of emulator RAM."""
import os
import re
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
vamos = os.environ.get("VAMOS") or shutil.which("vamos")
if not vamos:
    raise SystemExit("Set VAMOS to the amitools vamos executable")
cases = [
    ("what is 7 times 8", "7 times 8 is 56."),
    ("what is the capital of peru", "Lima."),
    ("is a whale a fish", "No, a whale is a mammal."),
    ("how many legs does a spider have", "Eight."),
    ("what is the symbol for gold", "It is Au."),
    ("plural of mouse", "Mice."),
    ("write 47 in words", "Forty-seven."),
    ("what is cat backwards", "Tac."),
]
command = [vamos, "--vols-base-dir", "/tmp/tiny-vamos-test", "-C", "68000", "-m", "224",
           "-s", "16", "--", "build/TinyCLI", "--model", "dos/TINY.BIN"]
p = subprocess.run(command, input="\n".join(q for q, _ in cases) + "\nquit\n",
                   text=True, capture_output=True, check=True)
answers = re.findall(r"^> (.*)$", p.stdout, re.MULTILINE)
assert answers[:len(cases)] == [a for _, a in cases], p.stdout + p.stderr
assert Path("build/Tiny").read_bytes()[:4] == bytes.fromhex("000003f3")
for name in ("Tiny", "TinyCLI"):
    binary = Path("build", name).read_bytes()
    assert b"mathieee" not in binary and b"ixemul" not in binary, name
print(f"PASS: {len(cases)} native 68000 answers with 224 KiB RAM; no external math/ixemul imports")
