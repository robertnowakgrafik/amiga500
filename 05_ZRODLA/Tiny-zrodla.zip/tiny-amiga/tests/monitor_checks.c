#include "tiny.h"
#include "monitor.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static TinyTelemetry last;
static TinyMonitorHistory history;
static int attention_events, layer_events, predictions, primitives;
static int chosen = -1;

static void observe(const TinyTelemetry *s, void *user)
{
    int i;
    (void)user;
    assert(s->position >= 0 && s->position < TINY_CONTEXT);
    assert(s->layers == 4);
    if (s->event == TINY_OBSERVE_TOKEN) {
        assert(s->layer_mask == 0 && s->attention_length == 0);
    } else if (s->event == TINY_OBSERVE_ATTENTION) {
        float sum = 0.0f;
        assert(s->layer >= 0 && s->layer < s->layers);
        assert(s->head >= 0 && s->head < 4);
        assert(s->attention_length == s->position + 1);
        for (i = 0; i < s->attention_length; i++) {
            assert(s->attention[i] >= 0.0f && s->attention[i] <= 1.00001f);
            sum += s->attention[i];
        }
        assert(sum > 0.9999f && sum < 1.0001f);
        attention_events++;
    } else if (s->event == TINY_OBSERVE_LAYER) {
        assert(s->activity[s->layer] >= 0.0f);
        assert(s->layer_mask & (1U << s->layer));
        layer_events++;
    } else if (s->event == TINY_OBSERVE_PREDICTION) {
        float sum = 0.0f;
        assert(s->has_prediction);
        for (i = 0; i < TINY_CANDIDATES; i++) {
            assert(s->candidate[i] >= 0 && s->candidate[i] < 97);
            assert(s->probability[i] >= 0.0f && s->probability[i] <= 1.00001f);
            if (i) assert(s->probability[i-1] >= s->probability[i]);
            sum += s->probability[i];
        }
        assert(sum <= 1.00001f);
        chosen = s->candidate[0];
        predictions++;
    }
    tiny_monitor_record(&history, s);
    last = *s;
}

static void letter(int c, void *user)
{
    (void)user;
    assert(c == chosen + 30);
}

static void fill(void *user, int x0, int y0, int x1, int y1, int pen)
{
    (void)user;
    assert(x0 >= 2 && x1 < 280 && y0 >= 0 && y1 <= 113);
    assert(x0 <= x1 && y0 <= y1 && pen >= 0 && pen <= 3);
    primitives++;
#ifdef EMIT_PREVIEW
    printf("F\t%d\t%d\t%d\t%d\t%d\n", x0, y0, x1, y1, pen);
#endif
}

static void line(void *user, int x0, int y0, int x1, int y1, int pen)
{
    (void)user;
    assert(x0 >= 2 && x1 < 280 && y0 >= 0 && y1 <= 113);
    assert(pen >= 0 && pen <= 3);
    primitives++;
#ifdef EMIT_PREVIEW
    printf("L\t%d\t%d\t%d\t%d\t%d\n", x0, y0, x1, y1, pen);
#endif
}

static void text(void *user, int x, int y, const char *text, int pen)
{
    (void)user;
    assert(x >= 8 && x + (int)strlen(text) * 8 <= 280);
    assert(y >= 7 && y <= 113 && pen >= 0 && pen <= 3);
    primitives++;
#ifdef EMIT_PREVIEW
    printf("T\t%d\t%d\t%d\t%s\n", x, y, pen, text);
#endif
}

int main(void)
{
    char baseline[TINY_CONTEXT+1], observed[TINY_CONTEXT+1];
    TinyPlot plot = { NULL, fill, line, text };
    int i;
    assert(tiny_load("dos/TINY.BIN"));
    assert(tiny_memory() == 131456UL);
    tiny_answer("what is 7 times 8", baseline, 128, NULL, NULL, NULL);
    tiny_set_observer(observe, NULL);
    tiny_answer("what is 7 times 8", observed, 128, NULL, letter, NULL);
    tiny_set_observer(NULL, NULL);
    assert(!strcmp(baseline, observed));
    assert(!strcmp(observed, "7 times 8 is 56."));
    assert(attention_events > 100 && layer_events > 10 && predictions > 1);
    assert(history.count == predictions && history.count <= TINY_MONITOR_HISTORY);
#ifndef EMIT_PREVIEW
    tiny_monitor_draw(NULL, &history, &plot, 8, 0, 272);
#endif
    tiny_monitor_draw(&last, &history, &plot, 8, 0, 272);
    assert(primitives > 20);
#ifndef EMIT_PREVIEW
    for (i = 0; i < 50; i++) tiny_monitor_record(&history, &last);
    assert(history.count == TINY_MONITOR_HISTORY);
    last.layers = TINY_MAX_LAYERS;
    last.attention_length = TINY_CONTEXT;
    last.layer = 7; last.head = 127;
    for (i = 0; i < last.layers; i++) last.activity[i] = (float)i;
    for (i = 0; i < last.attention_length; i++) last.attention[i] = 1.0f / TINY_CONTEXT;
    tiny_monitor_draw(&last, &history, &plot, 8, 0, 272);
    puts("PASS: real layer/attention/probability telemetry, unchanged answer, bounded charts and history");
#else
    (void)i;
#endif
    tiny_free();
    return 0;
}
