#include "tiny.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static int stop(int phase, int done, int total, void *user)
{
    (void)total; (void)user;
    return !(phase == 1 && done == 2);
}

static int stop_inside_token(int kind, int done, int total, void *user)
{
    (void)done; (void)total;
    return kind != *(int *)user;
}

int main(int argc, char **argv)
{
    char out[TINY_CONTEXT + 1];
    FILE *fp;
    int kind;
    assert(argc == 2);
    assert(tiny_answer("hi", out, 128, NULL, NULL, NULL) == -2);
    assert(tiny_load(argv[1]));
    assert(tiny_memory() == 131456UL);
    assert(tiny_answer("what is 7 times 8", out, 128, stop, NULL, NULL) == -1);
    assert(strlen(out) == 2);
    assert(tiny_answer("what is 7 times 8", out, 128, NULL, NULL, NULL) > 0);
    assert(!strcmp(out, "7 times 8 is 56."));
    for (kind = TINY_WORK_DISK; kind <= TINY_WORK_ATTENTION; kind++) {
        tiny_set_work(stop_inside_token, &kind);
        assert(tiny_answer("what is 7 times 8", out, 128, NULL, NULL, NULL) == -1);
        assert(out[0] == 0);
        tiny_set_work(NULL, NULL);
        assert(tiny_answer("what is 7 times 8", out, 128, NULL, NULL, NULL) > 0);
        assert(!strcmp(out, "7 times 8 is 56."));
    }
    /* Simulate removal/read failure after the model has been opened. */
    fp = fopen(argv[1], "wb");
    assert(fp); fclose(fp);
    assert(tiny_answer("hello", out, 128, NULL, NULL, NULL) == -3);
    tiny_free();
    assert(tiny_memory() == 0);
    assert(!tiny_load(argv[1]));
    assert(tiny_memory() == 0);
    return 0;
}
