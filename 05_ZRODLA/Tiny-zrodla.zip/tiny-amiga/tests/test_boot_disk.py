#!/usr/bin/env python3
"""Validate the released OFS boot disk and execute its native stack helper."""
import os
import shutil
import struct
import subprocess
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
xdftool = os.environ.get("XDFTOOL") or shutil.which("xdftool")
vamos = os.environ.get("VAMOS") or shutil.which("vamos")
compiler = os.environ.get("CROSS", "m68k-amigaos-") + "gcc"
assert xdftool and vamos, "Set XDFTOOL and VAMOS to amitools executables"
adf = Path("dist/Tiny-A500-512K-boot.adf")
raw = adf.read_bytes()
assert len(raw) == 880 * 1024
assert raw[:4] == b"DOS\0", "Must use OFS / DOS0 for Kickstart 1.3"
assert b"dos.library\0" in raw[12:1024], "Missing ROM DOS bootstrap"
total = 0
for word in struct.unpack(">256I", raw[:1024]):
    total += word
    total = (total & 0xFFFFFFFF) + (total >> 32)
assert total == 0xFFFFFFFF, "Invalid bootblock end-around-carry checksum"
assert raw == Path("dist/Tiny-A500-512K.adf").read_bytes()
assert raw == Path("dist/Tiny-A500-512K-live-boot.adf").read_bytes()
assert raw == Path("dist/Tiny-A500-512K-fast-pl-boot.adf").read_bytes()

with tempfile.TemporaryDirectory() as tmp:
    tmp = Path(tmp)
    for disk_path, source in [
        ("S/Startup-Sequence", "amiga/Startup-Sequence"),
        ("C/TinyStack", "build/TinyStack"),
        ("Tiny", "build/Tiny"),
        ("TINY.BIN", "dos/TINY.BIN"),
        ("TINY.KB", "build/TINY.KB"),
        ("TinyQuick", "build/TinyQuick"),
    ]:
        extracted = tmp / Path(disk_path).name
        subprocess.run([xdftool, str(adf), "read", disk_path, str(extracted)], check=True)
        assert extracted.read_bytes() == Path(source).read_bytes(), disk_path
        if disk_path in ("C/TinyStack", "Tiny"):
            assert extracted.read_bytes()[:4] == bytes.fromhex("000003f3"), disk_path
    startup = (tmp / "Startup-Sequence").read_bytes()
    assert startup == b"SYS:C/TinyStack\nSYS:Tiny SYS:TINY.BIN\n"
    assert b"\r" not in startup
with zipfile.ZipFile("dist/Tiny-A500-512K.zip") as z:
    assert z.read("S/Startup-Sequence") == startup
    assert z.read("C/TinyStack") == Path("build/TinyStack").read_bytes()
subprocess.run([xdftool, str(adf), "fsck"], check=True)
print("PASS: OFS 880 KB, boot checksum, startup commands, binaries and model verified")

subprocess.run([compiler, "-O2", "-std=c99", "-m68000", "-msoft-float", "-mcrt=nix13",
                "tests/boot_stack_checks.c", "-o", "build/boot-stack-checks"], check=True)
for executable in ("build/TinyStack", "build/boot-stack-checks"):
    subprocess.run([vamos, "--vols-base-dir", "/tmp/tiny-vamos-boot-test", "-C", "68000",
                    "-m", "128", "-s", "4", "--", executable], check=True)
print("PASS: native 68000 helper sets next CLI stack to 16 KB from a 4 KB starting stack")
