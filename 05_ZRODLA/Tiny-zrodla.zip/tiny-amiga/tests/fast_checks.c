#include "fast.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static void math(const char *q, const char *answer)
{
    FastReply r;
    assert(tiny_fast(q,"this-database-does-not-exist",&r)==FAST_MATH);
    if(strcmp(r.answer,answer)) {printf("BAD: %s -> %s, wanted %s\n",q,r.answer,answer);assert(0);}
}

int main(void)
{
    const char *bad[]={"1/0","0/0","2147483647+1","999999999999999","2+(","2+abc","2^17","1.1234567",NULL};
    FastReply r;
    int i;
    math("2+5","7");math("2+5\n","7");math("\t2+5\r\n","7");
    math("2+3*4","14");math("(2+3)*4","20");math("-2^2","-4");
    math("(-2)^2","4");math("2^3^2","512");math("2^-2","0.25");math("0.1+0.2","0.3");
    math("0,1+0,2","0.3");math("1/3+1/6","0.5");math("1/3","1/3");math("10/4","2.5");
    math("what is 7 times 8","56");math("ile jest 8 razy 7","56");math("oblicz 5 minus 8","-3");
    math("2147483647-2147483647","0");math("-2147483647-1","-2147483648");
    for(i=0;bad[i];i++) assert(tiny_math(bad[i],&r)==FAST_ERROR);
    assert(tiny_math("co to ram",&r)==FAST_NONE);
    assert(tiny_math("stolica polski",&r)==FAST_NONE);
    assert(tiny_fast("2+3*4","absent",&r)==FAST_MATH);
    assert(strstr(r.steps,"3 * 4 = 12") && strstr(r.steps,"2 + 12 = 14"));
    assert(tiny_fast("stolica polski","build/TINY.KB",&r)==FAST_FACT);
    assert(strstr(r.answer,"Warszawa"));
    assert(tiny_fast("jaki jest symbol zlota","build/TINY.KB",&r)==FAST_FACT);
    assert(strstr(r.answer,"Au"));
    assert(tiny_fast("jaka jest liczba atomowa tlenu","build/TINY.KB",&r)==FAST_FACT);
    assert(strstr(r.answer,"8"));
    assert(tiny_fast("ile nog ma mrowka","build/TINY.KB",&r)==FAST_FACT);
    assert(strstr(r.answer,"szesc"));
    assert(tiny_fast("co to algorytm","build/TINY.KB",&r)==FAST_FACT);
    assert(strstr(r.answer,"krokow"));
    assert(tiny_fast("dlaczego jest dzien i noc","build/TINY.KB",&r)==FAST_FACT);
    assert(strstr(r.answer,"obraca"));
    assert(tiny_fast("ile ludzi jest na ziemi","build/TINY.KB",&r)==FAST_FACT);
    assert(strstr(r.answer,"biezacych"));
    assert(tiny_fast("how many moons does mars have","build/TINY.KB",&r)==FAST_FACT);
    assert(tiny_fast("what is the capital of peru","build/TINY.KB",&r)==FAST_FACT);
    assert(strstr(r.answer,"Lima"));
    assert(tiny_fast("stolica atlantydy","build/TINY.KB",&r)==FAST_NONE);
    tiny_fast_close();
    assert(tiny_fast("co to ram","missing-database",&r)==FAST_ERROR);
    math("2+5","7");
    puts("PASS: exact instant arithmetic, Polish steps, errors and multi-topic knowledge; no model needed");
    return 0;
}
