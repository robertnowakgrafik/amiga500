/* Indexed local retrieval, kept separate from the neural model. */
#include "fast.h"
#include "knowledge_ids.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <ctype.h>

static FILE *kb_file;
static unsigned char *kb_index;
static uint32_t kb_count, kb_size;
static char kb_path[256];

static uint32_t read32(const unsigned char *b)
{
    return (uint32_t)b[0] | ((uint32_t)b[1]<<8) | ((uint32_t)b[2]<<16) | ((uint32_t)b[3]<<24);
}

void tiny_fast_close(void)
{
    if (kb_file) fclose(kb_file);
    free(kb_index); kb_file = NULL; kb_index = NULL; kb_count = 0;kb_path[0]=0;
}

static int open_database(const char *path)
{
    unsigned char h[12];
    if (kb_file && !strcmp(path,kb_path)) return 1;
    tiny_fast_close();
    if(strlen(path)>=sizeof(kb_path)) return 0;
    kb_file = fopen(path, "rb");
    if (!kb_file || fread(h,1,12,kb_file)!=12 || memcmp(h,"TKB1",4)) goto error;
    kb_count = read32(h+4); kb_size = read32(h+8);
    if (!kb_count || kb_count>20000 || kb_size<12+kb_count*12 || kb_size>1048576) goto error;
    kb_index = malloc(kb_count*12);
    if (!kb_index || fread(kb_index,12,kb_count,kb_file)!=kb_count) goto error;
    if(fseek(kb_file,0,SEEK_END) || ftell(kb_file)!=(long)kb_size) goto error;
    strcpy(kb_path,path);
    return 1;
error:
    tiny_fast_close(); return 0;
}

static void normalize(const char *in, char *out, unsigned capacity)
{
    unsigned n=0;
    while (*in && n+1<capacity) {
        unsigned char c = (unsigned char)*in++;
        if (c==0xc4 && *in) {
            unsigned char d=(unsigned char)*in++;
            c = d==0x84||d==0x85?'a':d==0x86||d==0x87?'c':d==0x98||d==0x99?'e':' ';
        } else if (c==0xc5 && *in) {
            unsigned char d=(unsigned char)*in++;
            c = d==0x81||d==0x82?'l':d==0x83||d==0x84?'n':d==0x9a||d==0x9b?'s':
                d==0xb9||d==0xba||d==0xbb||d==0xbc?'z':' ';
        } else if (c==0xc3 && *in) {
            unsigned char d=(unsigned char)*in++; c=d==0x93||d==0xb3?'o':' ';
        }
        c=(unsigned char)tolower(c);
        if ((c>='a'&&c<='z')||(c>='0'&&c<='9')) out[n++]=(char)c;
        else if (n && out[n-1]!=' ') out[n++]=' ';
    }
    while (n && out[n-1]==' ') n--;
    out[n]=0;
}

static int lookup(const char *key, unsigned *kind, char *value)
{
    uint32_t a=2166136261UL,b=5381, low=0, high=kb_count;
    const unsigned char *s=(const unsigned char *)key;
    unsigned char header[3];
    while (*s) { a=(a^*s)*16777619UL; b=(b*33)^*s++; }
    while (low<high) {
        uint32_t mid=low+(high-low)/2;
        const unsigned char *entry=kb_index+mid*12;
        uint32_t x=read32(entry),y=read32(entry+4);
        if (a<x || (a==x && b<y)) high=mid;
        else if (a>x || (a==x && b>y)) low=mid+1;
        else {
            uint32_t offset=read32(entry+8);
            unsigned length;
            if (offset<12+12*kb_count || offset+3>kb_size || fseek(kb_file,(long)offset,SEEK_SET)) return -1;
            if (fread(header,1,3,kb_file)!=3) return -1;
            length=header[1]|((unsigned)header[2]<<8); *kind=header[0];
            if (length>255 || offset+3+length>kb_size || fread(value,1,length,kb_file)!=length) return -1;
            value[length]=0; return 1;
        }
    }
    return 0;
}

static const char *subject_alias(const char *s)
{
    static const char *const pairs[][2]={
        {"polska","poland"},{"polski","poland"},{"polsce","poland"},
        {"niemcy","germany"},{"niemiec","germany"},{"francja","france"},{"francji","france"},
        {"wlochy","italy"},{"wloch","italy"},{"hiszpania","spain"},{"hiszpanii","spain"},
        {"japonia","japan"},{"japonii","japan"},{"chiny","china"},{"chin","china"},
        {"usa","united states"},{"stany zjednoczone","united states"},{"stanow zjednoczonych","united states"},
        {"wielka brytania","united kingdom"},{"wielkiej brytanii","united kingdom"},
        {"rosja","russia"},{"rosji","russia"},{"ukraina","ukraine"},{"ukrainy","ukraine"},
        {"czechy","czech republic"},{"czech","czech republic"},{"slowacja","slovakia"},{"slowacji","slovakia"},
        {"litwa","lithuania"},{"litwy","lithuania"},{"lotwa","latvia"},{"lotwy","latvia"},
        {"estonia","estonia"},{"estonii","estonia"},{"kanada","canada"},{"kanady","canada"},
        {"indie","india"},{"indii","india"},{"brazylia","brazil"},{"brazylii","brazil"},
        {"australia","australia"},{"australii","australia"},{"austria","austria"},{"austrii","austria"},
        {"szwajcaria","switzerland"},{"szwajcarii","switzerland"},{"grecja","greece"},{"grecji","greece"},
        {"norwegia","norway"},{"norwegii","norway"},{"szwecja","sweden"},{"szwecji","sweden"},
        {"dania","denmark"},{"danii","denmark"},{"finlandia","finland"},{"finlandii","finland"},
        {"pajak","spider"},{"pajaka","spider"},{"pies","dog"},{"psa","dog"},{"kot","cat"},{"kota","cat"},
        {"wieloryb","whale"},{"wieloryba","whale"},{"mrowka","ant"},{"mrowki","ant"},
        {"krowa","cow"},{"krowy","cow"},{"kon","horse"},{"konia","horse"},{"osmiornica","octopus"},
        {"osmiornicy","octopus"},{"waz","snake"},{"weza","snake"},{"ryba","fish"},{"ryby","fish"},
        {"pszczola","bee"},{"pszczoly","bee"},{"pingwin","penguin"},{"pingwina","penguin"},
        {"nietoperz","bat"},{"nietoperza","bat"},{"slon","elephant"},{"slonia","elephant"},
        {"zloto","gold"},{"zlota","gold"},{"srebro","silver"},{"srebra","silver"},{"zelazo","iron"},{"zelaza","iron"},
        {"wodor","hydrogen"},{"wodoru","hydrogen"},{"hel","helium"},{"helu","helium"},
        {"tlen","oxygen"},{"tlenu","oxygen"},{"azot","nitrogen"},{"azotu","nitrogen"},
        {"wegiel","carbon"},{"wegla","carbon"},{"sod","sodium"},{"sodu","sodium"},
        {"potas","potassium"},{"potasu","potassium"},{"wapn","calcium"},{"wapnia","calcium"},
        {"miedz","copper"},{"miedzi","copper"},{"rtec","mercury"},{"rteci","mercury"},
        {"siarka","sulfur"},{"siarki","sulfur"},{"chlor","chlorine"},{"chloru","chlorine"},
        {"krzem","silicon"},{"krzemu","silicon"},{"fosfor","phosphorus"},{"fosforu","phosphorus"},
        {"magnez","magnesium"},{"magnezu","magnesium"},{"uran","uranium"},{"uranu","uranium"},
        {"poniedzialek","monday"},{"wtorek","tuesday"},{"sroda","wednesday"},{"czwartek","thursday"},
        {"piatek","friday"},{"sobota","saturday"},{"niedziela","sunday"},
        {"styczen","january"},{"luty","february"},{"marzec","march"},{"kwiecien","april"},
        {"maj","may"},{"czerwiec","june"},{"lipiec","july"},{"sierpien","august"},
        {"wrzesien","september"},{"pazdziernik","october"},{"listopad","november"},{"grudzien","december"}
    };
    unsigned i;
    for(i=0;i<sizeof(pairs)/sizeof(pairs[0]);i++) if(!strcmp(s,pairs[i][0])) return pairs[i][1];
    return s;
}

static const char *translated(const char *s)
{
    static const char *const pairs[][2]={
        {"Warsaw","Warszawa"},{"London","Londyn"},{"Paris","Paryz"},{"Rome","Rzym"},{"Vienna","Wieden"},
        {"Beijing","Pekin"},{"Moscow","Moskwa"},{"Europe","Europa"},{"Asia","Azja"},{"Africa","Afryka"},
        {"North America","Ameryka Polnocna"},{"South America","Ameryka Poludniowa"},
        {"mammal","ssak"},{"bird","ptak"},{"fish","ryba"},{"reptile","gad"},{"amphibian","plaz"},
        {"insect","owad"},{"arachnid","pajeczak"},{"gas","gaz"},{"solid","cialo stale"},{"liquid","ciecz"},
        {"a metal","metal"},{"a nonmetal","niemetal"},{"a noble gas","gaz szlachetny"},{"a metalloid","metaloid"},
        {"four","cztery"},{"two","dwa"},{"six","szesc"},{"eight","osiem"},{"ten","dziesiec"},{"none","brak"},
        {"yes","tak"},{"no","nie"},{"English","angielski"},{"Polish","polski"},{"French","francuski"},
        {"German","niemiecki"},{"Spanish","hiszpanski"},{"Italian","wloski"},{"Japanese","japonski"},
        {"Portuguese","portugalski"},{"Russian","rosyjski"},{"Euro","euro"}
    };
    unsigned i;
    for(i=0;i<sizeof(pairs)/sizeof(pairs[0]);i++) if(!strcmp(s,pairs[i][0])) return pairs[i][1];
    return s;
}

static void relational_answer(unsigned kind, const char *value, FastReply *reply)
{
    static const char *const labels[][2]={
        {"capital","Stolica"},{"continent","Kontynent"},{"people","Nazwa mieszkancow"},
        {"landlocked","Kraj bez dostepu do morza"},{"subregion","Region"},{"borders","Sasiednie panstwa"},
        {"domain","Domena internetowa"},{"language","Uzywane jezyki"},{"currency","Waluta"},
        {"state_capital","Stolica stanu"},{"symbol","Symbol chemiczny"},{"atomic","Liczba atomowa"},
        {"kind","Typ pierwiastka"},{"phase","Stan skupienia"},{"class","Grupa zwierzat"},
        {"legs","Liczba nog"},{"baby","Nazwa mlodego (ang.)"},{"sound","Odglos (ang.)"},
        {"home","Miejsce zycia"},{"food","Pokarm"},{"group","Nazwa grupy (ang.)"},
        {"male","Samiec (ang.)"},{"female","Samica (ang.)"},{"plural","Liczba mnoga (ang.)"},
        {"opposite","Przeciwienstwo (ang.)"},{"past","Czas przeszly (ang.)"},{"synonym","Synonim (ang.)"},
        {"comparative","Stopien wyzszy (ang.)"},{"superlative","Stopien najwyzszy (ang.)"},
        {"word_French","Po francusku"},{"word_German","Po niemiecku"},{"word_Spanish","Po hiszpansku"},
        {"word_Italian","Po wlosku"},{"day_after","Nastepny dzien"},{"day_before","Poprzedni dzien"},
        {"month_after","Nastepny miesiac"},{"month_before","Poprzedni miesiac"},
        {"month_days","Liczba dni miesiaca"},{"month_number","Numer miesiaca"}
    };
    const char *relation=kb_relations[kind-3], *label=relation, *v=translated(value);
    unsigned i;
    for(i=0;i<sizeof(labels)/sizeof(labels[0]);i++) if(!strcmp(relation,labels[i][0])) {label=labels[i][1];break;}
    if(strlen(label)+strlen(v)+4>=sizeof(reply->answer)) {
        reply->kind=FAST_ERROR;strcpy(reply->answer,"Wpis jest za dlugi do wyswietlenia.");return;
    }
    strcpy(reply->answer,label);strcat(reply->answer,": ");strcat(reply->answer,v);strcat(reply->answer,".");
    strcpy(reply->steps,"Zrodlo: fakty treningowe Tiny.\nOdpowiedz odczytana z bazy wiedzy.");
}

int tiny_fast(const char *question, const char *database, FastReply *reply)
{
    static const char *const patterns[][2]={
        {"jaka jest stolica ","capital"},{"stolica ","capital"},{"capital of ","capital"},
        {"what is the capital of ","capital"},{"jaki jest kontynent ","continent"},{"kontynent ","continent"},
        {"gdzie lezy ","continent"},{"waluta ","currency"},{"jaka jest waluta ","currency"},
        {"jezyk ","language"},{"jaki jest jezyk ","language"},{"granice ","borders"},{"z kim graniczy ","borders"},
        {"symbol ","symbol"},{"jaki jest symbol ","symbol"},{"symbol chemiczny ","symbol"},
        {"jaki jest symbol chemiczny ","symbol"},{"liczba atomowa ","atomic"},{"jaka jest liczba atomowa ","atomic"},
        {"stan skupienia ","phase"},{"klasa ","class"},{"grupa zwierzat ","class"},
        {"ile nog ma ","legs"},{"nogi ","legs"},{"how many legs does ","legs"},
        {"pokarm ","food"},{"co je ","food"},{"odglos ","sound"},{"liczba mnoga ","plural"},
        {"plural of ","plural"},{"przeciwienstwo ","opposite"},{"opposite of ","opposite"},
        {"synonim ","synonym"},{"czas przeszly ","past"},{"past tense of ","past"},
        {"po francusku ","word_French"},{"po niemiecku ","word_German"},{"po hiszpansku ","word_Spanish"},
        {"po wlosku ","word_Italian"},{"dzien po ","day_after"},{"dzien przed ","day_before"},
        {"miesiac po ","month_after"},{"miesiac przed ","month_before"},{"dni miesiaca ","month_days"},
        {"numer miesiaca ","month_number"},{"domena ","domain"},{"region ","subregion"},
        {"stolica stanu ","state_capital"}
    };
    char q[128],key[192],value[256];
    unsigned kind=0,i;
    int found;
    if(tiny_math(question,reply)) return reply->kind;
    normalize(question,q,sizeof(q));
    if(!open_database(database)) {
        reply->kind=FAST_ERROR;strcpy(reply->answer,"Nie moge otworzyc TINY.KB. Kalkulator nadal dziala.");return reply->kind;
    }
    snprintf(key,sizeof(key),"q:%s",q);
    found=lookup(key,&kind,value);
    if(!found) for(i=0;i<sizeof(patterns)/sizeof(patterns[0]);i++) {
        size_t n=strlen(patterns[i][0]);
        if(!strncmp(q,patterns[i][0],n)) {
            char subject[128];size_t length;
            strcpy(subject,q+n);length=strlen(subject);
            if(length>5 && !strcmp(subject+length-5," have")) subject[length-5]=0;
            snprintf(key,sizeof(key),"r:%s:%s",patterns[i][1],subject_alias(subject));
            found=lookup(key,&kind,value);
            if(found) break;
        }
    }
    if(!found) for(i=0;i<KB_RELATION_COUNT;i++) {
        size_t n=strlen(kb_relations[i]);
        char rel[40];normalize(kb_relations[i],rel,sizeof(rel));n=strlen(rel);
        if(!strncmp(q,rel,n) && q[n]==' ') {
            snprintf(key,sizeof(key),"r:%s:%s",kb_relations[i],subject_alias(q+n+1));
            found=lookup(key,&kind,value);if(found) break;
        }
    }
    if(found<0 || (found && (kind<1 || kind>=3+KB_RELATION_COUNT))) {
        tiny_fast_close();reply->kind=FAST_ERROR;strcpy(reply->answer,"Plik TINY.KB jest uszkodzony lub nieczytelny.");return reply->kind;
    }
    if(!found) return FAST_NONE;
    reply->kind=FAST_FACT;
    if(kind<3) {
        strcpy(reply->answer,value);
        strcpy(reply->steps,kind==1?"Zrodlo: polska lokalna baza wiedzy.":"Zrodlo: oryginalne dane Tiny (EN).");
    } else relational_answer(kind,value,reply);
    return reply->kind;
}
