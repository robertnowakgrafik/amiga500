#include "tiny.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef __amigaos__
unsigned long __stack = 16384;
#endif

static void print_letter(int c, void *user)
{
    (void)user;
    putchar(c);
    fflush(stdout);
}

int main(int argc, char **argv)
{
    const char *path = "TINY.BIN", *question = NULL;
    char line[256], out[TINY_CONTEXT + 1];
    int i, info = 0, result = 0, limit = TINY_CONTEXT;
    for (i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--info")) info = 1;
        else if (!strcmp(argv[i], "--model") && i + 1 < argc) path = argv[++i];
        else if (!strcmp(argv[i], "--ask") && i + 1 < argc) question = argv[++i];
        else if (!strcmp(argv[i], "--max-tokens") && i + 1 < argc) {
            limit = atoi(argv[++i]);
            if (limit < 1 || limit > TINY_CONTEXT) return 2;
        } else {
            puts("TinyCLI [--model file] [--info] [--ask question] [--max-tokens 1..128]");
            return !strcmp(argv[i], "--help") ? 0 : 2;
        }
    }
    if (!tiny_load(path)) {
        fprintf(stderr, "TINY: %s\n", tiny_error());
        return 1;
    }
    if (info) {
        printf("TINY 2.1: %d layers, width %d, heap %lu bytes\n",
               tiny_layers(), tiny_width(), tiny_memory());
    } else if (question) {
        if (tiny_answer(question, out, limit, NULL, print_letter, NULL) < 0) {
            fprintf(stderr, "TINY: %s\n", tiny_error());
            result = 1;
        }
        putchar('\n');
    } else {
        puts("TINY 2.1 / Amiga 500. Ask in English. QUIT to exit.");
        while (printf("> "), fflush(stdout), fgets(line, sizeof(line), stdin)) {
            char q[TINY_MAXQ + 1];
            tiny_clean(line, q);
            if (!strcmp(q, "quit") || !strcmp(q, "exit")) break;
            if (tiny_answer(q, out, limit, NULL, print_letter, NULL) < 0) {
                fprintf(stderr, "TINY: %s\n", tiny_error());
                result = 1;
                break;
            }
            putchar('\n');
        }
    }
    tiny_free();
    return result;
}
