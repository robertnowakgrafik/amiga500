TINY 2.1 / STOCK AMIGA 500 / WORKBENCH 1.3
========================================

CURRENT VERSION: TINY FAST PL + LIVE
Enter / Szybko uses an exact native calculator or indexed local knowledge.
For example 2+5 returns 7 with Polish calculation steps, without loading
the neural model or database. Text answers identify their knowledge source.
Siec EN explicitly loads the original slow English model with LIVE charts.
Unknown fast-mode queries never silently start neural inference.
The Polish FAQ and calculator are separate additions, not Polish neural weights.
The knowledge index uses 54276 bytes; it is released before loading the neural
model. Network buffers are released when returning to fast mode.
Supported math: + - * / ^, parentheses, up to 6 decimal digits, exact bounded
32-bit rationals, integer powers -16..16. Try co to RAM or dlaczego jest dzien i noc.

Experimental offline port for a 68000 and 512 KB total RAM, no FPU.
Weights are streamed from disk. Engine allocations: 131456 bytes.
The program, C runtime, 16 KB stack and window need additional memory.
Close other applications. Do not copy the model to RAM:.

DIRECT BOOT
Use your own Kickstart 1.3 ROM, 68000, no FPU, 512 KB Chip RAM and no
Slow/Fast RAM. Insert Tiny-A500-512K-fast-pl-boot.adf in DF0 and start/reset.
All current ADF filenames contain the same bootable disk. Redownload if you have
the earlier data-only image. No separate Workbench disk is required.
The 1.x bootblock starts ROM AmigaDOS. S/Startup-Sequence sets a 16 KB
stack using our C/TinyStack command, then starts Tiny automatically.
Tiny opens the standard screen itself; no Workbench desktop is loaded.
Closing Tiny returns to CLI. Restart by typing: Tiny SYS:TINY.BIN

Boot your own Workbench 1.3, insert the TINY21 disk, open it and
double-click Tiny. Ask in English; Enter or Ask submits. Stop/Esc
cancels between chunks of work. The close gadget exits.
Leave the model disk inserted throughout inference.

Version 2.1q adds int16 attention activations with int32 dot products;
the original int8 weights are unchanged. Progress shows Read/Write,
layer, work within the current character, and elapsed minutes:seconds.
Stop/Esc is checked within disk reads and calculations. Input and Ask
are disabled while busy. Try the short prompt: 2+2

LIVE CHARTS (version 2.1q LIVE)
LAYERS shows mean ReLU activation for the current character, scaled
relative to the largest available layer value. Orange marks the current layer.
The header identifies the current character and position; NL is the question separator.
ATTN L/H shows the latest computed head's probability distribution over
context positions (prompt and generated answer). Up to 32 position bins;
heights are relative to the largest bin. Orange marks the largest attention.
PICK shows the last chosen character's softmax probability, plus a history
of 24 choices with a fixed 0-100% scale. Underscore means space; $ means end.
Character probability does not measure the factual correctness of the answer.
These are actual computation values, not a textual chain of reasoning.
New data redraws at most four times a second between major events. There
is no fake animation while waiting for disk. No extra screen or bitmap is
allocated. Statistics and plotting add some computation.

The ADF is a BOOTABLE 880 KB OFS (DOS0) disk. It includes no Kickstart
ROM or files from the Workbench disk. It can also be opened as a data
disk on an existing Workbench. Tiny and TINY.BIN belong in the same drawer.
No ixemul or mathieeesing*.library installation is needed.

CLI:
  TINY21:C/TinyStack
  TINY21:TinyCLI --model TINY21:TINY.BIN
  TinyCLI --info
  TinyCLI --ask "what is 7 times 8"
  TinyCLI --model TINY21:TINY.BIN --ask "plural of mouse"
  TinyCLI --max-tokens 16 --ask "what is the capital of peru"
With no options, TinyCLI is interactive; QUIT exits.

This will be extremely slow on a 7 MHz 68000 and DD drive. Each input
character reads approximately 348 KiB of weights; output reads 357 KiB.
One comparison on an emulated 68000 used 39.55% fewer CPU cycles than
the earlier port. It excludes real floppy latency, chip RAM contention
and GUI costs; it does not guarantee that reduction in actual wait time.
Real A500
latency has not been measured. Short questions reduce disk traffic.
The original English model can confidently give incorrect answers.
Input is limited to 72 ASCII characters; total context is 128.
Decoding is greedy/deterministic. Sound and speech are not included.

Verification: host answers compared with the unmodified DOS engine;
malformed files, cancellation, disk errors and cleanup tested under
ASan/UBSan. Native CLI executed with VAMOS / 68000 and a restricted
memory budget. Classic icon parsed, OFS disk checked with fsck.
The monitor passes ASan/UBSan and a native 68000 test with 224 KiB RAM:
attention sums, probability ranking, chosen characters, drawing bounds,
history rollover and identical answers with/without observation are checked.
The 1.x bootblock, checksum and startup file are checked. The stack
helper executes on an emulated 68000 with an initial 4 KB stack.
Full cold boot with an actual Kickstart 1.3 ROM has not been tested here.
The Intuition interface compiles against 1.3 headers but has NOT been
run on a full Workbench 1.3 installation or a physical A500.

Original: https://github.com/WollyMonjac/Tiny-2.1
Revision: 49348445661ffc9106f243afb4eafe499a51e286
Application: MIT (LICENSE); model attribution: DATA_LICENSES.md.
Static GCC runtime: GPLv3 + GCC Runtime Library Exception 3.1
(COPYING3, COPYING.RUNTIME, THIRD-PARTY.txt). Full source ZIP supplied.
