#include "fast.h"
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv)
{
    const char *database="TINY.KB", *question=NULL;
    char line[128]; FastReply reply;
    int i, result=0;
    for(i=1;i<argc;i++) {
        if(!strcmp(argv[i],"--model") && i+1<argc) database=argv[++i];
        else if(!strcmp(argv[i],"--database") && i+1<argc) database=argv[++i];
        else if(!strcmp(argv[i],"--ask") && i+1<argc) question=argv[++i];
        else {puts("TinyQuick [--database TINY.KB] [--ask pytanie]");return 2;}
    }
    do {
        if(!question) {
            printf("PL> ");fflush(stdout);
            if(!fgets(line,sizeof(line),stdin)) break;
            if(!strcmp(line,"quit\n")||!strcmp(line,"koniec\n")) break;
            question=line;
        }
        i=tiny_fast(question,database,&reply);
        if(!i) puts("Nie mam pewnej odpowiedzi w lokalnej bazie. Sprobuj doprecyzowac pytanie.");
        else {
            printf("[%s] %s\n",i==FAST_MATH?"KALKULATOR":i==FAST_ERROR?"BLAD":"BAZA WIEDZY",reply.answer);
            if(reply.steps[0]) {
                printf("%s",reply.steps);
                if(reply.steps[strlen(reply.steps)-1]!='\n') putchar('\n');
            }
            if(i==FAST_ERROR) result=1;
        }
        if(question!=line) break;
        question=NULL;
    } while(1);
    tiny_fast_close();return result;
}
