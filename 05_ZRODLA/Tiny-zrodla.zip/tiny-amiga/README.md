# Tiny FAST PL + LIVE na Amigę 500 bez rozszerzeń

Eksperymentalny port [WollyMonjac/Tiny-2.1](https://github.com/WollyMonjac/Tiny-2.1)
na **68000, 512 KB RAM i Workbench/Kickstart 1.3**. Działa lokalnie, używa
oryginalnego modelu i ma natywne okno Intuition oraz ikonę Workbencha.

Domyślny przycisk **Szybko** uruchamia teraz kalkulator lub lokalną bazę wiedzy.
`2+5` od razu daje `7`, z krótkimi krokami po polsku. Odpowiedzi tekstowe
obejmują wiele tematów i mają jawne źródło. Przycisk **Sieć EN** zachowuje
oryginalny angielski model oraz wykresy LIVE; ten tryb nadal jest wolny na A500.
Szybki tryb nie trenuje modelu ani nie udaje polskiego modelu rozumującego.

Szczegółowy opis zasobów i zakresu wiedzy: [JAK-DZIALA.md](JAK-DZIALA.md).
Pełny przeszukiwalny katalog po zbudowaniu paczki: `dist/Tiny-wiedza.html`.

W trybie Sieć EN wagi są doczytywane z dyskietki. Model i bufory zajmują **131 456 bajtów**;
program, stos, biblioteka C i okno wymagają dodatkowej pamięci. Zmniejszono także
bufory biblioteki C i połączono cache w jedną alokację. Wersję CLI sprawdzono na
emulowanym 68000 z budżetem 224 KiB, co zostawia zapas w maszynie z 512 KB.
To nie jest pomiar całego systemu Workbench.

## Uruchomienie

Gotowe pliki w `dist/`:

- `Tiny-A500-512K-fast-pl-boot.adf` — aktualna wersja: szybka matematyka, polska baza i opcjonalna sieć LIVE.
- `Tiny-A500-512K-live-boot.adf` — aktualna wersja z wykresami sieci na żywo.
- `Tiny-A500-512K-quantized-boot.adf` — aktualna wersja z kwantyzacją uwagi i częstszymi aktualizacjami postępu.
- `Tiny-A500-512K-boot.adf` — **bootowalna** dyskietka OFS/DOS0, 880 KB.
- `Tiny-A500-512K.adf` — ten sam aktualny obraz pod wcześniejszą nazwą.
- `Tiny-A500-512K.zip` — programy, ikona, model i instrukcje.
- `Tiny-A500-512K-source.zip` — pełne źródła i testy.
- `Tiny-wiedza.html` / `.csv` — katalog wszystkich danych źródłowych i polskich dodatków, do przeglądania na PC.

Wybierz swój ROM Kickstart 1.3, ustaw 68000, brak FPU, 512 KB Chip RAM, 0 Slow/Fast
RAM. Włóż `Tiny-A500-512K-fast-pl-boot.adf` do DF0 i uruchom lub zresetuj Amigę.
Tiny uruchamia się z `S/Startup-Sequence`, bez osobnej dyskietki Workbencha.
Wcześniej udostępniony ADF był niebootowalny — trzeba pobrać nowy obraz.

Bootblock dla 1.x inicjalizuje AmigaDOS z ROM-u. Nasze `C/TinyStack` ustawia
stos następnego polecenia na 16 KB, a Tiny sam otwiera standardowy ekran.
Nie jest ładowany pulpit Workbencha z ikonami. Po zamknięciu Tiny zostaje CLI;
można wpisać `Tiny SYS:TINY.BIN`, aby uruchomić program ponownie.

Pod już uruchomionym Workbenchem można otworzyć dysk TINY21 i kliknąć dwukrotnie
ikonę **Tiny**. Wpisz działanie lub pytanie, zatwierdź Enterem / **Szybko**.
Nieznane pytanie nie uruchamia automatycznie sieci. Do eksperymentu z oryginalnym
modelem wpisz pytanie po angielsku i wybierz **Sieć EN**.
Stop/Esc przerywa między porcjami obliczeń; zamknięcie okna kończy program.
Dysk z modelem musi pozostać w napędzie. Nie kopiuj modelu do RAM:.

W trybie sieci okno pokazuje etap czytania/pisania, warstwę, wewnętrzny postęp
i upływający czas. Odświeża stan również wewnątrz pojedynczego znaku, a Stop/Esc
działa między porcjami odczytu i obliczeń. Podczas liczenia pole pytania i Ask
są zablokowane. W trybie szybkim panel pokazuje wynik oraz rzeczywiste kroki
obliczeń albo źródło odpowiedzi z bazy. Wagi modelu są ładowane dopiero po
wybraniu Sieć EN. Przy przełączaniu trybów zwalniamy niepotrzebny duży bufor.

Obsługiwane działania: `+ - * / ^`, nawiasy i liczby z maksymalnie 6 cyframi
po kropce lub przecinku. Wyniki są dokładnymi ułamkami o liczniku/mianowniku
w zakresie 32 bitów; potęga przyjmuje wykładnik całkowity od -16 do 16.
Przykłady: `2+5`, `(2+3)*4`, `ile jest 8 razy 7`, `0,1+0,2`, `2^-2`.
Przykłady tekstu: `co to RAM`, `co to algorytm`, `dlaczego jest dzien i noc`,
`ile nog ma pajak`, `jaki jest symbol zlota`, `stolica polski`.
Na klasycznym Topazie najwygodniej pisać po polsku bez znaków diakrytycznych.

## Wykresy na żywo

Wersja `2.1q LIVE` dzieli okno na rozmowę i panel po prawej. Wykresy mają
bezpośrednie źródło w obliczeniach modelu:

- **LAYERS** — średnia aktywacja ReLU w warstwach dla aktualnego znaku,
  przeskalowana względem największej dostępnej wartości. Pomarańczowy kolor
  oznacza aktualną warstwę. Puste słupki czekają na obliczenie. Nagłówek podaje
  aktualnie przetwarzany znak i jego pozycję (`NL` to separator pytania).
- **ATTN L/H** — znormalizowany rozkład uwagi ostatniej obliczonej głowicy
  wskazanej warstwy. Pozycje obejmują dotychczasowy kontekst: pytanie i powstającą
  odpowiedź. Dłuższy kontekst grupowany jest w maksymalnie 32 słupki, skalowane
  do największej sumy prawdopodobieństw w grupie. Pomarańczowy słupek to maksimum.
- **PICK / LETTER CONFIDENCE** — prawdopodobieństwo softmax wybranej litery
  i historia ostatnich 24 wyborów. Skala pionowa wynosi 0–100%. `_` oznacza
  spację, `$` zakończenie odpowiedzi. Wartość dotyczy wyboru znaku, a nie
  prawdziwości całej odpowiedzi.

Panel odświeża się na podstawie nowych danych, z limitem czterech aktualizacji
na sekundę między głównymi zdarzeniami. Nie animuje wymyślonych danych podczas
oczekiwania na dysk. Nie jest zapisem tekstowego toku rozumowania modelu.
Rysuje bezpośrednio w istniejącym oknie, bez dodatkowego ekranu czy bitmapy.
Model i cache nadal alokują 131 456 bajtów; bufory panelu są niewielkie i statyczne.
Pomiar prawdopodobieństw i rysowanie mają dodatkowy koszt obliczeniowy.

CLI:

```text
TINY21:C/TinyStack
TINY21:TinyQuick --database TINY21:TINY.KB --ask "2+5"
TINY21:TinyCLI --model TINY21:TINY.BIN --ask "what is 7 times 8"
```

Szczegóły: [instrukcja PL](amiga/README.PL.txt), [instrukcja EN](amiga/README.EN.txt).

## Koszt zgodności ze stockową A500

Każdy znak pytania wymaga odczytania około 348 KiB wag, a znak odpowiedzi około
357 KiB. Pomijamy nieużywane obliczenia wyjściowe dla znaków pytania.
Procesor 68000 7 MHz i stacja DD będą bardzo wolne. Nie zmierzono rzeczywistego
czasu odpowiedzi na sprzęcie. Krótkie pytania ograniczają liczbę odczytów.

Najcięższe mnożenia używają wag int8, aktywacji int16 i akumulatora int32
(`MULS.W` na 68000). Dodatkowo kwantyzujemy zapytania uwagi oraz jej współczynniki
do int16 i mnożymy je z cache int8. Normalizacja, softmax oraz skale pozostają
zmiennoprzecinkowe. Wagi w dostarczonym modelu są już 8-bitowe i nie zmieniono ich.
Tabele są czytane większymi porcjami, w kolejności Q/K/V zgodnej z plikiem, co
ogranicza wywołania odczytu i ruch głowicy.
Kod dołącza programowe operacje IEEE z GCC oraz małe funkcje sqrt/exp. Nie wymaga
FPU, `mathieeesing*.library`, `ixemul.library` ani bibliotek systemu 2.x.

W pomiarze wersji kwantyzowanej sprzed dodania monitora, dla pytania
`how many people are in earth`, z limitem 4 znaków odpowiedzi, koszt
wykonania w emulatorze 68000 spadł z 4 933 719 116 do 2 982 647 982 cykli:
**39,55% mniej cykli CPU**, około 1,65 raza większa przepustowość. To pomiar
silnika CLI, bez rzeczywistych opóźnień stacji, współdzielenia Chip RAM i kosztu
GUI. Nie oznacza o 39,55% krótszego czasu na fizycznej A500. Zapis pomiaru:
[quantization-benchmark.json](tests/quantization-benchmark.json).

Odpowiedzi są deterministyczne (odpowiednik kreatywności 0 w DOS). Model pozostaje
angielski i może podawać błędne odpowiedzi. Pytania mają limit 72 znaków ASCII,
a wspólny kontekst pytania i odpowiedzi 128 znaków. Port nie zawiera dźwięku.

## Budowanie

Potrzebny jest `m68k-amigaos-gcc` z runtime `nix13`, np.
[AmigaPorts/m68k-amigaos-gcc](https://github.com/AmigaPorts/m68k-amigaos-gcc).
Użyta wersja: AmigaDev 16.2-rc25. Hostowe testy wymagają kompilatora C i Pythona 3;
testy natywne oraz tworzenie ADF wymagają `amitools`, `machine68k`, `greenlet`.

```sh
make all CROSS=/path/to/toolchain/bin/m68k-amigaos-
make test
make test-fast
make test-monitor
VAMOS=/path/to/venv/bin/vamos python3 tests/test_amiga.py
XDFTOOL=/path/to/venv/bin/xdftool make release CROSS=/path/to/toolchain/bin/m68k-amigaos-
```

`make host` buduje trzy wersje porównawcze: float z libm, szybszą int16 z libm
oraz int16 z lokalną matematyką. `TINY_RESIDENT` pozwala programiście wybrać
oryginalny sposób ładowania całego modelu do RAM; dostarczone binaria go nie używają.

## Weryfikacja i jej granice

- 48 pytań daje takie same odpowiedzi jak niezmieniony silnik DOS w trzech
  wariantach hostowych.
- Kalkulator i baza przechodzą ASan/UBSan oraz test natywny 68000 z budżetem
  192 KiB. Matematyka działa także przy nieistniejącym pliku modelu/bazy,
  na 68000 z budżetem 128 KiB. Testy obejmują kolejność działań, dokładne
  ułamki, kroki, przepełnienie, dzielenie przez zero i pytania z wielu dziedzin.
- Testy ASan/UBSan sprawdzają uszkodzone pliki, przerwanie i ponowne pytanie,
  błąd odczytu po otwarciu modelu oraz zwalnianie pamięci. Sprawdzają też
  przerwanie wewnątrz odczytu, mnożenia i uwagi oraz poprawne ponowne pytanie.
- Natywny plik Amiga HUNK wykonuje zestaw pytań w VAMOS, CPU 68000, RAM 224 KiB,
  stos 16 KiB. Test sprawdza też brak importów bibliotek IEEE/ixemul.
- Ikona to klasyczny DiskObject v1, dwa bitplany; sprawdzana parserem amitools.
  Obraz OFS przechodzi `xdftool fsck`.
- Monitor przeszedł testy ASan/UBSan i natywny test 68000 z budżetem 224 KiB.
  Test sprawdza sumy uwagi, ranking i zakres prawdopodobieństw, zgodność wybranych
  liter z wypisywanymi, historię, granice rysunku i identyczną odpowiedź przy
  włączonym/wyłączonym monitorze. `tools/preview_monitor.py` tworzy podgląd panelu
  z rzeczywistych danych modelu, przy użyciu tych samych funkcji rysujących
  (wymaga Pillow). To nie jest zrzut pełnego Workbencha.
- Bootblock jest wariantem `boot1x`; test sprawdza sumę kontrolną, ścieżki startowe
  i pliki wykonywalne. `TinyStack` działa w VAMOS na 68000 ze stosem początkowym
  4 KiB. Pełnego zimnego startu z rzeczywistym ROM-em 1.3 tutaj nie sprawdzono.
- **Okno Intuition skompilowano z API 1.3, lecz nie uruchomiono go na pełnym
  Workbenchu 1.3 ani fizycznej A500.** VAMOS nie emuluje tego interfejsu.

## Pochodzenie i licencje

Bazowy commit: `49348445661ffc9106f243afb4eafe499a51e286`.
Oryginalny opis zachowano w [README.UPSTREAM.md](README.UPSTREAM.md).
Kod aplikacji: [MIT](LICENSE). Atrybucja danych i modelu: [DATA_LICENSES.md](DATA_LICENSES.md).
Programowy runtime GCC ma GPLv3 z GCC Runtime Library Exception 3.1;
[notatka i licencje](third_party/gcc/README.md) są dołączone do paczek.
