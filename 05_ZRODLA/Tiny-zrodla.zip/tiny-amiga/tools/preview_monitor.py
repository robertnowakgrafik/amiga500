#!/usr/bin/env python3
"""Preview the real chart renderer using model telemetry captured by the C test.
This is a panel rendering, not a screenshot of an emulated Workbench.
"""
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

root = Path(__file__).resolve().parents[1]
subprocess.run(["cc", "-O2", "-std=c99", "-DEMIT_PREVIEW", "-I", "amiga",
                "amiga/tiny.c", "amiga/monitor.c", "tests/monitor_checks.c", "-lm", "-o", "build/monitor-preview"],
               cwd=root, check=True)
commands = subprocess.check_output(["build/monitor-preview"], cwd=root, text=True)
palette = [(0,85,170), (255,255,255), (0,0,34), (255,136,0)]
canvas = Image.new("RGB", (286,118), palette[0])
draw = ImageDraw.Draw(canvas)
font = ImageFont.truetype("DejaVuSansMono.ttf", 8)
for command in commands.splitlines():
    parts = command.split("\t")
    if parts[0] in ("F", "L"):
        x0,y0,x1,y1,pen = map(int, parts[1:])
        if parts[0] == "F": draw.rectangle((x0,y0,x1,y1), fill=palette[pen])
        else: draw.line((x0,y0,x1,y1), fill=palette[pen])
    elif parts[0] == "T":
        x,y,pen = map(int, parts[1:4])
        label = parts[4]
        box = font.getbbox(label)
        glyph = Image.new("RGB", (max(1,box[2]), max(1,box[3]-box[1])), palette[0])
        ImageDraw.Draw(glyph).text((0,-box[1]), label, font=font, fill=palette[pen])
        glyph = glyph.resize((len(label)*8,8), Image.Resampling.NEAREST)
        canvas.paste(glyph,(x,y-7))
out = root / "build/monitor-preview.png"
canvas.resize((1144,472), Image.Resampling.NEAREST).save(out)
print(out)
