#!/usr/bin/env python3
"""Build the binary ZIP, bootable Kickstart 1.x OFS disks, and source ZIP."""
import hashlib
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
DIST = ROOT / "dist"
DISK = DIST / "disk"
DIST.mkdir(exist_ok=True)
DISK.mkdir(exist_ok=True)
(DISK / "C").mkdir(exist_ok=True)
(DISK / "S").mkdir(exist_ok=True)
for src, name in [
    ("build/Tiny", "Tiny"), ("build/TinyCLI", "TinyCLI"), ("build/Tiny.info", "Tiny.info"),
    ("build/TinyQuick", "TinyQuick"), ("build/TINY.KB", "TINY.KB"),
    ("dos/TINY.BIN", "TINY.BIN"), ("amiga/README.PL.txt", "README.PL.txt"),
    ("amiga/README.EN.txt", "README.EN.txt"), ("LICENSE", "LICENSE"),
    ("DATA_LICENSES.md", "DATA_LICENSES.md"),
    ("third_party/gcc/COPYING3", "COPYING3"),
    ("third_party/gcc/COPYING.RUNTIME", "COPYING.RUNTIME"),
    ("third_party/gcc/README.md", "THIRD-PARTY.txt"),
    ("build/TinyStack", "C/TinyStack"),
    ("amiga/Startup-Sequence", "S/Startup-Sequence"),
]:
    shutil.copyfile(src, DISK / name)

binary = DIST / "Tiny-A500-512K.zip"
with zipfile.ZipFile(binary, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(DISK.rglob("*")):
        if p.is_file():
            z.write(p, p.relative_to(DISK).as_posix())

xdftool = os.environ.get("XDFTOOL") or shutil.which("xdftool")
if not xdftool:
    raise SystemExit("Binary ZIP built. Install amitools / set XDFTOOL to build the ADF.")
adf = DIST / "Tiny-A500-512K.adf"
if adf.exists():
    adf.unlink()
subprocess.run([xdftool, str(adf), "create", "+", "format", "TINY21", "DOS0"], check=True)
subprocess.run([xdftool, str(adf), "makedir", "C", "+", "makedir", "S"], check=True)
for p in sorted(DISK.rglob("*")):
    if p.is_file():
        subprocess.run([xdftool, str(adf), "write", str(p), p.relative_to(DISK).as_posix()], check=True)
subprocess.run([xdftool, str(adf), "protect", "Tiny", "rwed"], check=True)
subprocess.run([xdftool, str(adf), "protect", "TinyCLI", "rwed"], check=True)
subprocess.run([xdftool, str(adf), "protect", "TinyQuick", "rwed"], check=True)
subprocess.run([xdftool, str(adf), "protect", "C/TinyStack", "rwed"], check=True)
subprocess.run([xdftool, str(adf), "boot", "install", "boot1x"], check=True)
subprocess.run([xdftool, str(adf), "fsck"], check=True)
boot_adf = DIST / "Tiny-A500-512K-boot.adf"
shutil.copyfile(adf, boot_adf)
quantized_adf = DIST / "Tiny-A500-512K-quantized-boot.adf"
shutil.copyfile(adf, quantized_adf)
live_adf = DIST / "Tiny-A500-512K-live-boot.adf"
shutil.copyfile(adf, live_adf)
fast_adf = DIST / "Tiny-A500-512K-fast-pl-boot.adf"
shutil.copyfile(adf, fast_adf)

source = DIST / "Tiny-A500-512K-source.zip"
files = subprocess.check_output(
    ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"]
).decode().split("\0")
with zipfile.ZipFile(source, "w", zipfile.ZIP_DEFLATED) as z:
    for name in sorted(set(files) - {""}):
        p = ROOT / name
        if p.is_file():
            z.write(p, "tiny-amiga/" + name)
for path in (binary, adf, boot_adf, quantized_adf, live_adf, fast_adf, source):
    print(path.name, path.stat().st_size, hashlib.sha256(path.read_bytes()).hexdigest())
subprocess.run([sys.executable,str(ROOT/"tools/knowledge_catalog.py")],check=True)
