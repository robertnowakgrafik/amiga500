#!/usr/bin/env python3
"""Export every training fact and the authored PL FAQ as searchable HTML + CSV."""
from pathlib import Path
import csv
import importlib.util
import json

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("catalog_facts",ROOT/"training/gen2.py")
data=importlib.util.module_from_spec(spec);spec.loader.exec_module(data)
rows=[]
for relation,entries in data.REL.items():
    topic="Geografia" if relation in {"capital","state_capital","continent","currency","language","people","landlocked","subregion","domain"} else (
          "Chemia" if relation in {"symbol","atomic","kind","phase"} else (
          "Zwierzęta" if relation in {"class","legs","baby","sound","home","food","group","male","female"} else (
          "Kalendarz" if relation.startswith(("day_","month_")) else "Języki i słowa")))
    for subject,answer in entries:
        rows.append(dict(topic=topic,question=f"{relation}: {subject}",answer=answer,origin="Dane treningowe",aliases=""))
for subject,neighbors in data.BORDERS.items():
    rows.append(dict(topic="Geografia",question="borders: "+subject,answer=", ".join(neighbors) or "Brak granic lądowych",origin="Dane treningowe",aliases=""))
themes={"body":"Ciało człowieka","dos":"DOS","food":"Żywność","history":"Historia","maths":"Matematyka", "more":"Różne",
        "nature":"Przyroda","science":"Nauka","shapes":"Kształty","space":"Kosmos","sport":"Sport", "talk":"Rozmowa",
        "tech":"Komputery i programowanie","time":"Czas","world":"Świat"}
for fact in data.TXT:
    questions=fact["train_q"]+fact["test_q"]
    rows.append(dict(topic=themes.get(fact["theme"],fact["theme"]),question=questions[0],answer=" / ".join(fact["answers"]),
                     origin="Dane treningowe",aliases=" | ".join(questions[1:])))
for line in (ROOT/"training/polish_faq.tsv").read_text().splitlines():
    if not line or line.startswith("#"):continue
    questions,answer=line.split("\t");questions=questions.split("|")
    rows.append(dict(topic="Polska baza",question=questions[0],answer=answer,origin="Nowa baza PL",aliases=" | ".join(questions[1:])))
rows.sort(key=lambda r:(r["origin"]!="Nowa baza PL",r["topic"],r["question"]))
out=ROOT/"dist";out.mkdir(exist_ok=True)
with (out/"Tiny-wiedza.csv").open("w",encoding="utf-8-sig",newline="") as f:
    w=csv.DictWriter(f,fieldnames=["topic","question","answer","origin","aliases"]);w.writeheader();w.writerows(rows)
blob=json.dumps(rows,ensure_ascii=True).replace("</","<\\/")
page=r'''<!doctype html><html lang="pl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Co wie Tiny — pełny katalog danych</title><style>
*{box-sizing:border-box}body{margin:0;background:#f2f4f6;color:#172732;font:16px/1.5 system-ui,sans-serif}main{max-width:1250px;margin:auto;padding:36px 22px}
h1{font-size:clamp(28px,4vw,45px);line-height:1.1;margin:0 0 18px}p{max-width:950px}.note{border-left:4px solid #167a72;padding:12px 18px;background:#e3f0ed}
.stats{display:flex;gap:14px;flex-wrap:wrap;margin:24px 0}.stats div{background:white;padding:16px 24px;border-radius:10px;border:1px solid #d8e0e5}.stats b{display:block;font-size:29px;color:#14665f}
.filters{position:sticky;top:0;background:#f2f4f6;padding:14px 0;display:flex;gap:10px;flex-wrap:wrap}input,select,button{font:inherit;padding:11px 14px;border:1px solid #bccbd3;border-radius:7px;background:white}input{flex:1;min-width:240px}button{cursor:pointer;background:#14665f;color:white}
.table{overflow:auto;background:white;border:1px solid #d8e0e5;border-radius:10px}table{border-collapse:collapse;width:100%}th,td{text-align:left;vertical-align:top;padding:13px 15px;border-bottom:1px solid #e3e8eb}th{background:#e9eef1}td:first-child{width:155px}td:nth-child(2){width:30%}small{display:block;color:#58707d;margin-top:7px}.tag{font-size:12px;text-transform:uppercase;color:#14665f;font-weight:700}#count{font-weight:600}footer{margin-top:28px;font-size:14px;color:#526974}
</style><main><div class="tag">Amiga 500 · Tiny 2.1 · katalog offline</div><h1>Co jest w danych Tiny?</h1>
<p>Pełny spis materiału treningowego oryginalnego modelu i nowej polskiej bazy. Możesz wyszukiwać słowa, pytania, nazwy państw, zwierząt i pierwiastków.</p>
<div class="note">To katalog danych źródłowych, nie lista gwarantowanych umiejętności sieci. Model koduje wyuczone zależności w wagach i może odpowiadać błędnie. Nowy tryb <b>Szybko</b> odczytuje lokalną bazę; kalkulator wykonuje działania bez modelu. Polska baza jest osobnym dodatkiem, a nie nowymi polskimi wagami Tiny.</div>
<div class="stats"><div><b>2 872</b>wpisy tabelaryczne treningu</div><div><b>626</b>zestawy pytań i odpowiedzi</div><div><b>194</b>listy granic państw</div><div><b>86</b>nowe polskie odpowiedzi</div></div>
<div class="filters"><input id="search" placeholder="Szukaj: oxygen, pajak, fotosynteza, RAM…" aria-label="Szukaj"><select id="topic" aria-label="Temat"><option value="">Wszystkie tematy</option></select><select id="origin" aria-label="Pochodzenie"><option value="">Oba źródła</option><option>Dane treningowe</option><option>Nowa baza PL</option></select></div>
<p id="count"></p><div class="table"><table><thead><tr><th>Temat</th><th>Pytanie / relacja</th><th>Dane / odpowiedź</th></tr></thead><tbody id="results"></tbody></table></div><p><button id="more">Pokaż kolejne 200</button></p>
<footer>Trening: WollyMonjac/Tiny-2.1. Część danych pochodzi z mledoze/countries (ODbL) i Periodic-Table-JSON (CC BY-SA 3.0). Szczegóły znajdują się w DATA_LICENSES.md dołączonym do programu. Polska baza i kalkulator nie zmieniają oryginalnego modelu neuronowego. Katalog działa bez połączenia z internetem.</footer></main>
<script>const rows=__CATALOG_DATA__;const $=id=>document.getElementById(id);let limit=200;const plain=s=>s.toLowerCase().replaceAll('ł','l').normalize('NFD').replace(/[\u0300-\u036f]/g,'');rows.forEach(r=>r.search=plain(Object.values(r).join(' ')));
[...new Set(rows.map(r=>r.topic))].sort((a,b)=>a.localeCompare(b,'pl')).forEach(t=>{let o=document.createElement('option');o.value=t;o.textContent=t;$('topic').append(o)});
function render(){const terms=plain($('search').value).split(/\s+/).filter(Boolean);const filtered=rows.filter(r=>(!$('topic').value||r.topic===$('topic').value)&&(!$('origin').value||r.origin===$('origin').value)&&terms.every(t=>r.search.includes(t)));$('count').textContent=`Znaleziono ${filtered.length.toLocaleString('pl-PL')} wpisów. Wyświetlono ${Math.min(limit,filtered.length)}.`;$('results').replaceChildren();filtered.slice(0,limit).forEach(r=>{let tr=document.createElement('tr');[r.topic,r.question,r.answer].forEach((s,i)=>{let td=document.createElement('td');td.textContent=s;if(i===0){let sm=document.createElement('small');sm.textContent=r.origin;td.append(sm)}if(i===1&&r.aliases){let sm=document.createElement('small');sm.textContent='Inne pytania: '+r.aliases;td.append(sm)}tr.append(td)});$('results').append(tr)});$('more').hidden=limit>=filtered.length}
['search','topic','origin'].forEach(id=>$(id).addEventListener('input',()=>{limit=200;render()}));$('more').onclick=()=>{limit+=200;render()};render();</script></html>'''
(out/"Tiny-wiedza.html").write_text(page.replace('__CATALOG_DATA__',blob),encoding="utf-8")
print(f"Catalog: {len(rows)} entries -> {out/'Tiny-wiedza.html'}")
