/* Exercise the actual helper against native AmigaDOS process/CLI structures. */
#define main tiny_set_boot_stack
#include "../amiga/boot_stack.c"
#undef main

int main(void)
{
    struct Process *process = (struct Process *)FindTask(NULL);
    BPTR saved_cli = process->pr_CLI;
    struct CommandLineInterface *cli = (struct CommandLineInterface *)BADDR(saved_cli);
    int result;
    if (!cli) return 1;
    cli->cli_DefaultStack = 1000;
    if (tiny_set_boot_stack() || cli->cli_DefaultStack * sizeof(ULONG) != 16384)
        return 2;
    process->pr_CLI = 0;
    result = tiny_set_boot_stack();
    process->pr_CLI = saved_cli;
    return result == 20 ? 0 : 3;
}
