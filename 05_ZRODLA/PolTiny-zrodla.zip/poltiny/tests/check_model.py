import struct,math,json,hashlib,subprocess,tempfile
from pathlib import Path
R=Path(__file__).resolve().parents[1];b=(R/'build/POLTINY.BIN').read_bytes()
assert b[:4]==b'TPL1';d,l,h,hid,v=struct.unpack_from('<5H',b,4)
assert (d,l,h,hid,v)==(128,4,4,384,115)
matrices=v*d+128*d+l*(4*d*d+2*d*hid);gains=(l*2+1)*d
assert matrices+gains==687616
off=14
def matrix(rows,cols):
 global off
 for i in range(rows):
  scale=struct.unpack_from('<f',b,off)[0];assert math.isfinite(scale) and scale>0;off+=4+cols
def gain():
 global off
 assert all(math.isfinite(x) for x in struct.unpack_from(f'<{d}f',b,off));off+=4*d
matrix(v,d);matrix(128,d)
for i in range(l):
 gain()
 for j in range(4):matrix(d,d)
 gain();matrix(hid,d);matrix(d,hid)
gain();assert off==len(b)==708442
train=[json.loads(x) for x in (R/'training/train.jsonl').read_text().splitlines()];valid=[json.loads(x) for x in (R/'training/valid.jsonl').read_text().splitlines()]
assert not ({x['q'] for x in train}&{x['q'] for x in valid})
assert all(len(x['q'])<=72 and len(x['q'])+len(x['a'])+2<=128 for x in train+valid)
e=json.loads((R/'training/evaluation.json').read_text());assert e['model_sha256']==hashlib.sha256(b).hexdigest()
with tempfile.TemporaryDirectory() as td:
 for name,data in [('truncated',b[:100]),('old-magic',b'TNY2'+b[4:]),('bad-vocab',b[:12]+b'\x61\0'+b[14:]),('trailing',b+b'\0')]:
  p=Path(td)/name;p.write_bytes(data)
  run=subprocess.run([str(R/'build/poltiny-host'),'--model',str(p),'--info'],capture_output=True)
  assert run.returncode==1,(name,run.stdout,run.stderr)
print('Model dimensions, all scales, parameter count, test split, result hash and malformed files verified')
