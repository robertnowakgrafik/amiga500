#include "tiny.h"
#include "polish.h"
#include "fast.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define CHECK(x) do{if(!(x)){fprintf(stderr,"check failed %d: %s\n",__LINE__,#x);return 1;}}while(0)
static int calls;
static int stop(int k,int d,int t,void *u){(void)k;(void)d;(void)t;(void)u;return ++calls<40;}
int main(int argc,char **argv)
{
    char local[256],utf8[512],q[73],out[129];int i;FastReply r;
    for(i=2;i<115;i++)CHECK(pol_token(pol_letter(i))==i);
    pol_local("Zażółć gęślą jaźń",local,sizeof(local));pol_utf8(local,utf8,sizeof(utf8));CHECK(!strcmp(utf8,"Zażółć gęślą jaźń"));
    tiny_clean("CZEŚĆ",q);pol_utf8(q,utf8,sizeof(utf8));CHECK(!strcmp(utf8,"cześć"));
    CHECK(tiny_math("2+5",&r)==FAST_MATH&&!strcmp(r.answer,"7"));
    CHECK(tiny_math("(12-3)/4",&r)==FAST_MATH&&!strcmp(r.answer,"2.25"));
    CHECK(tiny_math("2^8",&r)==FAST_MATH&&!strcmp(r.answer,"256"));
    CHECK(tiny_math("1/0",&r)==FAST_ERROR);CHECK(tiny_math("co to jest procesor",&r)==FAST_NONE);
    CHECK(!tiny_load("missing-model.bin"));CHECK(tiny_memory()==0);
    if(argc>1){CHECK(tiny_load(argv[1]));CHECK(tiny_memory()==190464);tiny_set_work(stop,NULL);CHECK(tiny_answer("a",out,1,NULL,NULL,NULL)==-1);tiny_set_work(NULL,NULL);tiny_free();CHECK(tiny_memory()==0);}
    puts("PolTiny checks OK");return 0;
}
