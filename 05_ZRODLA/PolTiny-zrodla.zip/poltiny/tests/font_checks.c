#include "plfont.h"
#include "polish.h"
#include <string.h>
static unsigned char data[8*256];
static unsigned long loc[257];
int main(void){struct TextFont rom,*pl;int i,y;memset(&rom,0,sizeof(rom));
    rom.tf_YSize=8;rom.tf_XSize=8;rom.tf_LoChar=0;rom.tf_HiChar=255;rom.tf_Modulo=256;
    rom.tf_CharData=data;rom.tf_CharLoc=loc;
    for(i=0;i<257;i++)loc[i]=((unsigned long)(i*8)<<16)|8;
    loc[256]=loc['?']; /* ROM fonts may share the undefined glyph's bitmap. */
    for(y=0;y<8;y++)for(i=0;i<256;i++)data[y*256+i]=y==3?0x7e:0x42;
    pl=pol_font(&rom);if(pl==&rom||pl->tf_Modulo!=258||pl->tf_HiChar!=255)return 1;
    for(i=0;i<18;i++){int different=0;for(y=0;y<8;y++)if(((unsigned char*)pl->tf_CharData)[y*258+pol_letter(97+i)]!=data[y*256+'a'])different=1;if(!different)return 2;}
    return 0;}
