/* Small DOM contract checks, runnable with Node without a browser. */
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync('dist/PolTiny-wiedza.html','utf8'),script=html.match(/<script>([\s\S]*?)<\/script>/)[1];
function field(){return {value:'',textContent:'',handlers:{},addEventListener(n,f){this.handlers[n]=f}}}
const search=field(),topic=field(),count=field(),rows=[{textContent:'Polska Warszawa',dataset:{topic:'stolice'}},{textContent:'Wodór H',dataset:{topic:'chemia'}},{textContent:'RAM pamięć',dataset:{topic:'komputery'}}];
const ctx=vm.createContext({document:{querySelectorAll(){return rows},querySelector(id){return {'#search':search,'#topic':topic,'#count':count}[id]}}});
vm.runInContext(script,ctx);assert(rows.every(x=>!x.hidden));search.value='WODÓR';search.handlers.input();assert.deepStrictEqual(rows.map(x=>x.hidden),[true,false,true]);topic.value='stolice';topic.handlers.change();assert(rows.every(x=>x.hidden));search.value='';search.handlers.input();assert.deepStrictEqual(rows.map(x=>x.hidden),[false,true,true]);
const deck=fs.readFileSync('dist/PolTiny-raport.html','utf8');let scrolled=-1;
const slides=Array.from({length:8},(_,i)=>({scrollIntoView(){scrolled=i}})),fields={'#prev':field(),'#next':field(),'#position':field()};let key;
const c=vm.createContext({document:{querySelectorAll(){return slides},querySelector(id){return fields[id]},addEventListener(n,f){key=f}}});
vm.runInContext(deck.match(/<script>([\s\S]*?)<\/script>/)[1],c);fields['#next'].onclick();assert.equal(scrolled,1);key({key:'ArrowLeft'});assert.equal(scrolled,0);for(let i=0;i<20;i++)fields['#next'].onclick();assert.equal(scrolled,7);assert.equal(fields['#position'].textContent,'8 / 8');console.log('Catalog filtering and presentation navigation passed');
