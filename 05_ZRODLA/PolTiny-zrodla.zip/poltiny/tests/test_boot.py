import struct,subprocess,tempfile,hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];adf=R/'dist/PolTiny-A500-512K-boot.adf';data=adf.read_bytes()
assert len(data)==901120 and data[:4]==b'DOS\0'
assert b'dos.library\0' in data[:1024]
s=0
for w in struct.unpack('>256I',data[:1024]):s+=w;s=(s&0xffffffff)+(s>>32)
assert s==0xffffffff
with tempfile.TemporaryDirectory() as td:
    for name,src in [('PolTiny','build/PolTiny'),('POLTINY.BIN','build/POLTINY.BIN'),('S/Startup-Sequence','amiga/Startup-Sequence'),('C/TinyStack','build/TinyStack')]:
        out=Path(td)/Path(name).name
        subprocess.run(['/workspace/toolchains/venv/bin/xdftool',str(adf),'read',name,str(out)],check=True,capture_output=True)
        assert out.read_bytes()==(R/src).read_bytes(),name
assert (R/'amiga/Startup-Sequence').read_bytes()==b'SYS:C/TinyStack\nSYS:PolTiny SYS:POLTINY.BIN\n'
print('Bootblock 1.x, OFS, checksum and extracted binaries/model verified')
