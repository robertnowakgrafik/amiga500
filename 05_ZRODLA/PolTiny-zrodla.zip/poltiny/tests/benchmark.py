import subprocess,re,json,time
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def run(name,args,ram=320):
    log=R/f'build/benchmark-{name}.log';t=time.monotonic()
    p=subprocess.run(['/workspace/toolchains/venv/bin/vamos','--vols-base-dir','/tmp/poltiny-vamos','-l','machine:info','-L',str(log),'-C68000',f'-m{ram}','-s16','--','build/PolTiny',*args],cwd=R,capture_output=True,check=True)
    cycles=int(re.findall(r'total_cycles=(\d+)',log.read_text())[-1]);out=p.stdout.decode('iso8859-2').strip()
    return dict(cycles=cycles,cpu_seconds=cycles/7090000,output=out,host_seconds=time.monotonic()-t)
math=run('math',['--model','missing.bin','--ask','2+5'],192);assert math['output']=='7'
neural=run('neural',['--model','build/POLTINY.BIN','--neural','--ask','a','--max-tokens','1'])
parity=run('parity',['--model','build/POLTINY.BIN','--neural','--ask','stolica polski'])
host=subprocess.check_output([str(R/'build/poltiny-host'),'--model',str(R/'build/POLTINY.BIN'),'--neural','--ask','stolica polski'],text=True).strip()
assert parity['output']==host=='Warszawa.',(host,parity)
result=dict(clock_hz=7090000,math_cycles=math['cycles'],math_cpu_seconds=math['cpu_seconds'],neural_cycles=neural['cycles'],neural_cpu_seconds=neural['cpu_seconds'],case='a; max-tokens=1; includes model loading and two transformer positions',excludes='physical floppy latency, full AmigaOS and GUI',native_vs_host=parity,math=math,neural=neural)
(R/'tests/benchmark.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
