"""Portable TPL1 byte order matches the Amiga loader, row by row."""
import struct, json, argparse
from pathlib import Path
import torch,numpy as np
from model import Model,VOCAB
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--out',default=str(R.parent/'build/POLTINY.BIN'));a=p.parse_args()
ck=torch.load(R/'checkpoint.pt',map_location='cpu',weights_only=False);m=Model(**ck['cfg']);m.load_state_dict(ck['model'])
Path(a.out).parent.mkdir(parents=True,exist_ok=True)
with open(a.out,'wb') as f:
    cfg=ck['cfg'];f.write(b'TPL1'+struct.pack('<5H',cfg['d'],cfg['layers'],cfg['heads'],cfg['hid'],VOCAB))
    def matrix(w):
        w=w.detach().numpy().astype(np.float32);s=np.maximum(abs(w).max(1),1e-20)/127
        q=np.clip(np.rint(w/s[:,None]),-127,127).astype('i1')
        for x,r in zip(s,q):f.write(struct.pack('<f',x));f.write(r.tobytes())
    def gain(w):f.write(w.detach().numpy().astype('<f4').tobytes())
    matrix(m.emb.weight);matrix(m.pos.weight)
    for b in m.blocks:
        gain(b.n1.g)
        for w in [b.q,b.k,b.v,b.o]:matrix(w.weight)
        gain(b.n2.g);matrix(b.f1.weight);matrix(b.f2.weight)
    gain(m.nf.g)
print(json.dumps(dict(step=ck['step'],parameters=sum(p.numel() for p in m.parameters()),file_bytes=Path(a.out).stat().st_size)))
