"""PolTiny: a character transformer derived from Tiny 2.1 (MIT).
All trainable weights start from a reproducible random initialization.
"""
import math
import torch
from torch import nn
from torch.nn import functional as F

LETTERS="ąćęłńóśźżĄĆĘŁŃÓŚŹŻ"
ALPHABET="\n"+"".join(chr(i) for i in range(32,127))+LETTERS
VOCAB=len(ALPHABET)+1
CTX=128
TOKEN={c:i+1 for i,c in enumerate(ALPHABET)}
def encode(s): return [TOKEN[c] for c in s]
def decode(ids): return "".join(ALPHABET[i-1] for i in ids if i>1)

class Norm(nn.Module):
    def __init__(self,d):super().__init__();self.g=nn.Parameter(torch.ones(d))
    def forward(self,x):return x*torch.rsqrt(x.float().pow(2).mean(-1,keepdim=True)+1e-5)*self.g

class Block(nn.Module):
    def __init__(self,d,h,hid):
        super().__init__();self.h=h;self.d=d
        self.n1=Norm(d);self.n2=Norm(d)
        self.q=nn.Linear(d,d,bias=False);self.k=nn.Linear(d,d,bias=False)
        self.v=nn.Linear(d,d,bias=False);self.o=nn.Linear(d,d,bias=False)
        self.f1=nn.Linear(d,hid,bias=False);self.f2=nn.Linear(hid,d,bias=False)
    def forward(self,x):
        b,t,d=x.shape;z=self.n1(x)
        split=lambda a:a.view(b,t,self.h,d//self.h).transpose(1,2)
        a=F.scaled_dot_product_attention(split(self.q(z)),split(self.k(z)),split(self.v(z)),is_causal=True)
        x=x+self.o(a.transpose(1,2).reshape(b,t,d))
        return x+self.f2(F.relu(self.f1(self.n2(x))))

class Model(nn.Module):
    def __init__(self,d=128,layers=4,heads=4,hid=384):
        super().__init__();self.cfg=dict(d=d,layers=layers,heads=heads,hid=hid)
        self.emb=nn.Embedding(VOCAB,d);self.pos=nn.Embedding(CTX,d)
        self.blocks=nn.ModuleList([Block(d,heads,hid) for _ in range(layers)])
        self.nf=Norm(d)
        nn.init.normal_(self.emb.weight,std=.05);nn.init.normal_(self.pos.weight,std=.05)
        for b in self.blocks:
            for m in (b.q,b.k,b.v,b.o,b.f1,b.f2):nn.init.normal_(m.weight,std=.5/math.sqrt(m.in_features))
    def forward(self,idx):
        x=self.emb(idx)+self.pos(torch.arange(idx.shape[1],device=idx.device))
        for b in self.blocks:x=b(x)
        return self.nf(x)@self.emb.weight.t()
