"""Measure actual quantized C runtime, including its int8 KV cache."""
import json,subprocess,time,collections,argparse,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--model',default=str(R.parent/'build/POLTINY.BIN'));p.add_argument('--sample',type=int,default=0);p.add_argument('--output',default='evaluation.json');a=p.parse_args()
result={'model_sha256':hashlib.sha256(Path(a.model).read_bytes()).hexdigest(),'definition':'Exact answer including diacritics and punctuation, greedy quantized C engine; no calculator/lookup','sets':{}}
for split in ['train','valid']:
    rows=[json.loads(s) for s in (R/f'{split}.jsonl').read_text().splitlines()]
    if a.sample:rows=rows[::max(1,len(rows)//a.sample)][:a.sample]
    t=time.monotonic();proc=subprocess.run([str(R.parent/'build/poltiny-host'),'--model',a.model,'--neural','--batch'],input='\n'.join(r['q'] for r in rows)+'\n',text=True,capture_output=True,check=True)
    answers=proc.stdout.splitlines()
    if len(answers)!=len(rows):raise ValueError((len(rows),len(answers),proc.stderr))
    by=collections.defaultdict(lambda:[0,0]);examples=[];passed=0
    for r,answer in zip(rows,answers):
        ok=answer==r['a'];passed+=ok;by[r['topic']][0]+=ok;by[r['topic']][1]+=1
        examples.append(dict(q=r['q'],expected=r['a'],actual=answer,correct=ok,topic=r['topic']))
    result['sets'][split]=dict(correct=passed,total=len(rows),accuracy=passed/len(rows),host_seconds=time.monotonic()-t,topics=dict(by),answers=examples)
    print(split,passed,len(rows),round(100*passed/len(rows),2),flush=True)
(R/a.output).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
