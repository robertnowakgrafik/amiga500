import os, time, json, random, argparse, math, struct, copy
from pathlib import Path
import numpy as np
import torch
from torch.nn import functional as F
from model import Model, encode, decode, VOCAB
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--steps',type=int,default=16000);p.add_argument('--resume',action='store_true');p.add_argument('--batch',type=int,default=48);args=p.parse_args()
torch.set_num_threads(2);torch.manual_seed(173);random.seed(173)
rows=[json.loads(x) for x in (ROOT/'train.jsonl').read_text().splitlines()]
buckets={}
for r in rows:
    ids=encode(r['q']+'\n'+r['a']+'\n');length=((len(ids)+7)//8)*8
    buckets.setdefault(length,[]).append((ids,len(r['q'])))
lengths=list(buckets);weights=[len(buckets[k]) for k in lengths]
model=Model();optim=torch.optim.AdamW(model.parameters(),lr=.0018,weight_decay=.01)
start=0;elapsed_prior=0
if args.resume:
    ck=torch.load(ROOT/'checkpoint.pt',weights_only=False);model.load_state_dict(ck['model']);optim.load_state_dict(ck['optimizer']);start=ck['step'];elapsed_prior=ck['elapsed']
def export():
    out=ROOT.parent/'build/POLTINY.BIN'
    out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('wb') as f:
        f.write(b'TPL1'+struct.pack('<5H',128,4,4,384,VOCAB))
        def matrix(w):
            a=w.detach().numpy().astype(np.float32);s=np.maximum(abs(a).max(axis=1),1e-20)/127
            q=np.clip(np.rint(a/s[:,None]),-127,127).astype('i1')
            for sc,row in zip(s,q):f.write(struct.pack('<f',sc));f.write(row.tobytes())
        def gain(w):f.write(w.detach().numpy().astype('<f4').tobytes())
        matrix(model.emb.weight);matrix(model.pos.weight)
        for b in model.blocks:
            gain(b.n1.g)
            for m in [b.q,b.k,b.v,b.o]:matrix(m.weight)
            gain(b.n2.g)
            for m in [b.f1,b.f2]:matrix(m.weight)
        gain(model.nf.g)
    return out.stat().st_size
def save(step,elapsed):
    torch.save(dict(model=model.state_dict(),optimizer=optim.state_dict(),step=step,elapsed=elapsed,cfg=model.cfg),ROOT/'checkpoint.pt')
    size=export()
    (ROOT/'run.json').write_text(json.dumps(dict(seed=173,step=step,elapsed_seconds=elapsed,parameters=sum(x.numel() for x in model.parameters()),file_bytes=size,cfg=model.cfg,batch=args.batch,torch=torch.__version__),indent=2))
t0=time.monotonic();log=(ROOT/'loss.jsonl').open('a' if args.resume else 'w',buffering=1);running=0
for step in range(start,args.steps):
    n=random.choices(lengths,weights)[0];x=torch.zeros((args.batch,n),dtype=torch.long);mask=torch.zeros((args.batch,n-1))
    for j,(ids,q) in enumerate(random.choices(buckets[n],k=args.batch)):
        x[j,:len(ids)]=torch.tensor(ids);mask[j,q:len(ids)-1]=1
    lr=.0018*min(1,(step+1)/150)
    if step>args.steps*.8:lr*=.15+.85*.5*(1+math.cos(math.pi*(step/args.steps-.8)/.2))
    for g in optim.param_groups:g['lr']=lr
    logits=model(x[:,:-1]);losses=F.cross_entropy(logits.reshape(-1,VOCAB),x[:,1:].reshape(-1),reduction='none').view_as(mask)
    loss=(losses*mask).sum()/mask.sum();optim.zero_grad(set_to_none=True);loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1);optim.step();running+=loss.item()
    if (step+1)%100==0:
        elapsed=elapsed_prior+time.monotonic()-t0
        record=dict(step=step+1,loss=running/100,elapsed_seconds=elapsed,steps_per_second=(step+1-start)/(time.monotonic()-t0))
        log.write(json.dumps(record)+'\n');print(json.dumps(record),flush=True);running=0
    if (step+1)%1000==0:save(step+1,elapsed_prior+time.monotonic()-t0)
save(args.steps,elapsed_prior+time.monotonic()-t0)
