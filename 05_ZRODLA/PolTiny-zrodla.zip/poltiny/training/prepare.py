"""Deterministic Polish instruction corpus; no external text generator required."""
import json, hashlib, unicodedata, collections
from pathlib import Path
from model import encode, ALPHABET
ROOT=Path(__file__).resolve().parent
def plain(s):
    return ''.join(c for c in unicodedata.normalize('NFD',s.replace('ł','l').replace('Ł','L')) if unicodedata.category(c)!='Mn')
def clean(s):
    return ''.join(c if c in ALPHABET else plain(c) for c in s).strip()
items=[]
def add(topic,qs,a):
    qs=list(dict.fromkeys(clean(q.lower()) for q in qs))
    a=clean(a)
    qs=[q for q in qs if len(q)<=72 and len(q)+len(a)+2<=128]
    if qs:items.append(dict(topic=topic,questions=qs,answer=a))
for line in (ROOT/'polish_core.tsv').read_text().splitlines():
    if not line or line.startswith('#'):continue
    t,q,a=line.split('\t');add(t,q.split('|'),a)
countries=json.loads((ROOT/'sources/countries.json').read_text())
names={c['name']['common']:c['translations']['pol']['common'] for c in countries}
names.update({'Ivory Coast':'Wybrzeże Kości Słoniowej','Czech Republic':'Czechy','Swaziland':'Eswatini','Turkey':'Turcja','East Timor':'Timor Wschodni'})
gen=dict(x.split(':') for x in 'Polska:Polski|Niemcy:Niemiec|Francja:Francji|Włochy:Włoch|Hiszpania:Hiszpanii|Portugalia:Portugalii|Grecja:Grecji|Rosja:Rosji|Ukraina:Ukrainy|Czechy:Czech|Słowacja:Słowacji|Austria:Austrii|Węgry:Węgier|Litwa:Litwy|Łotwa:Łotwy|Estonia:Estonii|Szwecja:Szwecji|Norwegia:Norwegii|Finlandia:Finlandii|Dania:Danii|Belgia:Belgii|Holandia:Holandii|Szwajcaria:Szwajcarii|Wielka Brytania:Wielkiej Brytanii|Irlandia:Irlandii|Chiny:Chin|Japonia:Japonii|Indie:Indii|Brazylia:Brazylii|Kanada:Kanady|Australia:Australii|Egipt:Egiptu|Turcja:Turcji|Stany Zjednoczone:Stanów Zjednoczonych|Rumunia:Rumunii|Bułgaria:Bułgarii|Chorwacja:Chorwacji|Serbia:Serbii|Słowenia:Słowenii'.split('|'))
cap=dict(x.split(':') for x in 'Warsaw:Warszawa|London:Londyn|Paris:Paryż|Rome:Rzym|Vienna:Wiedeń|Moscow:Moskwa|Beijing:Pekin|Lisbon:Lizbona|Athens:Ateny|Prague:Praga|Budapest:Budapeszt|Brussels:Bruksela|Copenhagen:Kopenhaga|Stockholm:Sztokholm|Vilnius:Wilno|Riga:Ryga|Kyiv:Kijów|Kiev:Kijów|Bucharest:Bukareszt|Sofia:Sofia|Belgrade:Belgrad|Cairo:Kair|Tokyo:Tokio|Madrid:Madryt|Washington, D.C.:Waszyngton|Washington:Waszyngton|Nicosia:Nikozja|Luxembourg:Luksemburg|Vatican City:Watykan'.split('|'))
cont={'Europe':'Europa','Asia':'Azja','Africa':'Afryka','North America':'Ameryka Północna','South America':'Ameryka Południowa','Oceania':'Oceania'}
for line in (ROOT/'sources/geo.tsv').read_text().splitlines():
    rel,c,v=line.split('\t')
    if c not in names:continue
    n=names[c]
    if rel=='capital':
        qs=[f'stolica kraju {n}',f'jaka jest stolica kraju {n}',f'państwo: {n}, stolica?',f'{n} - stolica',f'podaj stolicę kraju {n}']
        if n in gen:qs += [f'stolica {gen[n]}',f'jaka jest stolica {gen[n]}',f'co jest stolicą {gen[n]}']
        add('stolice',qs,cap.get(v,v)+'.')
    elif rel=='continent' and v in cont:
        add('kontynenty',[f'kontynent kraju {n}',f'na jakim kontynencie leży {n}',f'gdzie leży {n}',f'{n} - kontynent',f'podaj kontynent kraju {n}'],cont[v]+'.')
chem='wodór hel lit beryl bor węgiel azot tlen fluor neon sód magnez glin krzem fosfor siarka chlor argon potas wapń skand tytan wanad chrom mangan żelazo kobalt nikiel miedź cynk gal german arsen selen brom krypton rubid stront itr cyrkon niob molibden technet ruten rod pallad srebro kadm ind cyna antymon tellur jod ksenon cez bar lantan cer prazeodym neodym promet samar europ gadolin terb dysproz holm erb tul iterb lutet hafn tantal wolfram ren osm iryd platyna złoto rtęć tal ołów bizmut polon astat radon frans rad aktyn tor protaktyn uran neptun pluton'.split()
elements=collections.defaultdict(dict)
for line in (ROOT/'sources/elements.tsv').read_text().splitlines():
    r,k,v=line.split('\t');elements[k][r]=v
for e in elements.values():
    num=int(e['atomic'])
    if num>len(chem):continue
    n=chem[num-1];symbol=e['symbol']
    add('chemia',[f'symbol pierwiastka {n}',f'jaki symbol ma {n}',f'{n} - symbol',f'podaj symbol: {n}'],symbol+'.')
    add('chemia',[f'liczba atomowa: {n}',f'jaką liczbę atomową ma {n}',f'{n} - liczba atomowa',f'ile protonów ma {n}'],str(num)+'.')
    add('chemia',[f'jaki pierwiastek ma symbol {symbol}',f'co oznacza symbol {symbol}',f'pierwiastek o symbolu {symbol}',f'symbol {symbol} to'],n.capitalize()+'.')
    add('chemia',[f'jaki pierwiastek ma liczbę atomową {num}',f'pierwiastek numer {num}',f'liczba atomowa {num} oznacza',f'podaj pierwiastek o numerze {num}'],n.capitalize()+'.')
days=['poniedziałek','wtorek','środa','czwartek','piątek','sobota','niedziela']
months=['styczeń','luty','marzec','kwiecień','maj','czerwiec','lipiec','sierpień','wrzesień','październik','listopad','grudzień']
for ns,topic in [(days,'dni'),(months,'miesiące')]:
    for i,n in enumerate(ns):
        add(topic,[f'jaki jest {i+1}. {"dzień tygodnia" if ns==days else "miesiąc roku"}',f'{"dzień tygodnia" if ns==days else "miesiąc"} numer {i+1}',f'podaj {i+1}. {"dzień tygodnia" if ns==days else "miesiąc"}'],n.capitalize()+'.')
opposites='duży:mały|wysoki:niski|ciepły:zimny|dobry:zły|szybki:wolny|jasny:ciemny|suchy:mokry|lekki:ciężki|nowy:stary|młody:stary|blisko:daleko|dzień:noc|prawda:fałsz|początek:koniec|wejście:wyjście|góra:dół|prawo:lewo|pełny:pusty|łatwy:trudny|szeroki:wąski'.split('|')
for pair in opposites:
    a,b=pair.split(':');add('słowa',[f'przeciwieństwo słowa {a}',f'jakie jest przeciwieństwo: {a}',f'podaj przeciwieństwo: {a}'],b.capitalize()+'.')
for n in ['sekretny kod Zenona','hasło telefonu Anny','numer konta Marka','pogoda jutro','wynik meczu jutro','imię mojego kota','moja ulubiona potrawa','aktualna cena złota','prywatny adres Ewy']:
    add('brak wiedzy',[f'jaki jest {n}',f'podaj {n}',f'czy znasz {n}'],'Nie wiem.')
train=[];valid=[];seen={}
for i,it in enumerate(items):
    qs=it['questions'];answer=it['answer']
    # Last wording is never included in training, including unaccented versions.
    withheld=qs[-1] if len(qs)>1 else None
    held={withheld,plain(withheld)} if withheld else set()
    for q in qs:
        for question in dict.fromkeys([q,plain(q)]):
            dest=valid if question in held else train
            if question in seen:
                if seen[question]!=answer:raise ValueError(('contradictory',question))
                continue
            seen[question]=answer
            dest.append(dict(id=i,topic=it['topic'],q=question,a=answer))
for name,rows in [('train',train),('valid',valid),('catalog',items)]:
    (ROOT/f'{name}.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
manifest={'items':len(items),'training_questions':len(train),'heldout_questions':len(valid),'topics':dict(collections.Counter(x['topic'] for x in items)),'vocab':len(ALPHABET)+1,'train_sha256':hashlib.sha256((ROOT/'train.jsonl').read_bytes()).hexdigest(),'valid_sha256':hashlib.sha256((ROOT/'valid.jsonl').read_bytes()).hexdigest()}
(ROOT/'dataset.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps(manifest,ensure_ascii=False,indent=2))
