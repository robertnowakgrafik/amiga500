#include "tiny.h"
#include "polish.h"
#include "fast.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void output(const char *s){
#ifdef __amigaos__
    fputs(s,stdout);
#else
    char text[1024];pol_utf8(s,text,sizeof(text));fputs(text,stdout);
#endif
}
int pol_cli(int argc,char **argv)
{
    const char *path="POLTINY.BIN",*q=NULL;int i,info=0,limit=128,neural=0,rc=0,batch=0,once;
    char out[129],line[256];FastReply reply;
    for(i=1;i<argc;i++){
        if(!strcmp(argv[i],"--model")&&i+1<argc)path=argv[++i];
        else if(!strcmp(argv[i],"--ask")&&i+1<argc)q=argv[++i];
        else if(!strcmp(argv[i],"--max-tokens")&&i+1<argc)limit=atoi(argv[++i]);
        else if(!strcmp(argv[i],"--info"))info=1;
        else if(!strcmp(argv[i],"--neural"))neural=1;
        else if(!strcmp(argv[i],"--batch"))batch=1;
        else{puts("PolTiny --model plik [--info | --ask pytanie] [--neural] [--max-tokens 1..128]");return 2;}
    }
    once=q!=NULL;
    if(q&&!neural&&tiny_math(q,&reply)){puts(reply.answer);return reply.kind==FAST_ERROR?1:0;}
    if(!tiny_load(path)){fprintf(stderr,"PolTiny: %s\n",tiny_error());return 1;}
    if(info){printf("PolTiny: warstwy=%d szerokosc=%d RAM_silnika=%lu bajtow\n",tiny_layers(),tiny_width(),tiny_memory());tiny_free();return 0;}
    do{
        if(!q){if(!fgets(line,sizeof(line),stdin))break;q=line;}
        if(!neural&&tiny_math(q,&reply)){puts(reply.answer);rc=0;}
        else {rc=tiny_answer(q,out,limit,NULL,NULL,NULL);if(rc>=0){output(out);putchar('\n');}else fprintf(stderr,"PolTiny: %s\n",tiny_error());}
        q=NULL;
        if(once||(!batch&&argc>1))break;
    }while(1);
    tiny_free();return rc<0?1:0;
}
#ifdef POL_HOST
int main(int argc,char **argv){return pol_cli(argc,argv);}
#endif
