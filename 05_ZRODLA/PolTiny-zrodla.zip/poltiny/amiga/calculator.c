/* Exact bounded rational arithmetic. No neural inference or floating point. */
#include "fast.h"
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

typedef struct { int64_t n, d; } Number;
typedef struct {
    const char *at;
    const char *error;
    int depth;
    FastReply *reply;
} Parser;

static void spaces(Parser *p) { while (isspace((unsigned char)*p->at)) p->at++; }
static int64_t magnitude(int64_t x) { return x < 0 ? -x : x; }
static int64_t gcd(int64_t a, int64_t b)
{
    a = magnitude(a); b = magnitude(b);
    while (b) { int64_t r = a % b; a = b; b = r; }
    return a ? a : 1;
}

static Number checked(Parser *p, int64_t n, int64_t d)
{
    Number result = { 0, 1 };
    int64_t divisor;
    if (!d) { p->error = "Nie mozna dzielic przez zero."; return result; }
    if (d < 0) { n = -n; d = -d; }
    divisor = gcd(n, d); n /= divisor; d /= divisor;
    if (n < -2147483648LL || n > 2147483647LL || d > 2147483647LL) {
        p->error = "Wynik przekracza zakres kalkulatora (32 bity).";
        return result;
    }
    result.n = n; result.d = d;
    return result;
}

static void format(Number a, char *out)
{
    int64_t rest, denominator = a.d, absolute = magnitude(a.n);
    int digits = 0;
    char *tail;
    if (a.d == 1) { sprintf(out, "%ld", (long)a.n); return; }
    while (!(denominator % 2)) { denominator /= 2; digits++; }
    { int fives = 0; while (!(denominator % 5)) { denominator /= 5; fives++; }
      if (fives > digits) digits = fives; }
    if (denominator != 1 || digits > 9) {
        sprintf(out, "%ld/%ld", (long)a.n, (long)a.d); return;
    }
    sprintf(out, "%s%lu.", a.n < 0 ? "-" : "", (unsigned long)(absolute / a.d));
    tail = out + strlen(out); rest = absolute % a.d;
    while (rest) { rest *= 10; *tail++ = (char)('0' + rest / a.d); rest %= a.d; }
    *tail = 0;
}

static void trace(Parser *p, Number a, char op, Number b, Number result)
{
    char left[48], right[48], answer[48], line[160];
    size_t used;
    if (p->error) return;
    format(a, left); format(b, right); format(result, answer);
    sprintf(line, "%s %c %s = %s\n", left, op, right, answer);
    used = strlen(p->reply->steps);
    if (used + strlen(line) < sizeof(p->reply->steps)) strcpy(p->reply->steps + used, line);
    p->reply->operations++;
}

static int word(Parser *p, const char *s)
{
    size_t n = strlen(s);
    spaces(p);
    if (!strncmp(p->at, s, n) && !isalpha((unsigned char)p->at[n])) { p->at += n; return 1; }
    return 0;
}

static Number expression(Parser *p);
static Number unary(Parser *p);

static Number primary(Parser *p)
{
    Number a = { 0, 1 };
    int digits = 0, fractional = 0;
    int64_t numerator = 0, denominator = 1;
    spaces(p);
    if (++p->depth > 16) { p->error = "Zbyt wiele zagniezdzonych nawiasow."; p->depth--; return a; }
    if (*p->at == '(') {
        p->at++; a = expression(p); spaces(p);
        if (*p->at == ')') p->at++; else p->error = "Brakuje nawiasu zamykajacego.";
    } else {
        while (isdigit((unsigned char)*p->at) || ((!fractional) && (*p->at == '.' || *p->at == ','))) {
            int c = *p->at++;
            if (c == '.' || c == ',') { fractional = 1; continue; }
            digits++;
            numerator = numerator * 10 + c - '0';
            if (fractional) denominator *= 10;
            if (numerator > 2147483647LL || denominator > 1000000LL) {
                p->error = "Za duza liczba lub wiecej niz 6 cyfr po przecinku."; break;
            }
        }
        if (!digits) p->error = "Oczekuje liczby lub nawiasu.";
        if (!p->error) a = checked(p, numerator, denominator);
    }
    p->depth--;
    return a;
}

static Number multiply(Parser *p, Number a, Number b)
{
    /* Both normalized operands fit signed 32 bits, so products fit int64. */
    return checked(p, a.n * b.n, a.d * b.d);
}

static Number power(Parser *p)
{
    Number a = primary(p);
    spaces(p);
    if (!p->error && *p->at == '^') {
        Number exponent, base = a, result = { 1, 1 };
        int n;
        p->at++; exponent = unary(p);
        if (exponent.d != 1 || exponent.n < -16 || exponent.n > 16) {
            p->error = "Wykladnik musi byc calkowity, od -16 do 16."; return a;
        }
        n = (int)exponent.n;
        if (n < 0) { base = checked(p, a.d, a.n); n = -n; }
        while (n && !p->error) {
            if (n & 1) result = multiply(p, result, base);
            n >>= 1;
            if (n) base = multiply(p, base, base);
        }
        trace(p, a, '^', exponent, result); a = result;
    }
    return a;
}

static Number unary(Parser *p)
{
    spaces(p);
    if (*p->at == '+' || *p->at == '-') {
        int negative = *p->at++ == '-';
        Number a;
        if (++p->depth > 16) { p->error = "Zbyt wiele znakow lub poteg."; p->depth--; return (Number){0,1}; }
        a = unary(p); p->depth--;
        return negative ? checked(p, -a.n, a.d) : a;
    }
    return power(p);
}

static Number term(Parser *p)
{
    Number a = unary(p);
    while (!p->error) {
        Number b, result;
        char op = 0;
        spaces(p);
        if (*p->at == '*' || *p->at == '/' || *p->at == 'x') op = *p->at++;
        else if (word(p,"times") || word(p,"razy")) op = '*';
        else if (word(p,"divided by") || word(p,"podzielone przez")) op = '/';
        if (!op) break;
        b = unary(p);
        result = op == '/' ? checked(p, a.n * b.d, a.d * b.n) : multiply(p, a, b);
        trace(p, a, op == 'x' ? '*' : op, b, result); a = result;
    }
    return a;
}

static Number expression(Parser *p)
{
    Number a = term(p);
    while (!p->error) {
        Number b, result;
        char op = 0;
        spaces(p);
        if (*p->at == '+' || *p->at == '-') op = *p->at++;
        else if (word(p,"plus")) op = '+';
        else if (word(p,"minus")) op = '-';
        if (!op) break;
        b = term(p);
        result = checked(p, a.n * b.d + (op == '+' ? b.n : -b.n) * a.d, a.d * b.d);
        trace(p, a, op, b, result); a = result;
    }
    return a;
}

int tiny_math(const char *question, FastReply *reply)
{
    char line[128];
    const char *prefixes[] = { "what is ", "how much is ", "calculate ", "compute ",
                              "ile to ", "ile jest ", "oblicz ", NULL };
    Parser p;
    Number result;
    int i, n = 0;
    memset(reply, 0, sizeof(*reply));
    while (question[n] && n < (int)sizeof(line)-1) { line[n] = (char)tolower((unsigned char)question[n]); n++; }
    if (question[n]) return FAST_NONE;
    line[n] = 0;
    p.at = line; p.error = NULL; p.depth = 0; p.reply = reply;
    spaces(&p);
    for (i = 0; prefixes[i]; i++) if (!strncmp(p.at,prefixes[i],strlen(prefixes[i]))) {
        p.at += strlen(prefixes[i]); break;
    }
    spaces(&p);
    if (!isdigit((unsigned char)*p.at) && *p.at != '(' && *p.at != '+' && *p.at != '-' && *p.at != '.')
        return FAST_NONE;
    result = expression(&p); spaces(&p);
    if (*p.at == '?') { p.at++; spaces(&p); }
    if (*p.at && !p.error) p.error = "Nie rozpoznaje dzialania. Uzyj + - * / ^ i nawiasow.";
    reply->kind = p.error ? FAST_ERROR : FAST_MATH;
    if (p.error) { strcpy(reply->answer,p.error); reply->steps[0] = 0; }
    else format(result,reply->answer);
    return reply->kind;
}
