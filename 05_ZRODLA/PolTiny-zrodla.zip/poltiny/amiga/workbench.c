/* Intuition V33 / Workbench 1.3: no GadTools, ReAction or OS 2.x calls. */
#include "tiny.h"
#include "monitor.h"
#include "fast.h"
#include "polish.h"
#include "plfont.h"
int pol_cli(int argc,char **argv);
#include <exec/types.h>
#include <intuition/intuition.h>
#include <graphics/gfxbase.h>
#include <workbench/startup.h>
#include <proto/exec.h>
#include <proto/dos.h>
#include <proto/intuition.h>
#include <proto/graphics.h>
#include <stdio.h>
#include <string.h>

struct IntuitionBase *IntuitionBase;
struct GfxBase *GfxBase;
unsigned long __stack = 16384;
/* libnix must not open a separate console for a Workbench launch. */
char *__stdiowin = NULL;

static struct Window *win;
static struct TextFont *font;
static struct Gadget input, ask, stop;
static struct StringInfo stringinfo;
static struct IntuiText asktext, stoptext;
static char question[TINY_MAXQ + 1], undo[TINY_MAXQ + 1];
#define CHAT_COLUMNS 41
#define MONITOR_X 350
static char history[14][CHAT_COLUMNS + 1];
static char status[76] = "Uruchamiam PolTiny...";
static int lines, column, running = 1, busy, cancelled, pending, engine_loaded;
static int rows, input_y, status_y;
static int phase, token_done, token_total, layer, work_kind, work_done, work_total;
static ULONG started_seconds, last_status_seconds;
static ULONG last_plot_seconds, last_plot_micros;
static const TinyTelemetry *monitor_snapshot;
static TinyMonitorHistory monitor_history;
static int monitor_dirty = 1;
static FastReply fast_reply;
static int fast_panel;

static void draw_fast_panel(void)
{
    char body[800], part[34];
    const char *at;
    int row = 0, n;
    struct RastPort *rp = win->RPort;
    const char *title = fast_reply.kind == FAST_MATH ? "KALKULATOR" :
                        fast_reply.kind == FAST_ERROR ? "BLAD" : "BAZA WIEDZY";
    snprintf(body,sizeof(body),"%s\n\n%s\n\n%s",title,fast_reply.answer,fast_reply.steps);
    SetAPen(rp,0);RectFill(rp,MONITOR_X,win->BorderTop+3,win->Width-11,status_y-10);
    SetAPen(rp,1);Move(rp,MONITOR_X-6,win->BorderTop+3);Draw(rp,MONITOR_X-6,status_y-10);
    at = body;
    while (*at && row < 12) {
        n = 0;
        while (*at && *at!='\n' && n<33) part[n++]=*at++;
        if (*at=='\n') at++;
        part[n]=0;
        SetAPen(rp,row==0?3:1);SetDrMd(rp,JAM1);
        Move(rp,MONITOR_X,win->BorderTop+11+row*9);Text(rp,part,n);row++;
    }
}

static void plot_fill(void *user, int x0, int y0, int x1, int y1, int pen)
{
    struct RastPort *rp = user;
    SetAPen(rp, pen);
    RectFill(rp, x0, y0, x1, y1);
}

static void plot_line(void *user, int x0, int y0, int x1, int y1, int pen)
{
    struct RastPort *rp = user;
    SetAPen(rp, pen);
    Move(rp, x0, y0); Draw(rp, x1, y1);
}

static void plot_text(void *user, int x, int y, const char *text, int pen)
{
    struct RastPort *rp = user;
    SetAPen(rp, pen); SetDrMd(rp, JAM1);
    Move(rp, x, y); Text(rp, text, strlen(text));
}

static void draw_monitor(void)
{
    TinyPlot plot = { win->RPort, plot_fill, plot_line, plot_text };
    if (fast_panel) { draw_fast_panel(); monitor_dirty=0; return; }
    tiny_monitor_draw(monitor_snapshot, &monitor_history, &plot,
                      MONITOR_X, win->BorderTop + 3, win->Width - MONITOR_X - 10);
    monitor_dirty = 0;
}

static void monitor_observer(const TinyTelemetry *snapshot, void *user)
{
    (void)user;
    monitor_snapshot = snapshot;
    tiny_monitor_record(&monitor_history, snapshot);
    monitor_dirty = 1;
}

static void draw_status(void)
{
    struct RastPort *rp = win->RPort;
    SetAPen(rp, 0);
    RectFill(rp, 5, status_y - 8, win->Width - 6, status_y + 2);
    SetAPen(rp, 1);
    SetDrMd(rp, JAM1);
    Move(rp, 10, status_y);
    Text(rp, status, strlen(status));
}

static void draw(void)
{
    int i;
    struct RastPort *rp = win->RPort;
    SetAPen(rp, 0);
    RectFill(rp, 5, win->BorderTop + 2, win->Width - 6, input_y - 8);
    SetAPen(rp, 1);
    SetDrMd(rp, JAM1);
    for (i = 0; i < lines; i++) {
        Move(rp, 10, win->BorderTop + 11 + i * 9);
        Text(rp, history[i], strlen(history[i]));
    }
    draw_monitor();
    draw_status();
    Move(rp, 10, input_y + 7);
    Text(rp, "PL:", 3);
    Move(rp, 39, input_y - 2);
    Draw(rp, win->Width - 12, input_y - 2);
    Draw(rp, win->Width - 12, input_y + 10);
    Draw(rp, 39, input_y + 10);
    Draw(rp, 39, input_y - 2);
}

static void new_line(void)
{
    if (lines == rows) {
        memmove(history, history + 1, (rows - 1) * sizeof(history[0]));
        lines--;
    }
    history[lines++][0] = 0;
    column = 0;
}

static void append(int c)
{
    if (!lines || column == CHAT_COLUMNS || c == '\n') new_line();
    if (c != '\n') {
        history[lines - 1][column++] = (char)c;
        history[lines - 1][column] = 0;
    }
}

static void say(const char *text)
{
    char converted[1024];
    pol_local(text,converted,sizeof(converted));text=converted;
    if (lines && column) new_line();
    while (*text) append((unsigned char)*text++);
    draw();
}

/* Reply immediately to every IntuiMessage, including during inference. */
static void events(void)
{
    struct IntuiMessage *msg;
    while ((msg = (struct IntuiMessage *)GetMsg(win->UserPort))) {
        ULONG cls = msg->Class;
        UWORD code = msg->Code;
        struct Gadget *g = (struct Gadget *)msg->IAddress;
        ReplyMsg((struct Message *)msg);
        if (cls == CLOSEWINDOW) { running = 0; cancelled = 1; }
        else if (cls == RAWKEY && code == 0x45) cancelled = 1;
        else if (cls == REFRESHWINDOW) {
            BeginRefresh(win);
            draw();
            EndRefresh(win, TRUE);
        } else if (cls == GADGETUP && g) {
            if (g->GadgetID == 3) cancelled = 1;
            else if (!busy) pending = g->GadgetID == 4 ? 2 : 1;
        }
    }
}

static void update_status(int force)
{
    static const char *names[] = { "start", "dysk", "licze", "uwaga" };
    ULONG seconds, micros, elapsed;
    int percent = work_total ? (int)((long)work_done * 100 / work_total) : 0;
    char part[24];
    CurrentTime(&seconds, &micros);
    if (monitor_dirty && (force || seconds != last_plot_seconds ||
        micros >= last_plot_micros + 250000UL)) {
        draw_monitor();
        last_plot_seconds = seconds; last_plot_micros = micros;
    }
    if (!force && seconds == last_status_seconds) return;
    last_status_seconds = seconds;
    elapsed = seconds - started_seconds;
    if (!phase) sprintf(part, "Czytam %d/%d", token_done < token_total ? token_done + 1 : token_total, token_total);
    else sprintf(part, "Pisze %d", token_done);
    sprintf(status, "%s L%d/%d %s %d%% | %lu:%02lu | Stop/Esc",
            part, layer, tiny_layers(), names[work_kind], percent,
            elapsed / 60, elapsed % 60);
    draw_status();
}

static int work(int kind, int done, int total, void *user)
{
    (void)user;
    events();
    if (!running || cancelled) return 0;
    if (kind == TINY_WORK_LAYER) layer = done;
    work_kind = kind; work_done = done; work_total = total;
    update_status(0);
    return 1;
}

static int progress(int new_phase, int done, int total, void *user)
{
    (void)user;
    events();
    if (!running || cancelled) return 0;
    phase = new_phase; token_done = done; token_total = total;
    layer = 0; work_kind = TINY_WORK_LAYER; work_done = 0; work_total = 0;
    update_status(1);
    return 1;
}

static void set_busy(int value)
{
    busy = value;
    if (value) {
        OffGadget(&input, win, NULL);
        OffGadget(&ask, win, NULL);
    } else {
        OnGadget(&input, win, NULL);
        OnGadget(&ask, win, NULL);
    }
}

static void letter(int c, void *user)
{
    (void)user;
    append(c);
    draw();
}

static void init_button(struct Gadget *g, struct IntuiText *text,
                        char *label, int x, int y, int width, int id)
{
    memset(g, 0, sizeof(*g));
    memset(text, 0, sizeof(*text));
    text->FrontPen = 1;
    text->DrawMode = JAM1;
    text->LeftEdge = 4;
    text->TopEdge = 2;
    text->IText = (UBYTE *)label;
    g->LeftEdge = x; g->TopEdge = y;
    g->Width = width; g->Height = 12;
    g->Flags = GADGHCOMP;
    g->Activation = RELVERIFY;
    g->GadgetType = BOOLGADGET;
    g->GadgetText = text;
    g->GadgetID = id;
}

int main(int argc, char **argv)
{
    struct NewWindow nw;
    struct TextAttr attr = { (STRPTR)"topaz.font", 8, FS_NORMAL, FPF_ROMFONT };
    BPTR olddir = 0;
    int changed_dir = 0, result = 1;
    const char *path = "POLTINY.BIN";
    if(argc>1 && argv[1][0]=='-')return pol_cli(argc,argv);
    if (!argc) {
        struct WBStartup *wb = (struct WBStartup *)argv;
        if (wb && wb->sm_NumArgs && wb->sm_ArgList[0].wa_Lock) {
            olddir = CurrentDir(wb->sm_ArgList[0].wa_Lock);
            changed_dir = 1;
        }
    } else if (argc > 1) path = argv[1];
    IntuitionBase = (struct IntuitionBase *)OpenLibrary("intuition.library", 33);
    GfxBase = (struct GfxBase *)OpenLibrary("graphics.library", 33);
    if (!IntuitionBase || !GfxBase) goto done;
    /* Also create the standard screen when booting without LoadWB. */
    if (!OpenWorkBench()) goto done;
    memset(&nw, 0, sizeof(nw));
    nw.LeftEdge = 4; nw.TopEdge = 12;
    nw.Width = 632; nw.Height = 180;
    nw.DetailPen = 0; nw.BlockPen = 1;
    nw.IDCMPFlags = CLOSEWINDOW | GADGETUP | RAWKEY | REFRESHWINDOW;
    nw.Flags = WINDOWDRAG | WINDOWDEPTH | WINDOWCLOSE | ACTIVATE | SIMPLE_REFRESH;
    nw.Title = (UBYTE *)"PolTiny PL - Amiga 500 / Workbench 1.3";
    nw.Type = WBENCHSCREEN;
    win = OpenWindow(&nw);
    if (!win) goto done;
    font = OpenFont(&attr);
    if (!font) goto done;
    SetFont(win->RPort, pol_font(font));
    input_y = win->Height - 34;
    status_y = input_y - 7;
    rows = (status_y - win->BorderTop - 15) / 9;
    if (rows > 14) rows = 14;
    if (rows < 1) rows = 1;
    memset(&input, 0, sizeof(input));
    memset(&stringinfo, 0, sizeof(stringinfo));
    stringinfo.Buffer = (STRPTR)question;
    stringinfo.UndoBuffer = (STRPTR)undo;
    stringinfo.MaxChars = sizeof(question);
    input.LeftEdge = 42; input.TopEdge = input_y;
    input.Width = 576; input.Height = 8;
    input.Flags = GADGHCOMP;
    input.Activation = RELVERIFY;
    input.GadgetType = STRGADGET;
    input.SpecialInfo = &stringinfo;
    input.GadgetID = 1;
    init_button(&ask, &asktext, "[ Odpowiedz ]", 10, input_y + 16, 128, 2);
    init_button(&stop, &stoptext, "[ Stop / Esc ]", 146, input_y + 16, 128, 3);
    input.NextGadget = &ask;
    ask.NextGadget = &stop;
    AddGadget(win, &input, (UWORD)-1);
    AddGadget(win, &ask, (UWORD)-1);
    AddGadget(win, &stop, (UWORD)-1);
    say("PolTiny: nowa sieć uczona po polsku.");
    say("914 tematów/faktów treningowych.");
    say("Tekst: wolno. Rachunki: od razu.");
    say("Wykresy: aktywność, uwaga i wybór znaku.");
    say("To pomiary sieci, nie zapis myśli.");
    RefreshGadgets(&input, win, NULL);
    strcpy(status,"Gotowy. Enter wysyla pytanie. Pisanie bez polskich liter tez dziala.");
    draw();ActivateGadget(&input,win,NULL);result=0;
    while (running) {
        if (!pending) Wait(1UL << win->UserPort->mp_SigBit);
        events();
        if (running && pending) {
            char q[TINY_MAXQ + 1], out[TINY_CONTEXT + 1];
            ULONG micros;
            int n;
            pending = 0;
            if (!tiny_clean(question,q)) continue;
            say("> ");
            for (n = 0; q[n]; n++) append(q[n]);
            new_line();
            memset(&monitor_history, 0, sizeof(monitor_history));
            monitor_snapshot = NULL;
            monitor_dirty = 1;
            fast_panel = 0;
            memset(&fast_reply,0,sizeof(fast_reply));
            draw();
            set_busy(1); cancelled = 0;
            if (tiny_math(q,&fast_reply)) {
                fast_panel=1;
                say(fast_reply.kind==FAST_MATH?"[KALKULATOR]":"[BŁĄD]");
                say(fast_reply.answer);
                strcpy(status,"Kalkulator: gotowe. Rzeczywiste kroki obliczen w panelu.");
                set_busy(0);draw();ActivateGadget(&input,win,NULL);continue;
            }
            if (!engine_loaded) {
                strcpy(status,"Wczytuje POLTINY.BIN. Siec pracuje offline; tekst wymaga czasu.");draw_status();
                if (!tiny_load(path)) {
                    say(tiny_error());strcpy(status,"Blad modelu. Kalkulator pozostaje dostepny.");
                    set_busy(0);draw();ActivateGadget(&input,win,NULL);continue;
                }
                engine_loaded=1;
            }
            CurrentTime(&started_seconds, &micros);
            last_status_seconds = (ULONG)-1;
            last_plot_seconds = (ULONG)-1;
            tiny_set_observer(monitor_observer, NULL);
            tiny_set_work(work, NULL);
            n = tiny_answer(q, out, TINY_CONTEXT, progress, letter, NULL);
            tiny_set_work(NULL, NULL);
            tiny_set_observer(NULL, NULL);
            set_busy(0);
            if (n == -3) {
                say(tiny_error());
                strcpy(status, "Blad odczytu. Sprawdz dyskietke.");
            } else strcpy(status, n < 0 ? "Zatrzymano. Mozesz zadac kolejne pytanie." : "Gotowy. Enter lub Odpowiedz wysyla pytanie.");
            draw();
            if (running) ActivateGadget(&input, win, NULL);
        }
    }
done:
    tiny_set_observer(NULL, NULL);
    tiny_set_work(NULL, NULL);
    tiny_free();
    if (win) CloseWindow(win);
    if (font) CloseFont(font);
    if (GfxBase) CloseLibrary((struct Library *)GfxBase);
    if (IntuitionBase) CloseLibrary((struct Library *)IntuitionBase);
    if (changed_dir) CurrentDir(olddir);
    return result;
}
