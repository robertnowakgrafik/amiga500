/* Derive glyphs in RAM from the user's ROM font; no ROM font is distributed. */
#include "plfont.h"
#include "polish.h"
#include <string.h>
static struct TextFont result;
static UBYTE bits[258*8];
static ULONG loc[257];
struct TextFont *pol_font(struct TextFont *rom)
{
    int c,y,x,i;ULONG cell,bit;UBYTE glyph[8];
    if(rom->tf_YSize!=8||rom->tf_XSize!=8)return rom;
    memset(bits,0,sizeof(bits));result=*rom;
    for(c=0;c<257;c++){
        int source=c;
        if(source<rom->tf_LoChar||source>rom->tf_HiChar)source=rom->tf_HiChar+1;
        cell=((ULONG *)rom->tf_CharLoc)[source-rom->tf_LoChar];
        for(y=0;y<8;y++)for(x=0;x<8&&x<(int)(cell&65535);x++){
            bit=(cell>>16)+x;
            if(((UBYTE *)rom->tf_CharData)[y*rom->tf_Modulo+(bit>>3)]&(128>>(bit&7)))bits[y*258+c]|=128>>x;
        }
        loc[c]=((ULONG)(c*8)<<16)|8;
    }
    for(i=0;i<18;i++){
        const char *base="acelnoszzACELNOSZZ";
        c=pol_letter(97+i);
        for(y=0;y<8;y++)glyph[y]=bits[y*258+(unsigned char)base[i]];
        if(i%9==0||i%9==2){glyph[7]|=0x0c;glyph[6]|=0x08;}
        else if(i%9==3){glyph[2]|=0x04;glyph[3]|=0x08;glyph[4]|=0x10;}
        else {for(y=7;y>0;y--)glyph[y]=glyph[y-1];glyph[0]=i%9==8?0x10:0x08;}
        for(y=0;y<8;y++)bits[y*258+c]=glyph[y];
    }
    result.tf_Flags=FPF_DESIGNED;result.tf_LoChar=0;result.tf_HiChar=255;
    result.tf_Modulo=258;result.tf_CharData=bits;result.tf_CharLoc=loc;
    result.tf_CharSpace=NULL;result.tf_CharKern=NULL;result.tf_Accessors=1;
    return &result;
}
