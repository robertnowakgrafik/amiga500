/* libnix defaults use 16 KB stdio buffers and 16 KB allocation pools.
 * A stock A500 benefits from smaller pools and 2 KB file buffers. */
static unsigned tiny_buffer_bytes = 2048;
static unsigned long tiny_pool_bytes = 4096;
unsigned *__BUFSIZE = &tiny_buffer_bytes;
unsigned long *__MEMORY_STEP = &tiny_pool_bytes;
