/* Small positive sqrt and non-positive exp. No OS math libraries or FPU. */
#include "portable_math.h"
#include <string.h>
#include <stdint.h>

float tiny_sqrt(float x)
{
    uint32_t bits;
    float y;
    int i;
    if (x <= 0.0f) return 0.0f;
    memcpy(&bits, &x, 4);
    bits = (bits >> 1) + 0x1fc00000UL;
    memcpy(&y, &bits, 4);
    for (i = 0; i < 5; i++) y = 0.5f * (y + x / y);
    return y;
}

float tiny_exp(float x)
{
    int n;
    uint32_t bits;
    float r, y, scale;
    if (x < -60.0f) return 0.0f;
    if (x >= 0.0f) return 1.0f;
    n = (int)(x * 1.4426950408889634f - 0.5f);
    /* Split ln(2) to keep range reduction accurate in single precision. */
    r = (x - n * 0.693145751953125f) - n * 0.000001428606765330187f;
    y = 1.0f + r * (1.0f + r * (0.5f + r * (0.1666666666667f +
        r * (0.0416666666667f + r * (0.0083333333333f +
        r * (0.0013888888889f + r * 0.0001984126984f))))));
    bits = (uint32_t)(n + 127) << 23;
    memcpy(&scale, &bits, 4);
    return y * scale;
}
