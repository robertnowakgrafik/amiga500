#ifndef TINY_FAST_H
#define TINY_FAST_H
#define FAST_NONE 0
#define FAST_MATH 1
#define FAST_FACT 2
#define FAST_ERROR 3
#define FAST_HELP 4
typedef struct {
    int kind, operations;
    char answer[256];
    char steps[512];
} FastReply;
int tiny_math(const char *question, FastReply *reply);
int tiny_fast(const char *question, const char *database, FastReply *reply);
void tiny_fast_close(void);
#endif
