#include "polish.h"
static const unsigned char letters[18]={0xb1,0xe6,0xea,0xb3,0xf1,0xf3,0xb6,0xbc,0xbf,0xa1,0xc6,0xca,0xa3,0xd1,0xd3,0xa6,0xac,0xaf};
static const unsigned short unicode[18]={0x105,0x107,0x119,0x142,0x144,0xf3,0x15b,0x17a,0x17c,0x104,0x106,0x118,0x141,0x143,0xd3,0x15a,0x179,0x17b};
int pol_token(unsigned char c){int i;if(c=='\n')return 1;if(c>=32&&c<=126)return c-30;for(i=0;i<18;i++)if(c==letters[i])return 97+i;return 0;}
unsigned char pol_letter(int t){return t>=97&&t<115?letters[t-97]:t>=2&&t<97?t+30:'\n';}
unsigned char pol_lower(unsigned char c){int i;if(c>='A'&&c<='Z')return c+32;for(i=9;i<18;i++)if(c==letters[i])return letters[i-9];return c;}
void pol_local(const char *s,char *o,size_t cap){size_t n=0;int i;if(!cap)return;while(*s&&n+1<cap){unsigned char c=*s++;if(c>=0xc2&&c<=0xdf&&((unsigned char)*s&0xc0)==0x80){unsigned u=((c&31)<<6)|((unsigned char)*s++&63);c='?';for(i=0;i<18;i++)if(u==unicode[i]){c=letters[i];break;}}o[n++]=c;}o[n]=0;}
void pol_utf8(const char *s,char *o,size_t cap){size_t n=0;int i;if(!cap)return;while(*s&&n+1<cap){unsigned char c=*s++;unsigned u=c;for(i=0;i<18;i++)if(c==letters[i]){u=unicode[i];break;}if(u>=128){if(n+2>=cap)break;o[n++]=0xc0|(u>>6);o[n++]=0x80|(u&63);}else o[n++]=c;}o[n]=0;}
