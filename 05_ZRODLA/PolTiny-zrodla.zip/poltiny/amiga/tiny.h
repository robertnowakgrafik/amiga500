#ifndef TINY_AMIGA_H
#define TINY_AMIGA_H
#define TINY_MAXQ 72
#define TINY_CONTEXT 128
typedef int (*TinyProgress)(int phase, int done, int total, void *user);
typedef void (*TinyLetter)(int letter, void *user);
enum { TINY_WORK_LAYER, TINY_WORK_DISK, TINY_WORK_MATH, TINY_WORK_ATTENTION };
/* Frequent checkpoints within a token. Returning zero cancels inference. */
typedef int (*TinyWork)(int kind, int done, int total, void *user);
void tiny_set_work(TinyWork work, void *user);
#define TINY_MAX_LAYERS 8
#define TINY_CANDIDATES 3
enum { TINY_OBSERVE_TOKEN, TINY_OBSERVE_LAYER, TINY_OBSERVE_ATTENTION,
       TINY_OBSERVE_PREDICTION, TINY_OBSERVE_LAYER_START };
typedef struct {
    int event, position, token, layers, layer, head;
    unsigned layer_mask;
    float activity[TINY_MAX_LAYERS]; /* mean ReLU activation, this token */
    int attention_length;
    float attention[TINY_CONTEXT]; /* normalized probabilities, last head */
    int has_prediction;
    int candidate[TINY_CANDIDATES];
    float probability[TINY_CANDIDATES]; /* full-vocabulary softmax */
} TinyTelemetry;
/* Snapshot storage belongs to the engine, stays valid until next update.
   Observer must not re-enter inference. NULL disables telemetry calculations. */
typedef void (*TinyObserver)(const TinyTelemetry *snapshot, void *user);
void tiny_set_observer(TinyObserver observer, void *user);
int tiny_load(const char *path);
void tiny_free(void);
const char *tiny_error(void);
unsigned long tiny_memory(void);
int tiny_width(void);
int tiny_layers(void);
int tiny_clean(const char *line, char *q);
/* out needs TINY_CONTEXT+1 bytes. -1 cancelled, -2 not loaded, -3 disk error.
   Single model, single caller. Callbacks must not re-enter the engine. */
int tiny_answer(const char *question, char *out, int limit,
                TinyProgress progress, TinyLetter letter, void *user);
#endif
