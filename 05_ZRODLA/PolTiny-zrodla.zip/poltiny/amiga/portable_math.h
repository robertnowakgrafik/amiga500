#ifndef TINY_PORTABLE_MATH_H
#define TINY_PORTABLE_MATH_H
float tiny_sqrt(float x);
/* Only the range [-60, 0] is needed by the attention softmax. */
float tiny_exp(float x);
#endif
