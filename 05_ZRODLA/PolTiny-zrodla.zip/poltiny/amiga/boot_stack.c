/* Set the initial CLI's default stack for the next command (Kickstart 1.3).
 * The field counts longwords. No external Stack command is required. */
#include <exec/types.h>
#include <dos/dosextens.h>
#include <proto/exec.h>

/* This command needs no argument parsing or stdio initialization. */
void __nocommandline(void) {}

int main(void)
{
    struct Process *process = (struct Process *)FindTask(NULL);
    struct CommandLineInterface *cli;
    if (!process || !process->pr_CLI) return 20;
    cli = (struct CommandLineInterface *)BADDR(process->pr_CLI);
    cli->cli_DefaultStack = 16384 / sizeof(ULONG);
    return 0;
}
