/* Pure drawing primitives shared by the Amiga UI and the host preview/tests. */
#include "monitor.h"
#include "polish.h"
#include <stdio.h>
#include <string.h>

void tiny_monitor_record(TinyMonitorHistory *h, const TinyTelemetry *s)
{
    int n;
    if (s->event != TINY_OBSERVE_PREDICTION) return;
    if (h->count == TINY_MONITOR_HISTORY) {
        memmove(h->confidence, h->confidence + 1, (h->count - 1) * sizeof(h->confidence[0]));
        memmove(h->token, h->token + 1, h->count - 1);
        h->count--;
    }
    n = h->count++;
    h->confidence[n] = (unsigned short)(s->probability[0] * 1000.0f + 0.5f);
    h->token[n] = (unsigned char)s->candidate[0];
}

static char token_char(int token)
{
    if (token <= 1) return '$';
    if (token == 2) return '_';
    return (char)pol_letter(token);
}

void tiny_monitor_draw(const TinyTelemetry *s, const TinyMonitorHistory *h,
                       const TinyPlot *p, int x, int y, int width)
{
    int i, n, bar, dx, height, bins, strongest = 0;
    float peak = 0.0f, weights[32];
    char text[64];
    p->fill(p->user, x, y, x + width - 1, y + 113, 0);
    p->line(p->user, x - 6, y, x - 6, y + 113, 1);
    p->text(p->user, x, y + 7, "WARSTWY (wzgledne)", 1);
    if (s) {
        if (s->token <= 1) sprintf(text, "[NL] #%d", s->position + 1);
        else sprintf(text, "[%c] #%d", token_char(s->token), s->position + 1);
        p->text(p->user, x + width - 8 * (int)strlen(text), y + 7, text, 3);
    }
    n = s && s->layers ? s->layers : 4;
    for (i = 0; s && i < n; i++) if (s->activity[i] > peak) peak = s->activity[i];
    dx = (width - 8) / n;
    for (i = 0; i < n; i++) {
        int active = s && s->layer == i;
        bar = x + 4 + i * dx;
        height = s && peak > 0.0f ? (int)(s->activity[i] * 14.0f / peak) : 0;
        if (height > 0) p->fill(p->user, bar, y + 25 - height, bar + dx - 5, y + 24, active ? 3 : 1);
        p->line(p->user, bar, y + 25, bar + dx - 5, y + 25, 1);
        sprintf(text, "L%d", i + 1);
        p->text(p->user, bar + 1, y + 34, text, active ? 3 : 1);
    }
    if (s && s->attention_length) sprintf(text, "UWAGA L%d G%d (wzgledna)", s->layer + 1, s->head + 1);
    else strcpy(text, "UWAGA (czekam na dane)");
    p->text(p->user, x, y + 45, text, 1);
    p->line(p->user, x + 4, y + 65, x + width - 5, y + 65, 1);
    if (s && s->attention_length) {
        n = s->attention_length;
        bins = n < 32 ? n : 32;
        memset(weights, 0, sizeof(weights));
        for (i = 0; i < n; i++) weights[i * bins / n] += s->attention[i];
        peak = 0.0f;
        for (i = 0; i < bins; i++) if (weights[i] > peak) { peak = weights[i]; strongest = i; }
        dx = (width - 8) / bins;
        for (i = 0; i < bins; i++) {
            height = peak > 0.0f ? (int)(weights[i] * 16.0f / peak) : 0;
            bar = x + 4 + i * dx;
            if (height > 0) p->fill(p->user, bar, y + 65 - height, bar + dx - 2, y + 64, i == strongest ? 3 : 1);
        }
        p->text(p->user, x + 4, y + 74, "1", 1);
        sprintf(text, "%d znakow", n);
        p->text(p->user, x + width - 8 * (int)strlen(text), y + 74, text, 1);
    }
    if (s && s->has_prediction) {
        if (s->candidate[0] <= 1) strcpy(text, "WYBOR <KONIEC>");
        else sprintf(text, "WYBOR '%c'", token_char(s->candidate[0]));
        sprintf(text + strlen(text), " %d%% (p.)", (int)(s->probability[0] * 100.0f + 0.5f));
    } else strcpy(text, "PRAWDOPODOBIENSTWO ZNAKU");
    p->text(p->user, x, y + 84, text, 1);
    p->line(p->user, x + 4, y + 104, x + width - 5, y + 104, 1);
    dx = (width - 8) / TINY_MONITOR_HISTORY;
    for (i = 0; i < h->count; i++) {
        bar = x + 4 + i * dx;
        height = (long)h->confidence[i] * 16 / 1000;
        if (height > 0) p->fill(p->user, bar, y + 104 - height, bar + dx - 2, y + 103, i == h->count - 1 ? 3 : 1);
        text[0] = token_char(h->token[i]); text[1] = 0;
        p->text(p->user, bar, y + 113, text, 1);
    }
}
