#ifndef POLTINY_FONT_H
#define POLTINY_FONT_H
#include <graphics/text.h>
struct TextFont *pol_font(struct TextFont *rom);
#endif
