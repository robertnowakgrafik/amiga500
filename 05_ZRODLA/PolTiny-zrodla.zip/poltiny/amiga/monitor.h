#ifndef TINY_MONITOR_H
#define TINY_MONITOR_H
#include "tiny.h"
#define TINY_MONITOR_HISTORY 24
typedef struct {
    int count;
    unsigned short confidence[TINY_MONITOR_HISTORY]; /* 0..1000 */
    unsigned char token[TINY_MONITOR_HISTORY];
} TinyMonitorHistory;
typedef struct {
    void *user;
    void (*fill)(void *user, int x0, int y0, int x1, int y1, int pen);
    void (*line)(void *user, int x0, int y0, int x1, int y1, int pen);
    void (*text)(void *user, int x, int baseline, const char *text, int pen);
} TinyPlot;
void tiny_monitor_record(TinyMonitorHistory *history, const TinyTelemetry *snapshot);
/* 8x8 fixed font; canvas at least 240x114 pixels. No off-screen bitmap. */
void tiny_monitor_draw(const TinyTelemetry *snapshot, const TinyMonitorHistory *history,
                       const TinyPlot *plot, int x, int y, int width);
#endif
