#ifndef POLTINY_POLISH_H
#define POLTINY_POLISH_H
#include <stddef.h>
/* Native UI/model encoding: ISO-8859-2; host/JSON encoding: UTF-8. */
int pol_token(unsigned char c);
unsigned char pol_letter(int token);
unsigned char pol_lower(unsigned char c);
void pol_local(const char *utf8, char *out, size_t cap);
void pol_utf8(const char *local, char *out, size_t cap);
#endif
