/* TINY 2.1 Amiga engine, derived from WollyMonjac/Tiny-2.1 (MIT).
 * New Polish TPL1 weights, explicit little-endian decoding, 68000 kernel.
 * See LICENSE and DATA_LICENSES.md. */
#include "tiny.h"
#include "polish.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <setjmp.h>
#ifdef TINY_PORTABLE_MATH
#include "portable_math.h"
#define sqrtf tiny_sqrt
#define expf tiny_exp
#endif
#define VOCAB 115
#define CTX 128
#define MAXD 128
#define MAXHID 512
#define MAXL 8
/* A table of weights: one byte per number, one scale per row. */
typedef struct {
    float *scale;
    signed char *w;
    int rows, cols;
    long offset;
} Table;

static FILE *model_file;
#ifndef TINY_RESIDENT
static unsigned char *stream_data;
#endif
static int D, L, H, HD, HID;
static float att_div;                         /* sqrt(HD) */
static Table emb, pos;
static Table wq[MAXL], wk[MAXL], wv[MAXL], wo[MAXL], f1[MAXL], f2[MAXL];
static float *g1[MAXL], *g2[MAXL], *gf;

static jmp_buf load_jump;
static const char *error_text;
static FILE *loading_file;
static void *allocations[256];
static unsigned allocation_count;
static unsigned long allocated_bytes;
static TinyWork work_callback;
static void *work_user;
static int work_cancelled;
static TinyObserver observer;
static void *observer_user;
static TinyTelemetry telemetry;
static void (*on_load)(int done, int total);  /* loading progress     */
static int tables_done, tables_total;

static void fail(const char *msg)
{
    error_text = msg;
    longjmp(load_jump, 1);
}

static void *get_memory(unsigned n)
{
    void *p;
    if (allocation_count == 256) fail("Zbyt wiele alokacji pamieci.");
    p = malloc(n);
    if (!p) fail("Brak RAM. Zamknij inne programy Workbencha.");
    allocations[allocation_count++] = p;
    allocated_bytes += n;
    return p;
}

void tiny_set_work(TinyWork work, void *user)
{
    work_callback = work;
    work_user = user;
}

void tiny_set_observer(TinyObserver callback, void *user)
{
    observer = callback;
    observer_user = user;
}

static void observe(int event)
{
    telemetry.event = event;
    observer(&telemetry, observer_user);
}

static void checkpoint(int kind, int done, int total)
{
    if (work_callback && !work_callback(kind, done, total, work_user)) {
        work_cancelled = 1;
        longjmp(load_jump, 1);
    }
}

static float decode_float(const unsigned char *b)
{
    unsigned long bits;
    float f;
    bits = (unsigned long)b[0] | ((unsigned long)b[1] << 8) |
           ((unsigned long)b[2] << 16) | ((unsigned long)b[3] << 24);
    if ((bits & 0x7f800000UL) == 0x7f800000UL)
        fail("Bledna liczba w POLTINY.BIN");
    { unsigned int word = (unsigned int)bits; memcpy(&f, &word, 4); }
    return f;
}

static float read_float(FILE *fp)
{
    unsigned char b[4];
    if (fread(b, 1, 4, fp) != 4) fail("Niepelny plik POLTINY.BIN");
    return decode_float(b);
}

static void damaged(void)
{
    fail("Plik POLTINY.BIN jest uszkodzony lub niepelny.");
}

static void load_table(FILE *fp, Table *t, int rows, int cols)
{
    int r;
    t->rows = rows;
    t->cols = cols;
    if ((long)rows * cols > 65000L)
        fail("Tabela modelu jest za duza.");
    t->offset = ftell(fp);
#ifdef TINY_RESIDENT
    t->scale = (float *)get_memory((unsigned)rows * sizeof(float));
    t->w = (signed char *)get_memory((unsigned)rows * (unsigned)cols);
    for (r = 0; r < rows; r++) {
        t->scale[r] = read_float(fp);
        if (t->scale[r] <= 0.0f) damaged();
        if (fread(t->w + (unsigned)r * cols, 1, cols, fp) != (unsigned)cols)
            damaged();
    }
#else
    for (r = 0; r < rows; r++) {
        unsigned char discard[MAXHID];
        if (read_float(fp) <= 0.0f) damaged();
        if (fread(discard, 1, cols, fp) != (unsigned)cols) damaged();
    }
#endif
    tables_done++;
    if (on_load)
        on_load(tables_done, tables_total);
}

static float *load_gains(FILE *fp)
{
    float *g = (float *)get_memory((unsigned)D * sizeof(float));
    int i;
    for (i = 0; i < D; i++) g[i] = read_float(fp);
    return g;
}

static int read16(FILE *fp)
{
    int lo = fgetc(fp), hi = fgetc(fp);
    if (lo == EOF || hi == EOF)
        damaged();
    return lo | (hi << 8);
}

static void load_model(const char *name)
{
    FILE *fp;
    char magic[4];
    int l;

    if (sizeof(char *) != 4 && sizeof(int) == 2)
        fail("Nieprawidlowy model pamieci kompilatora.");
    if (sizeof(float) != 4)
        fail("Nieprawidlowy rozmiar float.");
    fp = loading_file = fopen(name, "rb");
    if (fp == NULL)
        fail("Brak POLTINY.BIN obok programu PolTiny.");
    if (fread(magic, 1, 4, fp) != 4 || memcmp(magic, "TPL1", 4) != 0)
        fail("To nie jest model PolTiny (TPL1).");
    D = read16(fp); L = read16(fp); H = read16(fp); HID = read16(fp);
    if (read16(fp) != VOCAB) fail("Bledny alfabet modelu PolTiny.");
    if (D < 8 || D > MAXD || L < 1 || L > MAXL || H < 1 || D % H != 0 || HID < 8 || HID > MAXHID)
        fail("Nieobslugiwane rozmiary sieci.");
    HD = D / H;
    tables_done = 0;
    tables_total = 2 + 6 * L;
    att_div = sqrtf((float)HD);
#ifndef TINY_RESIDENT
    {
        unsigned max_rows = HID > CTX ? HID : CTX;
        if (max_rows < (unsigned)D) max_rows = D;
        /* Keep on-disk rows intact: read a whole table in sequential chunks. */
        stream_data = get_memory(max_rows * ((unsigned)D + sizeof(float)));
    }
#endif
    load_table(fp, &emb, VOCAB, D);
    load_table(fp, &pos, CTX, D);
    for (l = 0; l < L; l++) {
        g1[l] = load_gains(fp);
        load_table(fp, &wq[l], D, D);
        load_table(fp, &wk[l], D, D);
        load_table(fp, &wv[l], D, D);
        load_table(fp, &wo[l], D, D);
        g2[l] = load_gains(fp);
        load_table(fp, &f1[l], HID, D);
        load_table(fp, &f2[l], D, HID);
    }
    gf = load_gains(fp);
    if (fgetc(fp) != EOF)
        fail("Nieprawidlowy rozmiar pliku modelu.");
#ifdef TINY_RESIDENT
    fclose(fp);
#else
    model_file = fp;
#endif
    loading_file = NULL;
}

/* ---- the network ------------------------------------------------- */

/* Memory of earlier letters: for every layer and position, the "key" and
   "value" lists of D numbers, kept as bytes with one scale per list. */
static signed char *kc[MAXL], *vc[MAXL];
static float *ks[MAXL], *vs[MAXL];

/* Work buffers (static, so they do not use the small DOS stack). */
static float bx[MAXD], bh[MAXD], bq[MAXD], bt[MAXD], ba[MAXD], bm[MAXHID], bs[CTX];
static float layer_act[MAXL];               /* how busy each layer was */

static void alloc_memory(void)
{
    int l;
    unsigned char *pool = get_memory((unsigned)L * CTX * (2 * D + 2 * sizeof(float)));
    for (l = 0; l < L; l++) {
        /* CTX is divisible by four, so each float region stays aligned. */
        kc[l] = (signed char *)pool; pool += CTX * D;
        vc[l] = (signed char *)pool; pool += CTX * D;
        ks[l] = (float *)pool; pool += CTX * sizeof(float);
        vs[l] = (float *)pool; pool += CTX * sizeof(float);
    }
}

/* Symmetric int16 activations. Each int8/int16 dot product fits int32. */
#if !defined(TINY_REFERENCE_MATVEC) || !defined(TINY_REFERENCE_ATTENTION)
static float quantize(const float *x, int n, short *q)
{
    int i;
    float largest = 0.0f, factor;
    for (i = 0; i < n; i++) {
        float v = x[i] < 0.0f ? -x[i] : x[i];
        if (v > largest) largest = v;
    }
    if (largest < 1e-20f) largest = 1e-20f;
    factor = 32767.0f / largest;
    for (i = 0; i < n; i++) {
        float v = x[i] * factor;
        if (v > 32767.0f) v = 32767.0f;
        if (v < -32767.0f) v = -32767.0f;
        q[i] = (short)v;
    }
    return largest / 32767.0f;
}
#endif

/* y = table * x */
static void matvec(const Table *t, const float *x, float *y)
{
    int r, c, cols = t->cols;
    const signed char *w;
#ifndef TINY_RESIDENT
    unsigned bytes = (unsigned)t->rows * (cols + 4), offset;
    if (fseek(model_file, t->offset, SEEK_SET)) fail("Blad pozycjonowania POLTINY.BIN");
    for (offset = 0; offset < bytes;) {
        unsigned chunk = bytes - offset;
        if (chunk > 4096) chunk = 4096;
        checkpoint(TINY_WORK_DISK, offset, bytes);
        if (fread(stream_data + offset, 1, chunk, model_file) != chunk)
            fail("Blad odczytu. Pozostaw dyskietke PolTiny w stacji.");
        offset += chunk;
    }
    w = (const signed char *)stream_data + 4;
#else
    w = t->w;
#endif
    float s;
#ifndef TINY_REFERENCE_MATVEC
    short quant[MAXHID];
    float factor = quantize(x, cols, quant);
#endif
    for (r = 0; r < t->rows; r++) {
        if (!(r & 15)) checkpoint(TINY_WORK_MATH, r, t->rows);
#ifdef TINY_REFERENCE_MATVEC
        s = 0.0f;
        for (c = 0; c < cols; c++) s += w[c] * x[c];
#else
        /* At most 512 * 128 * 32767: always fits a signed 32-bit long.
           Both factors fit 16 bits, so a 68000 can use MULS.W. */
        long dot = 0;
        for (c = 0; c < cols; c++) dot += (long)((short)w[c] * quant[c]);
        s = (float)dot * factor;
#endif
#ifdef TINY_RESIDENT
        y[r] = s * t->scale[r];
#else
        y[r] = s * decode_float((const unsigned char *)w - 4);
#endif
        w += cols;
#ifndef TINY_RESIDENT
        w += 4;
#endif
    }
}

/* y = x scaled to a standard size, times the gains g */
static void norm(const float *x, const float *g, float *y)
{
    int i;
    float s = 0.0f;
    for (i = 0; i < D; i++)
        s += x[i] * x[i];
    s = 1.0f / sqrtf(s / D + 1e-5f);
    for (i = 0; i < D; i++)
        y[i] = x[i] * s * g[i];
}

/* e to the power x, quietly 0 for very negative x (no underflow messages) */
static float safe_exp(float x)
{
    if (x < -60.0f)
        return 0.0f;
    return expf(x);
}

static void observe_prediction(const float *score, int best)
{
    int i, rank, candidate;
    float sum = 0.0f;
    for (i = 0; i < VOCAB; i++) sum += safe_exp(score[i] - score[best]);
    for (rank = 0; rank < TINY_CANDIDATES; rank++) {
        candidate = -1;
        for (i = 0; i < VOCAB; i++) {
            int previous, used = 0;
            for (previous = 0; previous < rank; previous++)
                if (telemetry.candidate[previous] == i) used = 1;
            if (!used && (candidate < 0 || score[i] > score[candidate])) candidate = i;
        }
        telemetry.candidate[rank] = candidate;
        telemetry.probability[rank] = safe_exp(score[candidate] - score[best]) / sum;
    }
    telemetry.has_prediction = 1;
    observe(TINY_OBSERVE_PREDICTION);
}

/* keep a list of D numbers as bytes, returning the scale */
static float store(signed char *dst, const float *src)
{
    int i;
    float big = 0.0f, v, k;
    for (i = 0; i < D; i++) {
        v = src[i] < 0 ? -src[i] : src[i];
        if (v > big) big = v;
    }
    if (big < 1e-20f)
        big = 1e-20f;
    k = 127.0f / big;
    for (i = 0; i < D; i++) {
        v = src[i] * k;
        dst[i] = (signed char)(v < 0 ? v - 0.5f : v + 0.5f);
    }
    return big / 127.0f;
}

/* Feed letter number `tok` at position `p` (0, 1, 2, ...).
   Fills score[0..VOCAB-1]: how well each letter fits as the next one. */
static void step(int tok, int p, float *score)
{
    int i, j, l, h;
#ifdef TINY_RESIDENT
    const signed char *e = emb.w + tok * D;
    const signed char *q = pos.w + p * D;
#else
    signed char e[MAXD], q[MAXD];
#endif
    const signed char *kp;
    float s, big, sum, es, ps;
#ifndef TINY_REFERENCE_ATTENTION
    short query[MAXD], coefficients[CTX];
    float query_scale;
#else
    const signed char *vp;
#endif
    if (observer) {
        telemetry.position = p; telemetry.token = tok; telemetry.layers = L;
        telemetry.layer = -1; telemetry.head = -1; telemetry.layer_mask = 0;
        telemetry.attention_length = 0;
        memset(telemetry.activity, 0, sizeof(telemetry.activity));
        observe(TINY_OBSERVE_TOKEN);
    }
#ifdef TINY_RESIDENT
    es = emb.scale[tok]; ps = pos.scale[p];
#else
    if (fseek(model_file, emb.offset + (long)tok * (D + 4), SEEK_SET))
        fail("Blad pozycjonowania POLTINY.BIN");
    es = read_float(model_file);
    if (fread(e, 1, D, model_file) != (unsigned)D) fail("Blad odczytu POLTINY.BIN");
    if (fseek(model_file, pos.offset + (long)p * (D + 4), SEEK_SET))
        fail("Blad pozycjonowania POLTINY.BIN");
    ps = read_float(model_file);
    if (fread(q, 1, D, model_file) != (unsigned)D) fail("Blad odczytu POLTINY.BIN");
#endif

    for (i = 0; i < D; i++)
        bx[i] = e[i] * es + q[i] * ps;

    for (l = 0; l < L; l++) {
        if (observer) {
            telemetry.layer = l;
            telemetry.attention_length = 0;
            observe(TINY_OBSERVE_LAYER_START);
        }
        checkpoint(TINY_WORK_LAYER, l + 1, L);
        /* look back at the earlier letters */
        norm(bx, g1[l], bh);
        /* Follow the file's Q/K/V order to avoid floppy seeks backwards. */
        matvec(&wq[l], bh, bq);
        matvec(&wk[l], bh, bt);
        ks[l][p] = store(kc[l] + p * D, bt);
        matvec(&wv[l], bh, bt);
        vs[l][p] = store(vc[l] + p * D, bt);
#ifndef TINY_REFERENCE_ATTENTION
        query_scale = quantize(bq, D, query);
#endif
        for (h = 0; h < H; h++) {
            checkpoint(TINY_WORK_ATTENTION, h, H);
            big = -1e30f;
            for (j = 0; j <= p; j++) {
                if (!(j & 7)) checkpoint(TINY_WORK_ATTENTION, j, p + 1);
                kp = kc[l] + j * D + h * HD;
#ifdef TINY_REFERENCE_ATTENTION
                s = 0.0f;
                for (i = 0; i < HD; i++)
                    s += bq[h * HD + i] * kp[i];
#else
                long dot = 0;
                for (i = 0; i < HD; i++)
                    dot += (long)((short)kp[i] * query[h * HD + i]);
                s = (float)dot * query_scale;
#endif
                s = s * ks[l][j] / att_div;
                bs[j] = s;
                if (s > big) big = s;
            }
            sum = 0.0f;
            for (j = 0; j <= p; j++) {
                bs[j] = safe_exp(bs[j] - big);
                sum += bs[j];
            }
            if (observer) {
                telemetry.layer = l; telemetry.head = h;
                telemetry.attention_length = p + 1;
                for (j = 0; j <= p; j++) telemetry.attention[j] = bs[j] / sum;
                observe(TINY_OBSERVE_ATTENTION);
            }
#ifdef TINY_REFERENCE_ATTENTION
            for (i = 0; i < HD; i++)
                ba[h * HD + i] = 0.0f;
            for (j = 0; j <= p; j++) {
                if (bs[j] == 0.0f)
                    continue;
                vp = vc[l] + j * D + h * HD;
                s = bs[j] * vs[l][j] / sum;
                for (i = 0; i < HD; i++)
                    ba[h * HD + i] += s * vp[i];
            }
#else
            /* Softmax probabilities times the cached value scales become
               int16 coefficients; accumulate int8 values in int32. */
            for (j = 0; j <= p; j++) bs[j] = bs[j] * vs[l][j] / sum;
            s = quantize(bs, p + 1, coefficients);
            for (i = 0; i < HD; i++) {
                long dot = 0;
                const signed char *value = vc[l] + h * HD + i;
                if (!(i & 7)) checkpoint(TINY_WORK_ATTENTION, i, HD);
                for (j = 0; j <= p; j++, value += D)
                    dot += (long)((short)*value * coefficients[j]);
                ba[h * HD + i] = (float)dot * s;
            }
#endif
        }
        matvec(&wo[l], ba, bt);
        for (i = 0; i < D; i++)
            bx[i] += bt[i];

        /* think about it */
        norm(bx, g2[l], bh);
        matvec(&f1[l], bh, bm);
        s = 0.0f;
        for (i = 0; i < HID; i++) {
            if (bm[i] < 0.0f) bm[i] = 0.0f;
            else s += bm[i];
        }
        layer_act[l] = s / HID;                /* for the activity display */
        if (observer) {
            telemetry.activity[l] = layer_act[l];
            telemetry.layer_mask |= 1U << l;
            observe(TINY_OBSERVE_LAYER);
        }
        matvec(&f2[l], bm, bt);
        for (i = 0; i < D; i++)
            bx[i] += bt[i];
    }
    /* Prompt letters only populate the cache. Their logits are unused. */
    if (score) {
        norm(bx, gf, bh);
        matvec(&emb, bh, score);
    }
}


void tiny_free(void)
{
    if (model_file) { fclose(model_file); model_file = NULL; }
    while (allocation_count) free(allocations[--allocation_count]);
    allocated_bytes = 0;
}

int tiny_load(const char *path)
{
    tiny_free();
    error_text = NULL;
    if (setjmp(load_jump)) {
        if (loading_file) { fclose(loading_file); loading_file = NULL; }
        tiny_free();
        return 0;
    }
    load_model(path);
    alloc_memory();
    return 1;
}

const char *tiny_error(void) { return error_text ? error_text : "Nieznany blad"; }
unsigned long tiny_memory(void) { return allocated_bytes; }
int tiny_width(void) { return D; }
int tiny_layers(void) { return L; }

int tiny_clean(const char *line, char *q)
{
    char local[256];
    int n=0,i;
    pol_local(line,local,sizeof(local));
    for(i=0;local[i]&&n<TINY_MAXQ;i++)
        if(pol_token((unsigned char)local[i])>1)
            q[n++]=pol_lower((unsigned char)local[i]);
    while (n && q[n-1] == ' ') n--;
    q[n] = 0;
    return n;
}

static int answer_inner(const char *question, char *out, int limit,
                TinyProgress progress, TinyLetter letter, void *user)
{
    char q[TINY_MAXQ + 1];
    float score[VOCAB];
    int p, i, best, letters = 0, n;
    out[0] = 0;
    if (!allocation_count) return -2;
    n = tiny_clean(question, q);
    if (!n) return 0;
    if (observer) memset(&telemetry, 0, sizeof(telemetry));
    if (limit < 1 || limit > CTX) limit = CTX;
    for (p = 0; p < n; p++) {
        if (progress && !progress(0, p, n, user)) return -1;
        step(pol_token((unsigned char)q[p]), p, NULL);
    }
    if (progress && !progress(0, n, n, user)) return -1;
    step(1, p++, score);
    for (; p < CTX && letters < limit; p++) {
        if (progress && !progress(1, letters, limit, user)) return -1;
        best = 0;
        for (i = 1; i < VOCAB; i++) if (score[i] > score[best]) best = i;
        if (observer) observe_prediction(score, best);
        if (best <= 1) break;
        out[letters++] = (char)pol_letter(best);
        out[letters] = 0;
        if (letter) letter(pol_letter(best), user);
        if (letters < limit && p + 1 < CTX) step(best, p, score);
    }
    return letters;
}

int tiny_answer(const char *question, char *out, int limit,
                TinyProgress progress, TinyLetter letter, void *user)
{
    work_cancelled = 0;
    if (setjmp(load_jump)) return work_cancelled ? -1 : -3;
    return answer_inner(question, out, limit, progress, letter, user);
}
