Unmodified `libgcc/config/m68k/lb1sf68.S` from GCC 6.5.0:
https://github.com/gcc-mirror/gcc/blob/releases/gcc-6.5.0/libgcc/config/m68k/lb1sf68.S

Built with L_float, L_floatex and the six single precision comparison aliases.
This supplies static 68000 software floating point in place of libnix's
mathieeesingbas.library stubs, which need AmigaOS 2.x libraries.

GPLv3 with the GCC Runtime Library Exception 3.1. See COPYING3 and
COPYING.RUNTIME. The exception permits linking this runtime with the MIT
application. The assembly source and its notices remain under their own license.
