import os,shutil,subprocess,json,zipfile,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1];os.chdir(R);D=R/'dist';disk=D/'dyskietka'
disk.mkdir(parents=True,exist_ok=True)
catalog=[json.loads(x) for x in (R/'training/catalog.jsonl').read_text().splitlines()]
text='PolTiny: material treningowy, nie gwarancja odpowiedzi.\nKodowanie ISO-8859-2. Katalog nie jest przeszukiwany przez siec.\n';last=''
for r in catalog:
    if r['topic']!=last:text+='\n['+r['topic']+']\n';last=r['topic']
    q=r['questions'][0]
    for a,b in [('stolica kraju ',''),('kontynent kraju ',''),('symbol pierwiastka ','symbol '),('liczba atomowa: ','Z: '),('jaki pierwiastek ma symbol ','symbol '),('jaki pierwiastek ma liczbę atomową ','Z: ')]:
        if q.startswith(a):q=b+q[len(a):];break
    text+=q+'='+r['answer'].rstrip('.')+'\n'
(R/'build/WIEDZA.TXT').write_bytes(text.encode('iso8859-2'))
for name in ['C','S']:(disk/name).mkdir(exist_ok=True)
sources=[('build/PolTiny','PolTiny'),('build/PolTiny.info','PolTiny.info'),('build/TinyStack','C/TinyStack'),('amiga/Startup-Sequence','S/Startup-Sequence'),('build/POLTINY.BIN','POLTINY.BIN'),('build/WIEDZA.TXT','WIEDZA.TXT'),('README.md','CZYTAJ.TXT'),('LICENSE','LICENSE'),('DATA_LICENSES.md','DANE-LICENCJE.txt'),('third_party/gcc/COPYING3','COPYING3'),('third_party/gcc/COPYING.RUNTIME','COPYING.RUNTIME'),('third_party/gcc/README.md','THIRD-PARTY.txt')]
for src,dest in sources:
    data=(R/src).read_bytes()
    if dest in ['CZYTAJ.TXT','DANE-LICENCJE.txt']:data=data.decode().encode('iso8859-2',errors='replace')
    (disk/dest).write_bytes(data)
xdftool=os.environ.get('XDFTOOL','/workspace/toolchains/venv/bin/xdftool')
adf=D/'PolTiny-A500-512K-boot.adf'
if adf.exists():adf.unlink()
def cmd(*args):return subprocess.check_output([xdftool,str(adf),*args],text=True)
cmd('create','+','format','POLTINY','DOS0');cmd('makedir','C','+','makedir','S')
for p in sorted(disk.rglob('*')):
    if p.is_file():cmd('write',str(p),str(p.relative_to(disk)))
cmd('protect','PolTiny','rwed','+','protect','C/TinyStack','rwed');cmd('boot','install','boot1x')
check=cmd('fsck');print(check);listing=cmd('list');print(listing);info=cmd('info');print(info)
(R/'build/disk-list.txt').write_text(listing);(R/'build/fsck.txt').write_text(check)
(R/'build/disk-info.txt').write_text(info)
for path,files,prefix in [(D/'PolTiny-A500-512K.zip',list(disk.rglob('*')),''),(D/'PolTiny-zrodla.zip',[p for base in ['amiga','training','tools','tests','third_party'] for p in (R/base).rglob('*')]+[R/'Makefile',R/'README.md',R/'LICENSE',R/'DATA_LICENSES.md',R/'build/POLTINY.BIN'],'poltiny/')]:
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(files):
            if p.is_file() and '__pycache__' not in str(p) and p.suffix not in ['.pt']:
                rel=p.relative_to(disk if not prefix else R);z.write(p,prefix+str(rel))
metadata={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in D.glob('*') if p.is_file() and p.suffix in ['.adf','.zip']}
(D/'SHA256.json').write_text(json.dumps(metadata,indent=2)+'\n');print(json.dumps(metadata,indent=2))
