#!/usr/bin/env python3
"""Write a classic two-plane WBTOOL DiskObject, readable by icon.library 1.3."""
import struct
import sys
from pathlib import Path


def make_icon():
    width, height = 48, 24
    header = bytearray(78)
    struct.pack_into(">HH", header, 0, 0xE310, 1)
    struct.pack_into(">HHHHH", header, 12, width, height, 4, 1, 1)
    struct.pack_into(">I", header, 22, 1)  # GadgetRender is present
    header[48] = 3  # WBTOOL
    struct.pack_into(">III", header, 58, 0x80000000, 0x80000000, 0)
    struct.pack_into(">I", header, 74, 16384)
    pixels = [[0] * width for _ in range(height)]
    for y in range(2, 21):
        for x in range(3, 45):
            pixels[y][x] = 1 if x in (3, 44) or y in (2, 20) else 2
    # A small orange neural network on a white framed terminal.
    nodes = [(10, 7), (10, 15), (23, 6), (23, 12), (23, 17), (37, 10), (37, 16)]
    for a, b in [(0, 2), (0, 3), (1, 3), (1, 4), (2, 5), (3, 5), (3, 6), (4, 6)]:
        x0, y0 = nodes[a]
        x1, y1 = nodes[b]
        for x in range(x0, x1 + 1):
            y = round(y0 + (y1 - y0) * (x - x0) / (x1 - x0))
            pixels[y][x] = 1
    for x, y in nodes:
        for yy in range(y - 1, y + 2):
            for xx in range(x - 1, x + 2):
                pixels[yy][xx] = 3
    image = struct.pack(">hhhhhIBBI", 0, 0, width, height, 2, 1, 3, 0, 0)
    planes = bytearray()
    for plane in range(2):
        for row in pixels:
            for start in range(0, width, 16):
                word = sum(((row[start + bit] >> plane) & 1) << (15 - bit) for bit in range(16))
                planes += struct.pack(">H", word)
    return bytes(header) + image + planes


if __name__ == "__main__":
    Path(sys.argv[1]).write_bytes(make_icon())
