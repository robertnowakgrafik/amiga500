"""Package upload-ready graphics, editable masters and verified evidence."""
from pathlib import Path
import json,zipfile,hashlib,tempfile,subprocess,sys
from PIL import Image
from pypdf import PdfReader
from html.parser import HTMLParser
ROOT=Path(__file__).resolve().parents[1]
DEST=ROOT.parent/'dist/PolTiny-Behance-case-study.zip'
meta=json.loads((ROOT/'METADANE.json').read_text())
manifest=json.loads((ROOT/'MANIFEST.json').read_text())
assert len(manifest)==len(meta['kolejnosc'])==9
assert len(PdfReader(ROOT/'PolTiny-case-study.pdf').pages)==9
for i,row in enumerate(manifest):
    p=ROOT/row['plik'];assert p.exists() and row['kolejnosc']==i+1
    with Image.open(p) as im:assert im.size==(1400,row['wysokosc'])
assert Image.open(ROOT/meta['okladka']).size==(808,632)
class Links(HTMLParser):
    def handle_starttag(self,t,attrs):
        for k,v in attrs:
            if k in ['src','href'] and '://' not in v and not v.startswith('#'):
                assert (ROOT/v).exists(),v
links=Links();links.feed((ROOT/'PODGLAD.html').read_text())
files=[p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name not in ['dump_telemetry','SHA256SUMS.txt']]
sums=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(ROOT).as_posix()+'\n' for p in sorted(files))
(ROOT/'SHA256SUMS.txt').write_text(sums)
files.append(ROOT/'SHA256SUMS.txt')
DEST.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(DEST,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files):z.write(p,'PolTiny-Behance/'+p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(DEST) as z:
    assert z.testzip() is None
    assert all(not n.startswith('/') and '..' not in Path(n).parts for n in z.namelist())
    with tempfile.TemporaryDirectory() as td:
        z.extractall(td)
        extracted=Path(td)/'PolTiny-Behance'
        # Verify that the bundled generator also works without the original repo.
        subprocess.run([sys.executable,str(extracted/'src/build_case.py')],check=True,capture_output=True)
        for name in meta['kolejnosc']:
            assert (extracted/name).read_bytes()==(ROOT/name).read_bytes(),name
print(json.dumps({'archive':str(DEST),'files':len(files),'boards':len(manifest),'bytes':DEST.stat().st_size,'sha256':hashlib.sha256(DEST.read_bytes()).hexdigest(),'checks':['9 JPEG boards','808×632 cover','9 PDF pages','local links','ZIP CRC','fresh extraction and standalone identical render']},ensure_ascii=False,indent=2))
