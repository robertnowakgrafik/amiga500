/* Export real model telemetry for the Behance case-study illustrations. */
#include "tiny.h"
#include "polish.h"
#include <stdio.h>
static void capture(const TinyTelemetry *s,void *u){
 int i;char local[2],utf8[8];(void)u;
 if(s->event!=TINY_OBSERVE_PREDICTION)return;
 printf("{\"question\":\"stolica polski\",\"position\":%d,\"layer\":%d,\"head\":%d,\"activity\":[",s->position,s->layer+1,s->head+1);
 for(i=0;i<s->layers;i++)printf("%s%.8g",i?",":"",s->activity[i]);
 printf("],\"attention\":[");for(i=0;i<s->attention_length;i++)printf("%s%.8g",i?",":"",s->attention[i]);
 printf("],\"candidates\":[");
 for(i=0;i<3;i++){local[0]=pol_letter(s->candidate[i]);local[1]=0;pol_utf8(local,utf8,sizeof(utf8));printf("%s{\"token\":%d,\"letter\":\"%s\",\"probability\":%.8g}",i?",":"",s->candidate[i],utf8,s->probability[i]);}
 puts("]}");
}
int main(int argc,char **argv){char out[129];int n;if(argc!=2||!tiny_load(argv[1]))return 1;tiny_set_observer(capture,NULL);n=tiny_answer("stolica polski",out,1,NULL,NULL,NULL);tiny_free();return n==1?0:2;}
