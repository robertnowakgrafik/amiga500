# Odtworzenie plansz

Generator korzysta z danych w `dane/` i dołączonych krojów w `fonty/`.
Może pracować samodzielnie po rozpakowaniu paczki.

Wymagania: Python 3.10+, Pillow, ReportLab.

```
python -m pip install Pillow ReportLab
python src/build_case.py
```

Powstaną JPG w `materialy/`, PNG/SVG w `edycja/`, PDF, podgląd HTML,
tekst projektu, instrukcja dla Claude i metadane. Generator nadpisuje te pliki.
Źródła liczb nie są nadpisywane, jeżeli paczka nie znajduje się w repozytorium
oryginalnego PolTiny.

`dump_telemetry.c` dokumentuje eksport rzeczywistej telemetrii. Ponowne
wykonanie tego eksportu wymaga kodu silnika oraz pliku `POLTINY.BIN` z projektu
PolTiny. Do ponownego składania plansz wystarcza dołączona `telemetria.json`.

SVG zawierają tekst z nazwami krojów Noto Sans Display i DejaVu Sans Mono.
Przed edycją zainstaluj dołączone fonty zgodnie z ich licencjami. PNG i JPG
zachowują wygląd bez instalowania fontów. Grafika dyskietki jest oryginalną
ilustracją geometryczną, a widok interfejsu jest oznaczoną rekonstrukcją.
