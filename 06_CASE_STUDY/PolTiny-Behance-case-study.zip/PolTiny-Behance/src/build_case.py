"""Create Behance boards from verified project data; no fabricated screenshots.
Outputs matching JPEG, PNG, editable SVG, PDF and a local HTML preview.
"""
import json,math,html,shutil,csv,hashlib,zipfile
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader

OUT=Path(__file__).resolve().parents[1];ROOT=OUT.parent
ART=OUT/'materialy';EDIT=OUT/'edycja';DATA=OUT/'dane'
for p in [ART,EDIT,DATA]:p.mkdir(exist_ok=True,parents=True)
RUN=json.loads((ROOT/'training/run.json' if (ROOT/'training/run.json').exists() else DATA/'trening.json').read_text())
DS=json.loads((ROOT/'training/dataset.json' if (ROOT/'training/dataset.json').exists() else DATA/'korpus.json').read_text())
if (ROOT/'training/evaluation.json').exists():EV=json.loads((ROOT/'training/evaluation.json').read_text())
else:
    summary=json.loads((DATA/'wyniki.json').read_text())
    EV={'model_sha256':summary['model_sha256'],'sets':{k:{'correct':r['poprawne'],'total':r['wszystkie'],'accuracy':r['skutecznosc'],'topics':r['tematy']} for k,r in summary['ocena'].items()}}
B=json.loads((ROOT/'tests/benchmark.json' if (ROOT/'tests/benchmark.json').exists() else DATA/'benchmark.json').read_text())
TE=json.loads((DATA/'telemetria.json').read_text())
PAPER='#F1F0E9';INK='#102331';BLUE='#1659F5';MUTED='#61717B';ORANGE='#FF8049';WHITE='#FFFFFF';LINE='#CCD0CA';ACID='#DFF397'
FONTS={'regular':'/usr/share/fonts/truetype/noto/NotoSansDisplay-Regular.ttf','bold':'/usr/share/fonts/truetype/noto/NotoSansDisplay-Bold.ttf','mono':'/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'}
for weight,path in list(FONTS.items()):
    bundled=OUT/'fonty'/Path(path).name
    if bundled.exists():FONTS[weight]=str(bundled)
FC={}
def font(size,weight='regular'):
    key=(size,weight)
    if key not in FC:FC[key]=ImageFont.truetype(FONTS[weight],int(size))
    return FC[key]
def esc(s):return html.escape(str(s),quote=True)

class Board:
    def __init__(self,name,height,bg=PAPER,num=1,width=1400):
        self.name=name;self.h=height;self.w=width;self.bg=bg;self.num=num
        self.im=Image.new('RGB',(width,height),bg);self.d=ImageDraw.Draw(self.im);self.parts=[];self.alltext=[];self.bounds=[]
        self.rect(0,0,width,height,bg)
    def rect(self,x,y,w,h,fill,stroke=None,sw=1,r=0):
        box=(int(x),int(y),int(x+w),int(y+h))
        if r:self.d.rounded_rectangle(box,r,fill,outline=stroke,width=int(sw))
        else:self.d.rectangle(box,fill,outline=stroke,width=int(sw))
        self.parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke or "none"}" stroke-width="{sw}"/>')
    def line(self,x1,y1,x2,y2,color=INK,sw=1):
        self.d.line((int(x1),int(y1),int(x2),int(y2)),fill=color,width=int(sw))
        self.parts.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="{sw}"/>')
    def poly(self,pts,fill,stroke=None,sw=1):
        self.d.polygon(pts,fill=fill)
        if stroke:self.d.line(pts+[pts[0]],fill=stroke,width=int(sw),joint='curve')
        self.parts.append(f'<polygon points="'+ ' '.join(f'{x},{y}' for x,y in pts)+f'" fill="{fill}" stroke="{stroke or "none"}" stroke-width="{sw}"/>')
    def circle(self,x,y,r,fill,stroke=None,sw=1):
        self.d.ellipse((int(x-r),int(y-r),int(x+r),int(y+r)),fill=fill,outline=stroke,width=int(sw))
        self.parts.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="{stroke or "none"}" stroke-width="{sw}"/>')
    def text(self,x,y,s,size=30,color=INK,weight='regular',maxwidth=None):
        f=font(size,weight);asc,desc=f.getmetrics();width=self.d.textlength(str(s),font=f)
        if maxwidth is not None:assert width<=maxwidth+1,(self.name,s,width,maxwidth)
        self.d.text((x,y+asc),str(s),fill=color,font=f,anchor='ls')
        family='DejaVu Sans Mono' if weight=='mono' else 'Noto Sans Display'
        self.parts.append(f'<text x="{x}" y="{y+asc}" font-family="{family}" font-size="{size}" font-weight="{700 if weight=="bold" else 400}" fill="{color}">{esc(s)}</text>')
        self.alltext.append(str(s));self.bounds.append((x,y,width,size*1.35,str(s)))
        return width
    def para(self,x,y,s,width=1100,size=29,color=INK,weight='regular',lh=1.45):
        f=font(size,weight);yy=y
        for block in s.split('\n'):
            words=block.split();line=''
            for w in words:
                test=(line+' '+w).strip()
                if self.d.textlength(test,font=f)>width and line:
                    self.text(x,yy,line,size,color,weight,maxwidth=width);yy+=size*lh;line=w
                else:line=test
            self.text(x,yy,line,size,color,weight,maxwidth=width);yy+=size*lh
        return yy
    def heading(self,kicker,lines,sub=None,color=INK):
        self.text(88,72,kicker,19,MUTED if color==INK else '#C9D9FF','mono')
        y=130
        for s in lines:self.text(88,y,s,66,color,'bold',maxwidth=1224);y+=78
        if sub:self.para(88,y+26,sub,1130,28,MUTED if color==INK else WHITE)
    def footer(self,color=INK):
        self.line(88,self.h-70,self.w-88,self.h-70,LINE if color==INK else '#6F94EF')
        self.text(88,self.h-53,'POLTINY / AMIGA 500 / STUDIUM PROJEKTU',16,color,'mono')
        self.text(self.w-154,self.h-53,f'{self.num:02d} / 09',16,color,'mono')
    def save(self):
        self.im.save(ART/f'{self.name}.jpg',quality=96,subsampling=0,optimize=True)
        self.im.save(EDIT/f'{self.name}.png',optimize=True)
        svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="{self.w}" height="{self.h}" viewBox="0 0 {self.w} {self.h}"><title>{esc(self.name)}</title>'+''.join(self.parts)+'</svg>'
        (EDIT/f'{self.name}.svg').write_text(svg)
        for x,y,w,h,s in self.bounds:assert x>=0 and x+w<=self.w+1 and y>=0 and y+h<=self.h,(self.name,s,x,y,w,h)
        return self

def arrow(b,x,y,x2,color=BLUE):
    b.line(x,y,x2,y,color,3);b.poly([(x2,y),(x2-10,y-7),(x2-10,y+7)],color)
def badge(b,x,y,s,color=BLUE,fg=WHITE):
    w=b.d.textlength(s,font=font(18,'mono'))+32;b.rect(x,y,w,38,color,r=3);b.text(x+16,y+6,s,18,fg,'mono');return w
def floppy(b,x,y,scale=1,blue=BLUE):
    def p(a,c):return x+a*scale,y+c*scale
    def rr(a,c,w,h,fill,stroke=None,sw=1,r=0):b.rect(*p(a,c),w*scale,h*scale,fill,stroke,sw*scale,r*scale)
    b.poly([p(14,18),p(400,18),p(440,60),p(440,508),p(14,508)],'#0835AD')
    b.poly([p(0,0),p(380,0),p(424,44),p(424,490),p(0,490)],PAPER,INK,2)
    rr(82,0,245,160,'#D1D7D3',INK,2);rr(118,18,72,119,INK);rr(216,27,83,101,'#F5F4EF',INK,1)
    for a in range(6):rr(224+a*10,38,2,78,'#B7BFBC')
    rr(46,207,331,204,WHITE,INK,2)
    rr(46,207,331,52,blue)
    b.text(*p(67,218),'POLTINY PL',int(25*scale),WHITE,'bold')
    b.text(*p(65,283),'MODEL: INT8',int(21*scale),INK,'mono')
    b.text(*p(65,320),'A500 / 512 KiB',int(19*scale),INK,'mono')
    b.line(*p(66,366),*p(351,366),LINE,max(1,int(scale)))
    b.text(*p(66,376),'OFFLINE  /  DD 880 KiB',int(15*scale),MUTED,'mono')
    rr(23,443,28,25,INK);rr(367,443,28,25,INK)
    b.circle(*p(211,452),14*scale,'#C3CBC7',INK,max(1,int(scale)))

BOARDS=[]
# 01 — Strong cover with an original geometric floppy illustration.
b=Board('01_otwarcie',1100,BLUE,1)
for x in range(88,1360,52):
    for y in range(140,960,52):b.circle(x,y,1,'#3E76F7')
b.text(88,68,'POLTINY PL',23,WHITE,'mono');b.text(1020,68,'EKSPERYMENT / 2026',19,WHITE,'mono')
b.line(88,116,1312,116,'#7198F8')
b.text(80,177,'PolTiny',143,WHITE,'bold');badge(b,89,368,'POLSKI MODEL JĘZYKOWY',WHITE,BLUE)
b.text(88,453,'Jedna dyskietka.',53,WHITE,'bold')
b.text(88,519,'Cały eksperyment.',53,WHITE,'bold')
b.para(88,631,'Port nowego modelu na Amigę 500.\n512 KiB RAM, procesor 68000 i pełna praca offline.',650,29,WHITE)
floppy(b,855,232,.98)
b.line(88,865,1312,865,'#7198F8')
for x,n,label in [(88,'687 616','parametrów modelu'),(510,'99,55%','zajętej dyskietki'),(940,'0','połączeń z siecią')]:
    b.text(x,894,n,50,WHITE,'bold');b.text(x,963,label,23,WHITE)
b.footer(WHITE);BOARDS.append(b.save())
# 02 — Brief and strict hardware budget.
b=Board('02_zalozenia',1060,PAPER,2)
b.heading('01 / WYZWANIE',['Współczesna idea.','Sprzęt z innej epoki.'],'Przygotować większy model po polsku dla fabrycznej Amigi 500, bez rozszerzeń pamięci i bez serwera wykonującego odpowiedzi.')
for x,n,u,desc in [(88,'512','KiB RAM','Cała pamięć komputera,\nłącznie z ekranem i systemem.'),(516,'7,09','MHz','Procesor 68000.\nBrak sprzętowego FPU.'),(944,'880','KiB DD','Jeden obraz dyskietki.\nProgram, wagi i dokumentacja.')]:
    b.rect(x,430,368,270,WHITE)
    b.text(x+28,450,n,78,BLUE,'bold');b.text(x+28,553,u,25,INK,'mono');b.para(x+28,601,desc,315,22,MUTED)
b.text(88,754,'Uzgodniony priorytet: wszystko lokalnie.',36,INK,'bold')
b.para(88,823,'Zaakceptowano wolny i ograniczony model Tiny PL. Celem stał się działający prototyp, jawny budżet zasobów i mierzalne ograniczenia.',1160,29)
b.footer();BOARDS.append(b.save())
# 03 — Traceable training pipeline.
b=Board('03_dane_i_proces',1160,PAPER,3)
b.heading('02 / DANE I PROCES',['Polszczyzna zaczyna się','od danych.'],'Angielski Tiny 2.1 był punktem wyjścia dla architektury i portu. PolTiny otrzymał nowy korpus, nowy alfabet i wagi uczone od losowej inicjalizacji.')
steps=[('01','Korpus PL','914 wpisów\ni zagadnień'),('02','Trening CPU','12 000 kroków\nPyTorch'),('03','Eksport int8','Skala na wiersz\nmacierzy'),('04','Port 68000','C + Intuition\nKickstart 1.3')]
for i,(n,title,desc) in enumerate(steps):
    x=88+i*313;b.circle(x+24,467,24,BLUE);b.text(x+9,452,n,21,WHITE,'mono')
    if i<3:arrow(b,x+60,467,x+285)
    b.text(x,519,title,32,INK,'bold');b.para(x,573,desc,275,25,MUTED)
b.line(88,701,1312,701,LINE)
for x,n,label in [(88,'4 123','pytania treningowe'),(526,'1 337','odłożone sformułowania'),(1006,'115','znaków alfabetu')]:
    b.text(x,748,n,58,BLUE,'bold');b.text(x,825,label,24,INK)
b.para(88,896,'Tematy: geografia, chemia, komputery, podstawy nauki i krótkie rozmowy. Warianty bez polskich liter ułatwiają wpisywanie pytań na Amidze.',1140,28)
b.para(88,1005,'914 to liczba wpisów materiału, nie niezależnych umiejętności. Uczenie odbywało się na współczesnym komputerze; generowanie odpowiedzi działa offline na Amidze.',1180,21,MUTED)
b.footer();BOARDS.append(b.save())
# 04 — Actual architecture and streaming strategy.
b=Board('04_architektura',1200,INK,4)
b.heading('03 / ARCHITEKTURA',['Większa sieć.','Mały bufor.'],'Model przewiduje kolejny znak. Macierze są czytane z dyskietki etapami, bo cały plik wag przekracza pojemność RAM komputera.',WHITE)
boxes=[(88,430,300,'PYTANIE','stolica polski'),(454,430,380,'4 WARSTWY','D128 / H4 / MLP384'),(900,430,412,'WYBÓR ZNAKU','W  a  r  ...')]
for x,y,w,a,c in boxes:
    b.rect(x,y,w,142,'#18394A',stroke='#3B5868');b.text(x+24,y+22,a,20,'#AFC5D3','mono');b.text(x+24,y+67,c,28,WHITE,'bold')
arrow(b,397,501,441,ACID);arrow(b,845,501,886,ACID)
b.rect(88,640,1224,185,BLUE)
b.text(120,666,'DYSKIETKA → BUFOR JEDNEJ MACIERZY → OBLICZENIA',25,WHITE,'mono')
b.para(120,721,'int8 dla wag  ·  int16 dla aktywacji w iloczynach  ·  int32 dla sum\nCache KV: int8 ze skalami. Normalizacja i softmax: programowy float32.',1150,26,WHITE)
for x,n,label in [(88,'128','znaków kontekstu'),(516,'72','znaki pytania'),(944,'1,88×','więcej parametrów niż Tiny EN')]:
    b.text(x,875,n,62,ACID,'bold');b.para(x,960,label,365,24,WHITE)
b.para(88,1055,'Generowanie nie przeszukuje katalogu gotowych odpowiedzi. Historia poprzednich pytań nie jest pamięcią modelu; wagi nie zmieniają się podczas rozmowy.',1190,21,'#AFC5D3')
b.footer(WHITE);BOARDS.append(b.save())
# 05 — UI reconstruction. Values below come from the real engine.
b=Board('05_interfejs_i_telemetria',1250,PAPER,5)
b.heading('04 / DOŚWIADCZENIE UŻYTKOWNIKA',['Pokazać pracę sieci.','Dać możliwość przerwania.'],'Polski interfejs Intuition, dwie ścieżki odpowiedzi i pomiary obliczeń dostępne podczas generowania tekstu.')
x,y,w,h=88,423,1224,409
b.rect(x+13,y+14,w,h,'#C3C8C2');b.rect(x,y,w,h,'#0055AA',WHITE,5)
b.rect(x+4,y+4,w-8,38,WHITE);b.rect(x+14,y+12,23,20,'#0055AA')
b.text(x+48,y+6,'PolTiny PL - Amiga 500 / Workbench 1.3',22,'#0055AA','mono')
b.rect(x+w-36,y+12,20,20,'#0055AA')
for yy,ss in [(66,'PolTiny: nowa sieć uczona po polsku.'),(102,'> stolica polski'),(142,'W'),(200,'Wynik pełnej odpowiedzi w teście CLI:'),(232,'Warszawa.')]:b.text(x+22,y+yy,ss,22,WHITE,'mono',maxwidth=640)
b.line(x+665,y+59,x+665,y+276,WHITE,2)
b.text(x+689,y+60,'WARSTWY / średnia ReLU',18,WHITE,'mono')
peak=max(TE['activity'])
for i,v in enumerate(TE['activity']):
    bx=x+705+i*114;bh=int(v/peak*43)
    b.rect(bx,y+145-bh,75,max(1,bh),ORANGE if i==3 else WHITE);b.text(bx+18,y+151,'L'+str(i+1),16,WHITE,'mono')
b.text(x+689,y+190,'UWAGA / L4 G4',18,WHITE,'mono')
peak=max(TE['attention'])
for i,v in enumerate(TE['attention']):b.rect(x+704+i*31,y+257-int(v/peak*35),21,max(1,int(v/peak*35)),ORANGE if i==11 else WHITE)
b.text(x+689,y+271,'W: 99,995% P(kolejnego znaku)',18,WHITE,'mono')
b.text(x+20,y+309,'PL: stolica polski',22,WHITE,'mono')
b.rect(x+17,y+351,224,36,'#0055AA',WHITE,2);b.text(x+30,y+352,'[ Odpowiedz ]',22,WHITE,'mono')
b.rect(x+267,y+351,244,36,'#0055AA',WHITE,2);b.text(x+283,y+352,'[ Stop / Esc ]',22,WHITE,'mono')
b.para(88,874,'Rekonstrukcja widoku według kodu — nie zrzut z uruchomionego GUI. Słupki pochodzą z rzeczywistej telemetrii silnika C dla pierwszego znaku odpowiedzi na „stolica polski”.',1200,21,MUTED)
for xx,title,body in [(88,'Warstwy','Średnia aktywacja ReLU.\nSkala względna, nie użycie CPU.'),(516,'Uwaga','Rozkład wag ostatniej głowy\ni warstwy dla pozycji tekstu.'),(944,'Wybór znaku','Prawdopodobieństwo symbolu.\nNie jest miarą prawdy.')]:
    b.text(xx,958,title,32,BLUE,'bold');b.para(xx,1015,body,365,24)
b.text(88,1130,'To sygnały obliczeń. Nie zapis toku myśli.',29,INK,'bold')
b.footer();BOARDS.append(b.save())
# 06 — Exact storage and RAM accounting.
b=Board('06_budzet_sprzetowy',1180,PAPER,6)
b.heading('05 / BUDŻET ZASOBÓW',['99,55% dyskietki.','Bez pustego wypełnienia.'],'Program, rzeczywiste wagi modelu, katalog materiału i licencje mieszczą się w jednym bootowalnym obrazie OFS.')
b.text(88,396,'DYSKIETKA DD / 901 120 BAJTÓW',20,MUTED,'mono')
disk=[('Model int8',708442,BLUE),('Program, materiały i OFS',188582,INK),('Wolne',4096,ORANGE)]
xx=88
for label,n,c in disk:
    ww=n/901120*1224;b.rect(xx,444,ww,91,c);xx+=ww
for x,(label,n,c) in zip([88,560,1096],disk):
    b.rect(x,571,13,13,c);b.text(x+25,563,label,21,INK);b.text(x+25,605,f'{n:,}'.replace(',',' ')+' B',24,c,'mono')
b.line(88,687,1312,687,LINE)
b.text(88,733,'186 KiB',76,BLUE,'bold');b.text(558,743,'sterta silnika',34,INK,'bold')
b.text(558,798,'36,3% z 512 KiB RAM',27,MUTED)
ram=[('Cache KV',135168,BLUE),('Bufor macierzy',50688,'#6792F9'),('Gainy',4608,ORANGE)]
xx=88
for label,n,c in ram:
    ww=n/190464*1224;b.rect(xx,880,ww,43,c);xx+=ww
b.text(88,949,'135 168 B cache KV  +  50 688 B bufor  +  4 608 B gainy',23,INK,'mono')
b.para(88,1008,'186 KiB nie oznacza całego zużycia RAM. Dodatkowej pamięci potrzebują program, bufory statyczne, stos, ekran, system i obsługa dyskietki. Pełnego zajęcia RAM w Kickstarcie nie zmierzono.',1180,25,MUTED)
b.footer();BOARDS.append(b.save())
# 07 — Honest held-out evaluation and realistic CPU cost.
b=Board('07_wyniki_i_czas',1280,WHITE,7)
b.heading('06 / WYNIKI',['Dobre odtwarzanie.','Słaba generalizacja.'],'Test rzeczywistego silnika C po kwantyzacji. Pełna zgodność odpowiedzi, łącznie z polskimi literami i interpunkcją; kalkulator wyłączony.')
for yy,key,title,c in [(431,'train','Pytania treningowe',BLUE),(581,'valid','Odłożone sformułowania',ORANGE)]:
    s=EV['sets'][key];val=s['accuracy'];b.text(88,yy,title,27,INK,'bold');b.text(1110,yy,f'{100*val:.1f}%'.replace('.',','),40,c,'bold')
    b.rect(88,yy+67,1224,26,'#E8EBE8');b.rect(88,yy+67,1224*val,26,c)
    b.text(88,yy+103,f'{s["correct"]} / {s["total"]} dokładnych odpowiedzi',21,MUTED,'mono')
b.para(88,758,'Odłożone pytania dotyczą znanych faktów zapisanych innymi słowami. Wynik nie mierzy ogólnego rozumowania ani jakości na dowolnym tekście.',1180,24,MUTED)
b.rect(88,877,586,211,INK);b.rect(702,877,610,211,PAPER)
b.text(116,900,'KALKULATOR: 2+5 → 7',20,ACID,'mono');b.text(116,940,'~0,020 s',58,WHITE,'bold');b.text(116,1020,'samych cykli CPU',24,WHITE)
b.text(730,900,'SIEĆ: stolica polski → Warszawa.',20,INK,'mono');b.text(730,940,'~7,5 min',58,BLUE,'bold');b.text(730,1020,'samych cykli CPU',24,MUTED)
b.para(88,1120,'Emulacja instrukcji 68000 przy 7,09 MHz; bez czasu fizycznej dyskietki, pełnego OS i GUI. To różne ścieżki wykonania. Rozpoznane rachunki celowo omijają sieć.',1180,23,MUTED)
b.footer();BOARDS.append(b.save())
# 08 — Lessons, verified status and exact scope.
b=Board('08_wnioski_i_walidacja',1180,INK,8)
b.heading('07 / WNIOSKI',['Ograniczenia są częścią','wyniku projektu.'],None,WHITE)
rows=[('01','Więcej parametrów nie daje automatycznie większej wiedzy.','Nowy polski korpus ma wąski zakres. To mały eksperymentalny model językowy, bez możliwości współczesnego dużego LLM.'),('02','Kwantyzacja zmniejsza plik, ale nie usuwa kosztu odczytu.','Model nadal nie mieści się w RAM A500. Dla kolejnych znaków trzeba ponownie czytać macierze z dyskietki.'),('03','Osobna ścieżka rachunków rozwiązuje konkretny problem.','Parser i dokładny kalkulator zwracają wynik bez przeliczania transformatora. Panel pokazuje wykonane działania.')]
for i,(n,title,body) in enumerate(rows):
    y=343+i*195;b.text(88,y,n,24,ACID,'mono');b.para(155,y-2,title,1100,31,WHITE,'bold',1.28);b.para(155,y+89,body,1080,24,'#B9CBD6')
b.rect(88,961,1224,114,'#193A4B')
b.text(115,981,'SPRAWDZONE',18,ACID,'mono');b.para(115,1014,'Kod na 68000, kalkulator, format modelu, kodowanie PL, przerwanie obliczeń, testy pytań oraz struktura OFS i bootblock 1.x.',1150,21,WHITE)
b.footer(WHITE);BOARDS.append(b.save())
# 09 — Closure, outstanding validation and attribution.
b=Board('09_final_i_zrodla',1070,BLUE,9)
b.text(88,70,'POLTINY PL / REZULTAT',20,WHITE,'mono')
b.text(88,145,'Projektowanie',88,WHITE,'bold');b.text(88,253,'w granicach 512 KiB.',88,WHITE,'bold',maxwidth=1224)
b.para(88,407,'Rezultat: bootowalny ADF, źródła C, nowy model int8, korpus PL, katalog materiału i raport z pomiarami.',1150,33,WHITE)
b.rect(88,565,1224,137,WHITE)
b.text(115,580,'DO WERYFIKACJI NA SPRZĘCIE',20,BLUE,'mono')
b.para(115,620,'Pełny start GUI z Kickstartem 1.3 i działanie na fizycznej A500 nie zostały potwierdzone. VAMOS nie zastępuje takiego testu.',1168,25,INK)
b.para(88,755,'Rozwój i opracowanie materiałów z pomocą OpenAI Codex.\nArchitektura i rdzeń: Tiny 2.1 / WollyMonjac, MIT.',1200,25,WHITE)
b.para(88,856,'Dane: mledoze/countries (ODbL), Periodic-Table-JSON (CC BY-SA 3.0) oraz polskie przykłady autorskie. Szczegóły źródeł i metody pomiaru dołączono do paczki.',1200,22,'#D8E5FF')
b.footer(WHITE);BOARDS.append(b.save())

# Dedicated project cover. It is an original graphic, not a hardware photo.
c=Board('okladka_808x632',632,BLUE,0,width=808)
c.text(45,35,'AMIGA 500 / EKSPERYMENT',16,WHITE,'mono')
c.text(40,101,'PolTiny',91,WHITE,'bold')
c.text(45,248,'AI na jednej',39,WHITE,'bold');c.text(45,302,'dyskietce.',39,WHITE,'bold')
floppy(c,535,188,.51)
c.text(45,514,'512 KiB RAM',23,WHITE,'mono');c.text(45,552,'W całości offline.',23,WHITE)
c.save()
# Cover belongs at the root, not in the ordered content upload folder.
shutil.move(ART/'okladka_808x632.jpg',OUT/'okladka_808x632.jpg')

# PDF serves as a review document. JPEGs are the actual Behance content.
pdf=canvas.Canvas(str(OUT/'PolTiny-case-study.pdf'))
pdf.setTitle('PolTiny PL — case study');pdf.setAuthor('PolTiny / opracowanie z pomocą OpenAI Codex')
for board in BOARDS:
    pdf.setPageSize((board.w*.6,board.h*.6))
    pdf.drawImage(ImageReader(board.im),0,0,width=board.w*.6,height=board.h*.6);pdf.showPage()
pdf.save()

# Small contact sheet for visual QA and chat preview.
thumbw=360;gap=16;cellh=360;preview=Image.new('RGB',(thumbw*3+gap*4,cellh*3+gap*4),'#D8DED9')
pd=ImageDraw.Draw(preview)
for i,board in enumerate(BOARDS):
    thumb=board.im.copy();thumb.thumbnail((thumbw,316));x=gap+(i%3)*(thumbw+gap);y=gap+(i//3)*(cellh+gap)
    preview.paste(thumb,(x,y));pd.text((x,y+325),board.name,font=font(14,'mono'),fill=INK)
preview.save(OUT/'PODGLAD-plansze.jpg',quality=94)

style='''<style>*{box-sizing:border-box}body{margin:0;background:#d9dfdc;font:16px/1.5 system-ui;color:#102331}header{padding:20px max(20px,calc((100vw - 1400px)/2));background:#fff}main{max-width:1400px;margin:auto}img{display:block;width:100%;height:auto}a{color:#1659f5}details{background:white;padding:20px}nav{padding:14px;background:#fff;position:sticky;top:0;z-index:5}</style>'''
doc='<!doctype html><html lang="pl"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>PolTiny PL — case study do Behance</title>'+style+'<header><b>PolTiny PL — podgląd case study</b><p>9 plansz w kolejności publikacji. Widok interfejsu jest oznaczoną rekonstrukcją; telemetria pochodzi z silnika C.</p></header><nav><a href="PolTiny-case-study.pdf">PDF</a> · <a href="TEKST-PROJEKTU.md">Tekst</a> · <a href="PROMPT-DLA-CLAUDE.txt">Instrukcja dla Claude</a></nav><main>'
for board in BOARDS:
    doc+=f'<img src="materialy/{board.name}.jpg" width="{board.w}" height="{board.h}" alt="{esc(" / ".join(board.alltext))}">'
doc+='</main></html>';(OUT/'PODGLAD.html').write_text(doc)

metadata={'tytul':'PolTiny PL — polski model językowy na Amidze 500','opis':'Eksperymentalny model językowy po polsku dla Amigi 500 z 512 KiB RAM. Nowe wagi, kwantyzacja int8, interfejs Workbencha i rzeczywista telemetria — spakowane na jedną dyskietkę. Case study pokazuje proces, budżet zasobów, jakość odpowiedzi i ograniczenia prototypu.','jezyk':'pl','proponowane_dziedziny':['UI/UX','Programming','Interaction Design'],'tagi':['Amiga','Artificial Intelligence','Retrocomputing','Machine Learning','Embedded Systems','Quantization','Interface Design','Data Visualization','Polish Language','Workbench'],'narzedzia_faktycznie_uzyte':['C','Python','PyTorch','NumPy','m68k-amigaos-gcc','VAMOS','amitools','Matplotlib','Pillow','SVG','ReportLab','OpenAI Codex'],'okladka':'okladka_808x632.jpg','kolejnosc':[f'materialy/{b.name}.jpg' for b in BOARDS],'status':'Materialy przygotowane do publikacji; projekt nie zostal opublikowany na Behance.','atrybucja':'Rozwój i opracowanie z pomocą OpenAI Codex. Rdzeń i architektura na podstawie Tiny 2.1 autorstwa WollyMonjac (MIT).'}
(OUT/'METADANE.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
body='''# PolTiny PL — polski model językowy na Amidze 500

Eksperymentalny model językowy po polsku dla Amigi 500 z 512 KiB RAM. Nowe wagi, kwantyzacja int8, interfejs Workbencha i rzeczywista telemetria — spakowane na jedną dyskietkę.

## Wyzwanie

Celem było przygotowanie większego polskiego modelu dla fabrycznej Amigi 500: procesor 68000, 512 KiB RAM, Kickstart/Workbench 1.3, dyskietka DD 880 KiB. Uzgodniony priorytet to praca całkowicie offline, przy akceptacji wolnych odpowiedzi i ograniczonej wiedzy. Model nie jest odpowiednikiem współczesnego dużego LLM.

## Od Tiny do PolTiny

Architektura i silnik wywodzą się z Tiny 2.1. PolTiny ma 687 616 parametrów, około 1,88× więcej niż oryginalne 366 528. Wagi wytrenowano od losowej inicjalizacji na nowym polskim korpusie. Trening odbywał się na współczesnym komputerze, a generowanie działa lokalnie na Amidze.

Materiał obejmuje 914 wpisów i zagadnień, 4 123 pytania treningowe oraz 1 337 odłożonych sformułowań. Tematy to m.in. geografia, chemia, komputery, podstawy nauki i krótkie rozmowy. Wpisy nie oznaczają niezależnych umiejętności. Warianty bez polskich liter ułatwiają korzystanie ze standardowej klawiatury.

## Architektura i kwantyzacja

Transformator znakowy: D=128, cztery warstwy, cztery głowy uwagi, MLP=384, alfabet 115 znaków i kontekst 128 znaków. Maksymalna długość pytania wynosi 72 znaki. Model wybiera kolejne znaki z rozkładu; nie wyszukuje odpowiedzi w dołączonym katalogu.

Macierze int8 mają osobną skalę float32 na wiersz. Aktywacje w iloczynach są skalowane do int16, sumy do int32. Cache KV używa int8 ze skalami. Normalizacja i softmax nadal wymagają programowych obliczeń float32. Model nie uczy się podczas rozmowy i nie korzysta z historii poprzednich pytań.

## Doświadczenie użytkownika

Interfejs Intuition ma polskie komunikaty, przycisk odpowiedzi i Stop/Esc. Rozpoznane wyrażenia arytmetyczne trafiają do parsera i dokładnego kalkulatora, który pokazuje wykonane działania. Pozostałe pytania uruchamiają sieć.

Wykresy pokazują średnią aktywację ReLU warstw, uwagę ostatniej obliczonej głowy i warstwy oraz prawdopodobieństwo kolejnego znaku. To sygnały obliczeń, nie zapis toku myśli ani miara prawdziwości odpowiedzi. Widok GUI w materiale jest oznaczoną rekonstrukcją z kodu, a wartości wykresów odczytano z rzeczywistego silnika C.

## Budżet zasobów

Plik modelu zajmuje 708 442 bajty. Cały obraz dyskietki ma 901 120 bajtów, z czego 897 024 bajty są zajęte (99,55%); wolne pozostają 4 096 bajtów. Zajętość obejmuje program, dane, licencje i narzut OFS, bez pustego wypełnienia.

Silnik rezerwuje na stercie 190 464 bajty = 186 KiB, czyli 36,3% z 512 KiB RAM: 135 168 bajtów cache KV, 50 688 bajtów bufora macierzy i 4 608 bajtów gainów. To nie całkowite użycie pamięci; trzeba doliczyć program, bufory statyczne, stos, ekran, system i obsługę dyskietki. Pełnego zajęcia RAM w Kickstarcie nie zmierzono.

## Wyniki, z ograniczeniami

Silnik C po kwantyzacji uzyskał 4 109 / 4 123 (99,66%) dokładnych odpowiedzi na pytania treningowe oraz 453 / 1 337 (33,88%) na odłożone sformułowania znanych faktów. Wymagano pełnej zgodności odpowiedzi, łącznie z polskimi literami i interpunkcją. Kalkulator był wyłączony. Test nie mierzy ogólnego rozumowania ani jakości na dowolnym tekście.

W emulacji instrukcji 68000 przy 7,09 MHz działanie 2+5 → 7 kosztowało około 0,020 s samych cykli CPU. Odpowiedź sieci „stolica polski” → „Warszawa.” kosztowała około 7,5 min samych cykli CPU. Wyniki nie zawierają opóźnień fizycznej dyskietki, pełnego OS ani GUI. To dwa różne zadania i ścieżki wykonania.

Większy model niż RAM komputera wymaga ponownego czytania macierzy dla kolejnych znaków. Kwantyzacja ogranicza liczbę bajtów i koszt iloczynów, ale nie usuwa tego problemu. Wysoka trafność na treningu nie przełożyła się na dobre rozumienie przeformułowanych pytań.

## Walidacja i następny krok

Sprawdzono kod na 68000, kalkulator, format i integralność modelu, kodowanie polskich liter, przerwanie obliczeń, pytania testowe, system plików OFS oraz sumę kontrolną bootblocka 1.x. VAMOS nie zastępuje pełnego systemu. Pełny start GUI z Kickstartem 1.3 i działanie na fizycznej A500 pozostają do weryfikacji.

## Źródła i autorstwo

Rozwój i opracowanie materiałów z pomocą OpenAI Codex. Rdzeń i architektura na podstawie Tiny 2.1 autorstwa WollyMonjac (MIT): https://github.com/WollyMonjac/Tiny-2.1

Dane: mledoze/countries (ODbL 1.0): https://github.com/mledoze/countries ; Periodic-Table-JSON (CC BY-SA 3.0): https://github.com/Bowserinator/Periodic-Table-JSON ; autorskie przykłady po polsku. Dodatkowy kod soft-float GCC ma GPLv3 z GCC Runtime Library Exception. Szczegółowe informacje znajdują się w załączonych licencjach projektu.
'''
(OUT/'TEKST-PROJEKTU.md').write_text(body)
prompt='''Przygotuj projekt Behance na podstawie tej paczki PolTiny PL.

1. Otwórz plik METADANE.json. Użyj podanego tytułu, opisu i tagów. Język projektu: polski.
2. Użyj okladka_808x632.jpg jako okładki. Sprawdź przycięcie w podglądzie Behance.
3. Dodaj dziewięć obrazów JPG z katalogu materialy, kolejno od 01_otwarcie.jpg do 09_final_i_zrodla.jpg. To kompletne plansze, więc nie wstawiaj pomiędzy nimi ponownie całego tekstu z pliku Markdown. Zachowaj naturalne proporcje, pełną szerokość i ciągły układ bez dodatkowych obramowań.
4. Jako wprowadzenie użyj krótkiego opisu z METADANE.json. Pełny TEKST-PROJEKTU.md służy jako alternatywa dla tekstu na planszach oraz źródło podpisów i atrybucji.
5. Wybierz pasujące dziedziny spośród rzeczywiście dostępnych opcji Behance, sugerując się METADANE.json. Narzędzia wymieniaj tylko te, które są w paczce; nie dopisuj Figma ani Photoshopa.
6. Zachowaj informacje o ograniczeniach: 33,88% na odłożonych sformułowaniach, długi czas generowania oraz brak pełnego testu GUI na Kickstarcie 1.3 i fizycznej A500. Widok Workbencha jest rekonstrukcją z kodu, nie zrzutem uruchomionego emulatora. Wykresy pochodzą z prawdziwej telemetrii silnika.
7. Zachowaj atrybucję Tiny 2.1 / WollyMonjac, źródła danych i informację o pracy z pomocą OpenAI Codex. Nie wymyślaj nazwy klienta, zespołu, autora, nagród ani efektów biznesowych.
8. Po dodaniu plansz i metadanych pokaż podgląd projektu, abym mógł ocenić całość.

Nie mam potrzeby dodawania na Behance ADF, kodu C ani pełnego archiwum oprogramowania. Folder dane służy do weryfikacji liczb. Folder edycja zawiera wersje PNG/SVG do ewentualnych korekt, a PDF i PODGLAD.html służą do przeglądu.
'''
(OUT/'PROMPT-DLA-CLAUDE.txt').write_text(prompt)
start='''# PolTiny PL — paczka do Behance

Najpierw rozpakuj ZIP. Skopiuj treść `PROMPT-DLA-CLAUDE.txt` do Claude działającego w Chrome i udostępnij mu pliki z tej paczki. Jeśli nie może sam wybrać plików z dysku, wybierz je w oknie przesyłania wskazanym przez Claude.

## Pliki do publikacji

- `okladka_808x632.jpg` — miniatura projektu.
- `materialy/01…09.jpg` — dziewięć gotowych plansz, szerokość 1400 px; dodawaj w kolejności numerów.
- `METADANE.json` — tytuł, opis, tagi, sugerowane dziedziny i kolejność.
- `TEKST-PROJEKTU.md` — pełny tekst i atrybucje.

## Podgląd i edycja

- `PODGLAD.html` — otwórz lokalnie w przeglądarce po rozpakowaniu; nie wymaga internetu.
- `PolTiny-case-study.pdf` — PDF z dziewięcioma planszami.
- `PODGLAD-plansze.jpg` — przegląd całego układu.
- `edycja/` — bezstratne PNG i wektorowe SVG; do publikacji wystarczą JPG.
- `fonty/` — użyte otwarte kroje i informacje licencyjne.
- `dane/` — wyniki i liczby źródłowe, bez ujawniania jakichkolwiek danych konta.
- `src/` — generator materiałów i pomocniczy eksport telemetrii.

Plansze zawierają tekst: nie dodawaj go drugi raz w pełnej postaci między obrazami. Krótki opis z metadanych wystarczy na wprowadzenie.

Nie dołączono nazwiska autora, klienta ani podpisów pod fikcyjnymi zdjęciami. Autorstwo konta uzupełnij zgodnie z własnym profilem. Wizerunek Workbencha jest wyraźnie oznaczoną rekonstrukcją z kodu, a słupki pochodzą z telemetrii rzeczywistego silnika. Nie potwierdzono pełnego startu GUI na Kickstarcie 1.3 ani testu na fizycznej A500.

Projekt nie został opublikowany na Behance przez tę paczkę.
'''
(OUT/'00_START-TUTAJ.md').write_text(start)

# Reproducible evidence accompanies the design, not account/authentication data.
for src,name in [(ROOT/'training/run.json','trening.json'),(ROOT/'training/dataset.json','korpus.json'),(ROOT/'tests/benchmark.json','benchmark.json'),(ROOT/'build/disk-info.txt','dyskietka.txt'),(ROOT/'DATA_LICENSES.md','DANE-LICENCJE.md'),(ROOT/'LICENSE','LICENSE-MIT.txt')]:
    if src.exists():shutil.copyfile(src,DATA/name)
    else:assert (DATA/name).exists(),name
summary={'model_sha256':EV['model_sha256'],'ocena':{k:{'poprawne':r['correct'],'wszystkie':r['total'],'skutecznosc':r['accuracy'],'tematy':r['topics']} for k,r in EV['sets'].items()},'telemetria':'Realny silnik C, pierwsza predykcja po pytaniu stolica polski; 1 znak odpowiedzi; L4 G4.','zasoby':{'ram_silnika_bajty':190464,'ram_calkowity_bajty':524288,'model_bajty':708442,'dysk_zajete_bajty':897024,'dysk_wolne_bajty':4096,'dysk_pojemnosc_bajty':901120},'zastrzezenia':['Nie zmierzono całkowitego RAM pełnego systemu.','Czasy cykli CPU bez opóźnienia fizycznej dyskietki i pełnego OS/GUI.','Brak potwierdzonego startu GUI z Kickstartem 1.3 i fizycznej A500.','Widok GUI jest rekonstrukcją na podstawie kodu.']}
(DATA/'wyniki.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
manifest=[{'kolejnosc':i+1,'plik':f'materialy/{b.name}.jpg','szerokosc':b.w,'wysokosc':b.h,'opis_alternatywny':' / '.join(b.alltext)} for i,b in enumerate(BOARDS)]
(OUT/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(OUT/'FONTY.txt').write_text('Noto Sans Display Regular/Bold (SIL Open Font License) oraz DejaVu Sans Mono (licencja DejaVu). SVG zachowują tekst; do edycji można zainstalować dołączone kroje. JPG, PNG i PDF nie wymagają instalacji fontów.\n')
print(json.dumps({'plansze':len(BOARDS),'tekstowe_pola':sum(len(b.bounds) for b in BOARDS),'height_total':sum(b.h for b in BOARDS),'output':str(OUT)},ensure_ascii=False))
