# PolTiny PL — paczka do Behance

Najpierw rozpakuj ZIP. Skopiuj treść `PROMPT-DLA-CLAUDE.txt` do Claude działającego w Chrome i udostępnij mu pliki z tej paczki. Jeśli nie może sam wybrać plików z dysku, wybierz je w oknie przesyłania wskazanym przez Claude.

## Pliki do publikacji

- `okladka_808x632.jpg` — miniatura projektu.
- `materialy/01…09.jpg` — dziewięć gotowych plansz, szerokość 1400 px; dodawaj w kolejności numerów.
- `METADANE.json` — tytuł, opis, tagi, sugerowane dziedziny i kolejność.
- `TEKST-PROJEKTU.md` — pełny tekst i atrybucje.

## Podgląd i edycja

- `PODGLAD.html` — otwórz lokalnie w przeglądarce po rozpakowaniu; nie wymaga internetu.
- `PolTiny-case-study.pdf` — PDF z dziewięcioma planszami.
- `PODGLAD-plansze.jpg` — przegląd całego układu.
- `edycja/` — bezstratne PNG i wektorowe SVG; do publikacji wystarczą JPG.
- `fonty/` — użyte otwarte kroje i informacje licencyjne.
- `dane/` — wyniki i liczby źródłowe, bez ujawniania jakichkolwiek danych konta.
- `src/` — generator materiałów i pomocniczy eksport telemetrii.

Plansze zawierają tekst: nie dodawaj go drugi raz w pełnej postaci między obrazami. Krótki opis z metadanych wystarczy na wprowadzenie.

Nie dołączono nazwiska autora, klienta ani podpisów pod fikcyjnymi zdjęciami. Autorstwo konta uzupełnij zgodnie z własnym profilem. Wizerunek Workbencha jest wyraźnie oznaczoną rekonstrukcją z kodu, a słupki pochodzą z telemetrii rzeczywistego silnika. Nie potwierdzono pełnego startu GUI na Kickstarcie 1.3 ani testu na fizycznej A500.

Projekt nie został opublikowany na Behance przez tę paczkę.
