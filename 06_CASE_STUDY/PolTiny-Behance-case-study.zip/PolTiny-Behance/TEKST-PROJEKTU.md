# PolTiny PL — polski model językowy na Amidze 500

Eksperymentalny model językowy po polsku dla Amigi 500 z 512 KiB RAM. Nowe wagi, kwantyzacja int8, interfejs Workbencha i rzeczywista telemetria — spakowane na jedną dyskietkę.

## Wyzwanie

Celem było przygotowanie większego polskiego modelu dla fabrycznej Amigi 500: procesor 68000, 512 KiB RAM, Kickstart/Workbench 1.3, dyskietka DD 880 KiB. Uzgodniony priorytet to praca całkowicie offline, przy akceptacji wolnych odpowiedzi i ograniczonej wiedzy. Model nie jest odpowiednikiem współczesnego dużego LLM.

## Od Tiny do PolTiny

Architektura i silnik wywodzą się z Tiny 2.1. PolTiny ma 687 616 parametrów, około 1,88× więcej niż oryginalne 366 528. Wagi wytrenowano od losowej inicjalizacji na nowym polskim korpusie. Trening odbywał się na współczesnym komputerze, a generowanie działa lokalnie na Amidze.

Materiał obejmuje 914 wpisów i zagadnień, 4 123 pytania treningowe oraz 1 337 odłożonych sformułowań. Tematy to m.in. geografia, chemia, komputery, podstawy nauki i krótkie rozmowy. Wpisy nie oznaczają niezależnych umiejętności. Warianty bez polskich liter ułatwiają korzystanie ze standardowej klawiatury.

## Architektura i kwantyzacja

Transformator znakowy: D=128, cztery warstwy, cztery głowy uwagi, MLP=384, alfabet 115 znaków i kontekst 128 znaków. Maksymalna długość pytania wynosi 72 znaki. Model wybiera kolejne znaki z rozkładu; nie wyszukuje odpowiedzi w dołączonym katalogu.

Macierze int8 mają osobną skalę float32 na wiersz. Aktywacje w iloczynach są skalowane do int16, sumy do int32. Cache KV używa int8 ze skalami. Normalizacja i softmax nadal wymagają programowych obliczeń float32. Model nie uczy się podczas rozmowy i nie korzysta z historii poprzednich pytań.

## Doświadczenie użytkownika

Interfejs Intuition ma polskie komunikaty, przycisk odpowiedzi i Stop/Esc. Rozpoznane wyrażenia arytmetyczne trafiają do parsera i dokładnego kalkulatora, który pokazuje wykonane działania. Pozostałe pytania uruchamiają sieć.

Wykresy pokazują średnią aktywację ReLU warstw, uwagę ostatniej obliczonej głowy i warstwy oraz prawdopodobieństwo kolejnego znaku. To sygnały obliczeń, nie zapis toku myśli ani miara prawdziwości odpowiedzi. Widok GUI w materiale jest oznaczoną rekonstrukcją z kodu, a wartości wykresów odczytano z rzeczywistego silnika C.

## Budżet zasobów

Plik modelu zajmuje 708 442 bajty. Cały obraz dyskietki ma 901 120 bajtów, z czego 897 024 bajty są zajęte (99,55%); wolne pozostają 4 096 bajtów. Zajętość obejmuje program, dane, licencje i narzut OFS, bez pustego wypełnienia.

Silnik rezerwuje na stercie 190 464 bajty = 186 KiB, czyli 36,3% z 512 KiB RAM: 135 168 bajtów cache KV, 50 688 bajtów bufora macierzy i 4 608 bajtów gainów. To nie całkowite użycie pamięci; trzeba doliczyć program, bufory statyczne, stos, ekran, system i obsługę dyskietki. Pełnego zajęcia RAM w Kickstarcie nie zmierzono.

## Wyniki, z ograniczeniami

Silnik C po kwantyzacji uzyskał 4 109 / 4 123 (99,66%) dokładnych odpowiedzi na pytania treningowe oraz 453 / 1 337 (33,88%) na odłożone sformułowania znanych faktów. Wymagano pełnej zgodności odpowiedzi, łącznie z polskimi literami i interpunkcją. Kalkulator był wyłączony. Test nie mierzy ogólnego rozumowania ani jakości na dowolnym tekście.

W emulacji instrukcji 68000 przy 7,09 MHz działanie 2+5 → 7 kosztowało około 0,020 s samych cykli CPU. Odpowiedź sieci „stolica polski” → „Warszawa.” kosztowała około 7,5 min samych cykli CPU. Wyniki nie zawierają opóźnień fizycznej dyskietki, pełnego OS ani GUI. To dwa różne zadania i ścieżki wykonania.

Większy model niż RAM komputera wymaga ponownego czytania macierzy dla kolejnych znaków. Kwantyzacja ogranicza liczbę bajtów i koszt iloczynów, ale nie usuwa tego problemu. Wysoka trafność na treningu nie przełożyła się na dobre rozumienie przeformułowanych pytań.

## Walidacja i następny krok

Sprawdzono kod na 68000, kalkulator, format i integralność modelu, kodowanie polskich liter, przerwanie obliczeń, pytania testowe, system plików OFS oraz sumę kontrolną bootblocka 1.x. VAMOS nie zastępuje pełnego systemu. Pełny start GUI z Kickstartem 1.3 i działanie na fizycznej A500 pozostają do weryfikacji.

## Źródła i autorstwo

Rozwój i opracowanie materiałów z pomocą OpenAI Codex. Rdzeń i architektura na podstawie Tiny 2.1 autorstwa WollyMonjac (MIT): https://github.com/WollyMonjac/Tiny-2.1

Dane: mledoze/countries (ODbL 1.0): https://github.com/mledoze/countries ; Periodic-Table-JSON (CC BY-SA 3.0): https://github.com/Bowserinator/Periodic-Table-JSON ; autorskie przykłady po polsku. Dodatkowy kod soft-float GCC ma GPLv3 z GCC Runtime Library Exception. Szczegółowe informacje znajdują się w załączonych licencjach projektu.
