# Oryginalne screeny do dołączenia

Potrzebne są pliki z wcześniejszej rozmowy: ekran „Reading 7/31”, kolejny „Reading 9/31” oraz ekran z pytaniem „2+5”, licznikiem około 3:25 i paskiem odczytu. Dostępny jest opis tych obrazów, ale brak plików do kadrowania.

Po otrzymaniu oryginałów:
1. Zachowaj kopie surowych plików.
2. Wykadruj do granic prawdziwego emulowanego obrazu Amigi. Usuń tło gospodarza i czarne marginesy; nie odtwarzaj GUI od nowa.
3. Na życzenie autora popraw jedynie pisownię poleceń i usuń przypadkowo dopisane znaki. Przykład: „How many people are there on Earth?” lub „What is 2 + 5?”. Wyniki, postęp i czas programu pozostają danymi źródłowymi.
4. Przy redakcyjnej korekcie dodaj drobny podpis „kadrowanie i korekta pisowni poleceń” / „cropped; prompt spelling edited”.
5. Zapisz gotowe obrazy w assets/reading_7.png, assets/reading_9.png i assets/math_slow.png. Jeżeli jest aktualny screen PolTiny PL, dołącz go jako dodatkowe potwierdzenie obecnej wersji.

Plansze z placeholderami nie są gotowe do publikacji. Zrzuty z wersji angielskiej należy pokazać jako etap historii, a nie dowód ekranu późniejszego PolTiny PL.
