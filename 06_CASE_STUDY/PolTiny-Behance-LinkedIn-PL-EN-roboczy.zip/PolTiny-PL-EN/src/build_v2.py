"""Bilingual editorial documents for Behance and LinkedIn.
Document layout embeds original image assets without redrawing screenshots.
PDF pages are rendered to publication PNG/JPEGs with PyMuPDF.
"""
from pathlib import Path
import json,math,shutil,zipfile,hashlib,html
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor
import fitz

ROOT=Path(__file__).resolve().parents[1]
STORY=json.loads((ROOT/'content/story.json').read_text())
FONTROOT=ROOT.parent/'behance/fonty'
for name,path in [('sans','NotoSansDisplay-Regular.ttf'),('bold','NotoSansDisplay-Bold.ttf'),('mono','DejaVuSansMono.ttf')]:
    bundled=ROOT/'fonts'/path
    pdfmetrics.registerFont(TTFont(name,str(bundled if bundled.exists() else FONTROOT/path)))
BLUE='#143FF0';INK='#0C2234';PAPER='#F2F0E9';ORANGE='#F67E49';MUTED='#5F717C';WHITE='#FFFFFF';LINE='#CFD6D7';ACID='#DDED9D'
ASSETS=ROOT/'assets';TE=json.loads((ASSETS/'telemetry.json').read_text());Q=json.loads((ASSETS/'optimization-benchmark.json').read_text())
missing=set();FILES=[];ALLTEXT=[]
def clean(s):return s.replace('→',' > ').replace('−','-').replace('×','x')

class Page:
    def __init__(self,path,w=1400,h=1320,bg=PAPER,lang='PL',number=1,total=12):
        self.path=path;path.parent.mkdir(parents=True,exist_ok=True);self.w=w;self.h=h;self.lang=lang;self.number=number;self.total=total
        self.c=canvas.Canvas(str(path),pagesize=(w,h));self.c.setTitle(STORY[lang]['title']);self.c.setAuthor('PolTiny / developed with OpenAI Codex')
        self.rect(0,0,w,h,bg);self.scale=w/1400;self.bg=bg;self.texts=[]
    def rect(self,x,y,w,h,color,stroke=None,sw=1):
        self.c.setFillColor(HexColor(color));self.c.setStrokeColor(HexColor(stroke or color));self.c.setLineWidth(sw);self.c.rect(x,self.h-y-h,w,h,fill=1,stroke=int(bool(stroke)))
    def line(self,x,y,x2,y2,color=LINE,sw=2):
        self.c.setStrokeColor(HexColor(color));self.c.setLineWidth(sw);self.c.line(x,self.h-y,x2,self.h-y2)
    def text(self,x,y,s,size=30,color=INK,face='sans'):
        if self.bg in [INK,BLUE]:
            color={INK:WHITE,MUTED:'#BDCFDF',BLUE:'#A8C1FF'}.get(color,color)
        s=clean(s);self.c.setFillColor(HexColor(color));self.c.setFont(face,size)
        self.c.drawString(x,self.h-y-size,s);self.texts.append(s)
        assert x+pdfmetrics.stringWidth(s,face,size)<=self.w+1,(self.path,s)
    def para(self,x,y,s,width=1216,size=29,color=INK,face='sans',lh=1.37):
        s=clean(s)
        for block in s.split('\n'):
            line=''
            for word in block.split():
                test=(line+' '+word).strip()
                if line and pdfmetrics.stringWidth(test,face,size)>width:
                    self.text(x,y,line,size,color,face);y+=size*lh;line=word
                else:line=test
            self.text(x,y,line,size,color,face);y+=size*lh
        return y
    def image(self,path,x,y,w,h):
        if not path.exists():
            missing.add(path.name);self.rect(x,y,w,h,'#DDE2E0',LINE)
            label='MIEJSCE NA ORYGINALNY SCREEN' if self.lang=='PL' else 'ORIGINAL SCREENSHOT PENDING'
            self.para(x+25,y+max(25,h*.33),label,w-50,25,MUTED,'mono')
            self.para(x+25,y+max(80,h*.56),path.name,w-50,18,MUTED,'mono');return
        image=fitz.open(str(path));pix=image[0].get_pixmap() if path.suffix.lower()=='.pdf' else None
        if pix:iw,ih=pix.width,pix.height
        else:
            pm=fitz.Pixmap(str(path));iw,ih=pm.width,pm.height
        image.close();ratio=min(w/iw,h/ih);ww,hh=iw*ratio,ih*ratio
        self.c.drawImage(str(path),x+(w-ww)/2,self.h-y-(h+hh)/2,width=ww,height=hh,mask='auto')
    def footer(self,color=INK):
        m=self.w*.065;self.line(m,self.h-75,self.w-m,self.h-75,LINE)
        self.text(m,self.h-52,'POLTINY PL / '+('HISTORIA PROJEKTU' if self.lang=='PL' else 'PROJECT EVOLUTION'),16,color,'mono')
        self.text(self.w-m-90,self.h-52,f'{self.number:02}/{self.total:02}',16,color,'mono')
    def finish(self,outstem):
        self.c.showPage();self.c.save()
        doc=fitz.open(str(self.path));pm=doc[0].get_pixmap(alpha=False)
        pm.save(str(outstem.with_suffix('.png')))
        outstem.with_suffix('.jpg').write_bytes(pm.tobytes('jpg',jpg_quality=95));doc.close()
        FILES.append(str(outstem.with_suffix('.jpg').relative_to(ROOT)));ALLTEXT.extend(self.texts)

def heading(p,s,compact=False):
    m=90 if p.w==1400 else 70
    p.text(m,66,('HISTORIA PROJEKTU / ' if p.lang=='PL' else 'PROJECT EVOLUTION / ')+f'{p.number:02}',20,MUTED,'mono')
    y=132;size=62 if p.w==1400 else 49
    for line in s['title']:
        p.text(m,y,line,size,INK,'bold');y+=size*1.15
    return p.para(m,y+34,s['body'],p.w-2*m,28 if p.w==1400 else 27,MUTED)

def art_hero(p,s,platform):
    if platform=='behance':
        p.rect(0,0,p.w,p.h,'#071743');p.image(ASSETS/'key-visual.png',0,0,1400,934)
        p.text(86,48,('POLTINY / SPRZĘT 1987, EKSPERYMENT 2026' if p.lang=='PL' else 'POLTINY / 1987 HARDWARE, 2026 EXPERIMENT'),20,WHITE,'mono')
        p.text(80,121,'PolTiny PL',124,WHITE,'bold')
        p.para(86,273,s['subtitle'],1030,43,WHITE,'bold')
        p.para(86,1044,STORY[p.lang]['goal'],1200,28,WHITE)
        p.text(86,1156,('WIZUALIZACJA AI' if p.lang=='PL' else 'AI-GENERATED KEY VISUAL'),16,'#AFC4E4','mono')
        p.footer(WHITE)
    else:
        p.text(70,58,'POLTINY PL / RETROCOMPUTING',18,MUTED,'mono')
        p.text(65,147,'PolTiny PL',105,INK,'bold')
        p.para(70,300,s['subtitle'],940,43,INK,'bold')
        p.image(ASSETS/'key-visual.png',0,500,1080,720)
        p.text(70,1244,('A500 / 0,5 MB RAM / BEZ DODATKÓW' if p.lang=='PL' else 'A500 / 0.5 MB RAM / NO EXPANSIONS'),20,INK,'mono')

def body_art(p,s,platform):
    end=heading(p,s);m=90 if p.w==1400 else 70;w=p.w-2*m
    top=max(515,end+45) if p.w==1400 else max(520,end+35)
    floor=p.h-300;area=max(245,floor-top)
    kind=s['kind'];PL=p.lang=='PL'
    if kind=='brief':
        words=[('0,5 MB' if PL else '0.5 MB','RAM / 512 KiB'),('7,09 MHz' if PL else '7.09 MHz','68000 / NO FPU'),('880 KiB','DD / OFS / ADF')]
        for i,(n,label) in enumerate(words):
            y=top+i*120;p.text(m,y,n,68 if p.w==1400 else 62,BLUE,'bold');p.text(m+540 if p.w==1400 else m+460,y+31,label,22,MUTED,'mono')
        p.text(m,floor+30,('AMIGA 500 / 1987 / BEZ ROZSZERZEŃ' if PL else 'AMIGA 500 / 1987 / NO EXPANSIONS'),22,INK,'mono')
    elif kind=='origin':
        p.image(ASSETS/'upstream-tiny21.png',m,top,w,area)
        p.text(m,top+area+20,('Tiny 2.1 DOS — zrzut z projektu źródłowego' if PL else 'Tiny 2.1 DOS — upstream project screenshot'),20,MUTED)
    elif kind=='screens':
        keys=s['screens']
        if platform=='behance':
            for i,key in enumerate(keys):p.image(ASSETS/f'{key}.png',m,top+i*(area+20)/2,w,(area-20)/2)
        else:
            p.image(ASSETS/f'{keys[0]}.png',m,top,w,area)
            if not (ASSETS/f'{keys[1]}.png').exists():missing.add(f'{keys[1]}.png')
        p.text(m,top+area+22,('7/31 > 9/31 / POSTĘP PRZETWARZANIA' if PL else '7/31 > 9/31 / PROCESSING PROGRESS'),22,BLUE,'mono')
    elif kind=='boot':
        p.rect(m,top,w,area,INK)
        p.text(m+35,top+25,('SAMOBOOTUJĄCY ADF' if PL else 'SELF-BOOTING ADF'),27,ACID,'mono')
        lines=['Kickstart 1.3','Bootblock 1.x / OFS','S:Startup-Sequence','TinyStack / 16 KiB','PolTiny / POLTINY.BIN']
        for i,line in enumerate(lines):p.text(m+35,top+85+i*53,line,28,WHITE,'mono')
    elif kind=='optimization':
        vals=[(Q['previous_cpu_cycles'],('Przed' if PL else 'Before'),'#718694' if p.bg==INK else INK),(Q['quantized_attention_cpu_cycles'],('Po optymalizacji' if PL else 'Optimised'),BLUE)]
        for i,(value,label,c) in enumerate(vals):
            y=top+i*150;p.text(m,y,label,26,INK,'bold');p.rect(m,y+57,w*value/Q['previous_cpu_cycles'],40,c)
            p.text(m,y+110,f'{value:,}'.replace(',',' ')+' CPU cycles',21,MUTED,'mono')
        p.text(m,top+340,'-39,55%' if PL else '-39.55%',78,ORANGE,'bold')
    elif kind=='math':
        if platform=='behance':
            photo_h=area-300
            p.image(ASSETS/'math_slow.png',m,top,w,photo_h)
            yy=top+photo_h+25;p.rect(m,yy,w,265,INK)
            p.text(m+30,yy+20,'2 + 5 = 7',70,WHITE,'bold')
            p.text(m+650,yy+30,'~0,020 s CPU' if PL else '~0.020 s CPU',43,ACID,'bold')
            p.text(m+30,yy+130,'3 * 4 = 12    2 + 12 = 14',27,WHITE,'mono')
            p.text(m+30,yy+195,('Jawne kroki kalkulatora dla 2 + 3 * 4' if PL else 'Actual calculator steps for 2 + 3 * 4'),23,WHITE)
        else:
            p.image(ASSETS/'math_slow.png',m,top,w,area-230)
            yy=top+area-205;p.rect(m,yy,w,205,INK)
            p.text(m+24,yy+15,'2 + 5 = 7',61,WHITE,'bold')
            p.text(m+24,yy+110,'~0,020 s CPU' if PL else '~0.020 s CPU',41,ACID,'bold')
    elif kind=='polish':
        rows=[('TINY EN + PL HELPERS',366528),('NOWY POLTINY PL' if PL else 'NEW POLTINY PL',687616)]
        for i,(label,n) in enumerate(rows):
            yy=top+i*165;p.text(m,yy,label,23,MUTED,'mono');p.text(m,yy+48,f'{n:,}'.replace(',',' '),73,BLUE if i else INK,'bold')
        p.text(m,top+365,('115 ZNAKÓW / POLSKIE LITERY' if PL else '115 TOKENS / POLISH CHARACTERS'),23,INK,'mono')
    elif kind=='telemetry':
        p.text(m,top,('WARSTWY / ŚREDNIA RELU' if PL else 'LAYERS / MEAN RELU'),23,MUTED,'mono')
        peak=max(TE['activity']);barw=(w-100)/4
        for i,value in enumerate(TE['activity']):
            hh=170*value/peak;xx=m+i*(w/4);p.rect(xx,top+240-hh,barw,hh,ORANGE if i==3 else BLUE);p.text(xx,top+260,f'L{i+1}',26,INK,'mono')
        p.text(m,top+335,'P(W) = 99.995%',54,BLUE,'bold')
        p.text(m,top+415,'L4 / G4 / stolica polski / first prediction',20,MUTED,'mono')
    elif kind=='budget':
        p.text(m,top,'99,55%' if PL else '99.55%',115,BLUE,'bold');p.text(m,top+145,('DYSKIETKI ZAJĘTE' if PL else 'DISK CAPACITY USED'),24,INK,'mono')
        p.rect(m,top+220,w,55,LINE);p.rect(m,top+220,w*897024/901120,55,BLUE)
        p.text(m,top+310,'708 442 B / MODEL',31,INK,'mono');p.text(m,top+370,'186 KiB / ENGINE HEAP',31,INK,'mono')
    elif kind=='results':
        vals=[('Trening' if PL else 'Training',4109/4123,BLUE),('Nowe sformułowania' if PL else 'Held-out phrasings',453/1337,ORANGE)]
        for i,(label,value,c) in enumerate(vals):
            y=top+i*150;p.text(m,y,label,26,INK,'bold');p.text(p.w-m-170,y,f'{value*100:.1f}%',42,c,'bold');p.rect(m,y+67,w,28,LINE);p.rect(m,y+67,w*value,28,c)
    elif kind=='validation':
        p.rect(m,top,w,area,BLUE)
        labels=['WinUAE / A500 / 0.5 MB','ADF / OFS / Kickstart 1.3',('BEZ DYSKIETKI WORKBENCH' if PL else 'NO SEPARATE WORKBENCH DISK'),('POLSKI INTERFEJS I MODEL' if PL else 'POLISH INTERFACE AND MODEL')]
        for i,t in enumerate(labels):p.text(m+32,top+35+i*74,t,28,WHITE,'mono')
    # Footnote is part of the publication, not hidden in external metadata.
    note=s.get('note','')
    if platform=='linkedin' and kind=='validation':
        note=('Potwierdzenie WinUAE: autor projektu. Wynik modelu: 99,66% na treningu i 33,88% na odłożonych sformułowaniach. Tiny 2.1 / WollyMonjac (MIT). Rozwój z pomocą OpenAI Codex.' if PL else 'WinUAE confirmation: project author. Model: 99.66% training exact match, 33.88% held-out phrasings. Tiny 2.1 / WollyMonjac (MIT). Developed with OpenAI Codex.')
    p.para(m,p.h-230,note,w,22 if p.w==1400 else 20,MUTED)
    p.footer()

def export(lang,platform):
    slides=STORY[lang]['slides']
    if platform=='linkedin':slides=[slides[i] for i in [0,1,3,5,6,7,10,11]]
    dirname=ROOT/platform/lang;pdfdir=dirname/'pdf';pdfdir.mkdir(parents=True,exist_ok=True)
    aggregate=fitz.open()
    for i,s in enumerate(slides):
        size=(1400,2160 if s['kind']=='screens' else 1660 if s['kind']=='math' else 1320) if platform=='behance' else (1080,1350)
        stem=dirname/f'{i+1:02}_{s["id"].split("_",1)[1]}'
        bg=INK if s['kind'] in ['optimization','budget'] else BLUE if s['kind']=='validation' else PAPER
        p=Page(pdfdir/(stem.name+'.pdf'),*size,bg=bg,lang=lang,number=i+1,total=len(slides))
        if s['kind']=='hero':art_hero(p,s,platform)
        else:body_art(p,s,platform)
        p.finish(stem);single=fitz.open(str(p.path));aggregate.insert_pdf(single);single.close()
    aggregate.save(str(dirname/f'PolTiny-{platform}-{lang}.pdf'),deflate=True);aggregate.close()
    return slides

for lang in ['PL','EN']:
    export(lang,'behance');export(lang,'linkedin')
    story=STORY[lang]
    full='# '+story['title']+'\n\n'+story['history']+'\n\n'+story['goal']+'\n\n'
    for s in story['slides'][1:]:full+='## '+' '.join(s['title'])+'\n\n'+s['body']+'\n\n'+s.get('note','')+'\n\n'
    full+='\nTiny 2.1 / WollyMonjac: https://github.com/WollyMonjac/Tiny-2.1\nDane / Data: mledoze/countries (ODbL), Periodic-Table-JSON (CC BY-SA 3.0), original Polish examples.\n'
    (ROOT/'content'/f'CASE-STUDY-{lang}.md').write_text(full)
    (ROOT/'content'/f'LINKEDIN-POST-{lang}.txt').write_text(story['post']+'\n')
    (ROOT/'content'/f'BEHANCE-DESCRIPTION-{lang}.txt').write_text(story['subtitle']+'\n\n'+story['goal']+'\n\n'+story['history']+'\n')

index='<!doctype html><html lang="pl"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>PolTiny — historia projektu PL/EN</title><style>body{margin:0;background:#e9e9e4;font:18px/1.5 system-ui}nav{position:sticky;top:0;background:white;padding:18px;z-index:5}main{max-width:1400px;margin:auto}img{width:100%;height:auto;display:block}section{margin:30px 0}h2,p{padding:15px}a{color:#143ff0}</style><nav>'
for platform in ['behance','linkedin']:
    for lang in ['PL','EN']:index+=f'<a href="#{platform}-{lang}">{platform} {lang}</a> · '
index+='</nav><main>'
if missing:index+='<p><b>WERSJA ROBOCZA / DRAFT:</b> Oryginalne screeny nie zostały jeszcze dołączone. Miejsca na nie są wyraźnie oznaczone.</p>'
for platform in ['behance','linkedin']:
    for lang in ['PL','EN']:
        index+=f'<section id="{platform}-{lang}"><h2>{platform} / {lang}</h2>'
        for f in sorted((ROOT/platform/lang).glob('*.jpg')):index+=f'<img loading="lazy" src="{f.relative_to(ROOT).as_posix()}" alt="{html.escape(f.stem)}">'
        index+='</section>'
index+='</main></html>'; (ROOT/'PODGLAD.html').write_text(index)
status={'status':'draft_missing_original_screenshots' if missing else 'ready','missing_original_screenshots':sorted(missing),'author_reported_validation':'Author confirmed working in WinUAE; not independently re-tested in this workspace.','target':'Stock Amiga 500, 512 KiB (0.5 MB), no expansions, accelerator or FPU.','image_provenance':{'key-visual.png':'AI-generated editorial illustration, not a photo or documentary evidence.','upstream-tiny21.png':'Upstream Tiny 2.1 repository screenshot.','reading_7.png':'Awaiting user original, cropped to Amiga output; prompt spelling may be edited with caption.','reading_9.png':'Awaiting user original, cropped to Amiga output; prompt spelling may be edited with caption.'},'files':FILES,'publication':'No publication performed. User will upload through Claude in Chrome.'}
(ROOT/'MANIFEST.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n')
prompt='''Use this PolTiny package to prepare a project on Behance and a LinkedIn carousel. Read MANIFEST.json first. If its status is draft_missing_original_screenshots, do not publish the screenshot placeholders. Ask for the original images listed in missing_original_screenshots, then replace the corresponding assets and re-render the documents. Use only the Polish OR English set for one publication; do not interleave duplicate translations. Behance: upload JPG files from behance/PL or behance/EN in numerical order. LinkedIn: use the matching multipage PDF from linkedin/PL or linkedin/EN and the matching post text from content/. Full case-study copy and short descriptions are in content/. The goal was a stock Amiga 500, 0.5 MB RAM (512 KiB), no expansions, accelerator or FPU. Preserve the distinction between author-reported WinUAE verification, VAMOS CPU-cycle measurements, and physical hardware tests. No separate Workbench disk is required; Kickstart 1.3 remains necessary. Describe Polish explanations and explicit calculator steps accurately; do not invent human-like reasoning. Key visual is AI-generated artwork, not hardware-test evidence. Original screenshots must be cropped to the real Amiga display without the author's desktop background. If prompt spelling is corrected, retain a small editorial-correction caption. Keep all reported timing and progress data unchanged. Preserve attribution to WollyMonjac/Tiny-2.1, dataset licences and work with OpenAI Codex.\n'''
(ROOT/'PROMPT-DLA-CLAUDE.txt').write_text(prompt)
(ROOT/'SCREENY-DO-DOLACZENIA.md').write_text('''# Oryginalne screeny do dołączenia

Potrzebne są pliki z wcześniejszej rozmowy: ekran „Reading 7/31”, kolejny „Reading 9/31” oraz ekran z pytaniem „2+5”, licznikiem około 3:25 i paskiem odczytu. Dostępny jest opis tych obrazów, ale brak plików do kadrowania.

Po otrzymaniu oryginałów:
1. Zachowaj kopie surowych plików.
2. Wykadruj do granic prawdziwego emulowanego obrazu Amigi. Usuń tło gospodarza i czarne marginesy; nie odtwarzaj GUI od nowa.
3. Na życzenie autora popraw jedynie pisownię poleceń i usuń przypadkowo dopisane znaki. Przykład: „How many people are there on Earth?” lub „What is 2 + 5?”. Wyniki, postęp i czas programu pozostają danymi źródłowymi.
4. Przy redakcyjnej korekcie dodaj drobny podpis „kadrowanie i korekta pisowni poleceń” / „cropped; prompt spelling edited”.
5. Zapisz gotowe obrazy w assets/reading_7.png, assets/reading_9.png i assets/math_slow.png. Jeżeli jest aktualny screen PolTiny PL, dołącz go jako dodatkowe potwierdzenie obecnej wersji.

Plansze z placeholderami nie są gotowe do publikacji. Zrzuty z wersji angielskiej należy pokazać jako etap historii, a nie dowód ekranu późniejszego PolTiny PL.
''')
(ROOT/'00_START-TUTAJ.md').write_text('''# PolTiny — case study PL/EN, Behance i LinkedIn

To nowa wersja z chronologiczną historią projektu i nową ilustracją kluczową. Katalogi behance/PL i behance/EN zawierają po 12 plansz; linkedin/PL i linkedin/EN — po 8 slajdów i PDF karuzeli. Pliki content/ zawierają pełne teksty oraz posty po polsku i angielsku.

Otwórz PODGLAD.html po rozpakowaniu. Do Claude w Chrome przekaż PROMPT-DLA-CLAUDE.txt i pliki wybranego języka.

WAŻNE: status w MANIFEST.json opisuje brakujące oryginalne screeny. W tej wersji odpowiednie miejsca są oznaczone. Nie publikuj placeholderów; dołącz pliki wskazane w SCREENY-DO-DOLACZENIA.md. Ilustracja Amigi jest wygenerowaną grafiką redakcyjną, a nie zdjęciem potwierdzającym test sprzętowy.

Uruchomienie w WinUAE jest potwierdzeniem przekazanym przez autora. ADF nie potrzebuje osobnej dyskietki Workbench, ale wymaga Kickstartu 1.3. Celem była Amiga 500 z 0,5 MB RAM (512 KiB), bez dodatków. Wersja nie przypisuje małemu modelowi możliwości współczesnego dużego LLM.

Odtworzenie dokumentów: Python 3, ReportLab i PyMuPDF, fonty w fonts/. Uruchom python src/build_v2.py. Program osadza obrazy w dokumentach, nie rysuje ponownie oryginalnych screenów.
''')
print(json.dumps({'publication_images':len(FILES),'missing':sorted(missing),'directory':str(ROOT)},ensure_ascii=False))
