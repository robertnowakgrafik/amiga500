from pathlib import Path
import json,zipfile,hashlib
from html.parser import HTMLParser
import fitz
R=Path(__file__).resolve().parents[1]
M=json.loads((R/'MANIFEST.json').read_text())
assert len(M['files'])==40
for p in M['files']:
    assert (R/p).exists()
    pix=fitz.Pixmap(str(R/p))
    assert pix.width==(1400 if p.startswith('behance/') else 1080)
    if p.startswith('linkedin/'):assert pix.height==1350
for platform,count in [('behance',12),('linkedin',8)]:
    for lang in ['PL','EN']:
        p=R/platform/lang/f'PolTiny-{platform}-{lang}.pdf'
        d=fitz.open(p);assert len(d)==count;d.close()
for lang in ['PL','EN']:
    story=json.loads((R/'content/story.json').read_text())[lang]
    assert len(story['post'])<3000
    assert ('0,5 MB' if lang=='PL' else '0.5 MB') in story['goal']
class Links(HTMLParser):
    def handle_starttag(self,t,a):
        for k,v in a:
            if k in ['href','src'] and not v.startswith('#') and '://' not in v:assert (R/v).exists(),v
Links().feed((R/'PODGLAD.html').read_text())
out=R.parent/'dist/PolTiny-Behance-LinkedIn-PL-EN-roboczy.zip'
include=[]
for p in R.rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts or p.name=='SHA256SUMS.txt':continue
    # Aggregate PDFs retain vector text. Per-page intermediate PDFs are redundant.
    if p.parent.name=='pdf':continue
    # JPEG publication panels plus source data keep the archive compact.
    if p.suffix.lower()=='.png' and 'assets' not in p.relative_to(R).parts:continue
    include.append(p)
(R/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(R).as_posix()+'\n' for p in sorted(include)))
include.append(R/'SHA256SUMS.txt')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(include):z.write(p,'PolTiny-PL-EN/'+p.relative_to(R).as_posix())
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    assert len([n for n in z.namelist() if n.endswith('.jpg')])==40
print(json.dumps({'zip':str(out),'bytes':out.stat().st_size,'files':len(include),'status':M['status'],'missing_screens':M['missing_original_screenshots'],'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},ensure_ascii=False,indent=2))
