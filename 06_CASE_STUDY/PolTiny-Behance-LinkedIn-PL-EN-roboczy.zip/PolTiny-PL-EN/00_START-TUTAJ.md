# PolTiny — case study PL/EN, Behance i LinkedIn

To nowa wersja z chronologiczną historią projektu i nową ilustracją kluczową. Katalogi behance/PL i behance/EN zawierają po 12 plansz; linkedin/PL i linkedin/EN — po 8 slajdów i PDF karuzeli. Pliki content/ zawierają pełne teksty oraz posty po polsku i angielsku.

Otwórz PODGLAD.html po rozpakowaniu. Do Claude w Chrome przekaż PROMPT-DLA-CLAUDE.txt i pliki wybranego języka.

WAŻNE: status w MANIFEST.json opisuje brakujące oryginalne screeny. W tej wersji odpowiednie miejsca są oznaczone. Nie publikuj placeholderów; dołącz pliki wskazane w SCREENY-DO-DOLACZENIA.md. Ilustracja Amigi jest wygenerowaną grafiką redakcyjną, a nie zdjęciem potwierdzającym test sprzętowy.

Uruchomienie w WinUAE jest potwierdzeniem przekazanym przez autora. ADF nie potrzebuje osobnej dyskietki Workbench, ale wymaga Kickstartu 1.3. Celem była Amiga 500 z 0,5 MB RAM (512 KiB), bez dodatków. Wersja nie przypisuje małemu modelowi możliwości współczesnego dużego LLM.

Odtworzenie dokumentów: Python 3, ReportLab i PyMuPDF, fonty w fonts/. Uruchom python src/build_v2.py. Program osadza obrazy w dokumentach, nie rysuje ponownie oryginalnych screenów.
